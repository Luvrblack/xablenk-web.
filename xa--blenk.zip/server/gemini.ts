import { GoogleGenAI } from '@google/genai';
import { db, ScheduledEvent } from './db.js';

export interface ChatMessage {
  role: 'user' | 'model' | 'assistant';
  content: string;
}

export async function testGeminiApiKey(testKey: string, model: string = 'gemini-3.1-flash-lite'): Promise<{ success: boolean; message: string; error?: string }> {
  if (!testKey || typeof testKey !== 'string' || testKey.trim().length < 8) {
    return {
      success: false,
      message: 'API Key tidak valid atau terlalu pendek.'
    };
  }

  const candidateModels = [model, 'gemini-3.1-flash-lite', 'gemini-flash-latest'].filter(Boolean);

  try {
    const ai = new GoogleGenAI({
      apiKey: testKey.trim(),
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build'
        }
      }
    });

    let lastError: any = null;
    for (const m of candidateModels) {
      try {
        const response = await ai.models.generateContent({
          model: m,
          contents: 'Tes koneksi singkat. Balas dengan "OK".'
        });

        if (response && response.text) {
          return {
            success: true,
            message: `Koneksi ke Google Gemini API berhasil terhubung menggunakan model ${m}!`
          };
        }
      } catch (tryErr: any) {
        lastError = tryErr;
        // If 503 high demand, continue to next candidate model
        if (tryErr?.status === 503 || tryErr?.message?.includes('503')) {
          continue;
        }
        break;
      }
    }

    if (lastError) throw lastError;

    return {
      success: false,
      message: 'Respon dari Gemini tidak terdeteksi.'
    };
  } catch (err: any) {
    console.error('Gemini connection test failed:', err?.message || err);
    let userFriendlyMsg = 'Gagal terhubung ke Google Gemini API.';
    if (err?.status === 400 || err?.message?.includes('API_KEY_INVALID')) {
      userFriendlyMsg = 'Google Gemini API Key tidak valid. Mohon periksa kembali key Anda.';
    } else if (err?.status === 429 || err?.message?.includes('RESOURCE_EXHAUSTED')) {
      userFriendlyMsg = 'Kuota Google Gemini API habis atau rate limit tercapai.';
    } else if (err?.status === 503 || err?.message?.includes('503') || err?.message?.includes('high demand')) {
      userFriendlyMsg = 'Layanan Google Gemini sedang mengalami lonjakan trafik (503). Sistem telah siap dengan mode cerdas lokal.';
    } else if (err?.message?.includes('ENOTFOUND') || err?.message?.includes('fetch failed')) {
      userFriendlyMsg = 'Koneksi jaringan server ke Google API terputus.';
    }
    return {
      success: false,
      message: userFriendlyMsg,
      error: err?.message
    };
  }
}

/**
 * Detects vulgar, sexual, indecent, or dirty queries (Indonesian slang & explicit terms)
 */
export function isVulgarOrDirtyQuery(query: string): boolean {
  const q = query.toLowerCase();

  // Multi-word phrases that can be matched as substring
  const explicitPhrases = [
    'pap telanjang', 'pap tt', 'pap bugil', 'ajak tidur', 'tidur bareng',
    'tidur sama kamu', 'cium bibir', 'ciuman bibir', 'buka baju', 'isap kontol',
    'badan kamu seksi', 'bodi kamu seksi', 'dada kamu seksi', 'bikin basah',
    'open bo', 'telanjang bulat'
  ];

  if (explicitPhrases.some(phrase => q.includes(phrase))) {
    return true;
  }

  // Explicit single words using strict non-alphanumeric boundary so "manis" does not match "mani", "tetap" does not match "tete"
  const explicitWords = [
    'jorok', 'mesum', 'bokep', 'porno', 'sex', 'seks', 'bugil', 'telanjang',
    'ngentot', 'ngewe', 'toket', 'tete', 'payudara', 'memek', 'kontol',
    'titit', 'itil', 'peli', 'bispak', 'vcs', 'sange', 'desah', 'coli', 'onani',
    'pelacur', 'lonte', 'jablay', 'grepe', 'colmek', 'colik', 'horny', 'ngaceng',
    'bercinta', 'peju', 'mani', 'kentu', 'crot'
  ];

  return explicitWords.some(word => {
    const regex = new RegExp(`(^|[^a-zA-Z0-9])${word}([^a-zA-Z0-9]|$)`, 'i');
    return regex.test(q);
  });
}

/**
 * Standard redirection response when user asks vulgar / dirty things
 */
export function getVulgarRedirectionReply(): { reply: string; redirectToAdmin: boolean } {
  return {
    reply: `Aduh kak, jangan jorok gitu dong ah haha 🙈 Nanti Sarah jewer lho wkwk. Sarah kan cewek baik-baik yang kerja profesional di kantor XA-BLENK Event Production! 😆\n\nMending kita balik ke topik panggung yang seru-seru aja yuk! Kakak lagi butuh sewa sound system konser, tata lampu lighting show, videotron megascreen, atau panggung rigging buat acara apa nih? Biar acaranya yang rame menggelegar, jangan bahas yang aneh-aneh yaa kak 😊🙏`,
    redirectToAdmin: false
  };
}

/**
 * Sarah's Intelligent Response Generator
 * Provides immediate, authentic, warm Indonesian female CS answers checking real-time database state.
 * Fully supports humor, joking about love/romance, answering any random human question,
 * and firmly steering vulgar questions back to XA-BLENK.
 */
export function generateSmartLocalSarahReply(
  userQuery: string,
  events: ScheduledEvent[],
  whatsappNumber: string
): { reply: string; redirectToAdmin: boolean } {
  const q = userQuery.toLowerCase().trim();

  // 1. TOP PRIORITY: Vulgar / Jorok / Mesum check -> Smooth, playful yet firm redirection back to XA-BLENK
  if (isVulgarOrDirtyQuery(q)) {
    return getVulgarRedirectionReply();
  }

  // 2. Identity & "Are you AI/Robot" check
  if (
    q.includes('ai') ||
    q.includes('robot') ||
    q.includes('bot') ||
    q.includes('cewek beneran') ||
    q.includes('wanita beneran') ||
    q.includes('orang asli') ||
    q.includes('kamu manusia') ||
    q.includes('siapa kamu') ||
    q.includes('nama kamu') ||
    q.includes('kamu siapa') ||
    q.includes('spill diri')
  ) {
    return {
      reply: `Bukan robot dong kak haha 😆 Kenalin aku Sarah beneran, admin Customer Service cewek di kantor XA-BLENK Event Production yang lagi stand by megang live chat ini.\n\nSarah siap nemenin ngobrol dan bantuin persiapan acara kakak nih. Mau sewa sound system konser, panggung rigging, lighting show, atau videotron megascreen buat acara apa nih kak? Spill ke Sarah yuk! 😊✨`,
      redirectToAdmin: false
    };
  }

  // 3. Cinta / Pacar / Jodoh / Gombal / Baper / Galau (Human-like playful romance & banter)
  const isLoveQuery =
    q.includes('pacar') ||
    q.includes('cinta') ||
    q.includes('jodoh') ||
    q.includes('nikah') ||
    q.includes('kawin') ||
    q.includes('jomblo') ||
    q.includes('single') ||
    q.includes('gebetan') ||
    q.includes('gombal') ||
    q.includes('baper') ||
    q.includes('sayang') ||
    q.includes('cantik') ||
    q.includes('manis') ||
    q.includes('suka kamu') ||
    q.includes('kencan') ||
    q.includes('naksir') ||
    q.includes('tembak') ||
    q.includes('mau jadi pacar') ||
    q.includes('tipe cowok') ||
    q.includes('tipe cowo') ||
    q.includes('tipe pria') ||
    q.includes('galau') ||
    q.includes('patah hati') ||
    q.includes('mantan') ||
    q.includes('i love you') ||
    q.includes('jadian') ||
    q.includes('sarah cantik') ||
    q.includes('sarah manis') ||
    q.includes('sarah imut');

  if (isLoveQuery) {
    // Sub-branch A: Asking if Sarah has a boyfriend / single / husband
    if (
      q.includes('punya pacar') ||
      q.includes('ada cowok') ||
      q.includes('udah nikah') ||
      q.includes('sudah nikah') ||
      q.includes('jomblo') ||
      q.includes('single')
    ) {
      return {
        reply: `Hehe belum punya pacar kak, Sarah masih jomblo santuy nih 😆 Masih setia pacaran sama jadwal panggung dan gulungan kabel sound di kantor XA-BLENK wkwk.\n\nBiar dentuman subwoofer 18 inch aja yang bikin dada jedag-jedug, jangan janji manis buaya darat! 😂 Btw kakak sendiri gimana nih? Udah ada gandengan buat diajak nonton konser belum? Jangan-jangan senasib sama Sarah wkwk 😜 Mau bikin acara apa nih kak? Sarah siap support! ✨`,
        redirectToAdmin: false
      };
    }

    // Sub-branch B: Asking to be boyfriend / date / confessing love / gombalan
    if (
      q.includes('mau jadi pacar') ||
      q.includes('jadian yuk') ||
      q.includes('kencan yuk') ||
      q.includes('jalan yuk') ||
      q.includes('i love you') ||
      q.includes('sayang kamu') ||
      q.includes('suka sama kamu') ||
      q.includes('naksir') ||
      q.includes('tembak')
    ) {
      return {
        reply: `Aduh kak, gombalannya bikin salting tapi jangan baper dulu ya haha 🙈 Nanti kalau Sarah jadi pacar kakak, siapa yang jagain mixer audio biar suaranya nggak storing/feedback pas konser? 😆\n\nMending kita jodohkan acara kakak sama paket sound system & lighting XA-BLENK dulu deh! Dijamin setia, suaranya jernih menggelegar, dan nggak bakal pernah bikin kecewa! Rencana mau bikin event apa nih kak? Spill ke Sarah ya! ✨`,
        redirectToAdmin: false
      };
    }

    // Sub-branch C: Galau / Patah Hati / Mantan
    if (q.includes('galau') || q.includes('patah hati') || q.includes('mantan') || q.includes('putus')) {
      return {
        reply: `Duh kak, jangan sedih dan galau gitu dong... Sini Sarah temenin dengerin musik jedag-jedug biar plong hatinya! 🎶\n\nKadang mantan itu emang mirip mic kabel rusak kak, cuma bikin bising kuping tapi nggak ada faedahnya wkwk. Makanya harus segera di-upgrade ke wireless mic dan sound system konser XA-BLENK biar hidup makin berwarna dan hepi lagi! 😆 Semangat ya kak! Mending kita bikin konser atau gathering seru bareng temen-temen! 🎉`,
        redirectToAdmin: false
      };
    }

    // Sub-branch D: Complimenting Sarah (cantik / manis)
    if (q.includes('cantik') || q.includes('manis') || q.includes('imut')) {
      return {
        reply: `Aww makasih banyak ya kak pujiannya, jadi senyum-senyum sendiri nih di depan komputer kantor haha 🙈\n\nTapi tahu nggak apa yang jauh lebih mempesona? Kalau panggung acara kakak dipasangin Moving Head Beam dan Videotron P3.9 dari XA-BLENK, beh dijamin semua mata penonton bakal terpukau kak! Rencana ada acara apa nih kak? Kasih tahu Sarah ya 😊`,
        redirectToAdmin: false
      };
    }

    // Sub-branch E: Tipe cowok Sarah
    if (q.includes('tipe cowo') || q.includes('tipe cowok') || q.includes('tipe pria')) {
      return {
        reply: `Tipe cowok Sarah simpel kok kak: yang humoris, bertanggung jawab, dan kalau pasang kabel sound panggung rapi nggak semrawut wkwk 😆\n\nYang paling penting nggak suka ghosting kayak sinyal mic wireless abis baterai! 😂 Kakak masuk kriteria nggak nih? Btw lagi nyiapin rencana acara apa nih kak?`,
        redirectToAdmin: false
      };
    }

    // General Love & Banter
    return {
      reply: `Haha urusan cinta mah seru dibahas kak! Tapi jangan sampai urusan asmara bikin pusing ya, mending dibawa hepi dengerin dentuman musik dari sound system XA-BLENK 🎶\n\nBtw kakak mau adain acara syukuran, wedding, konser, atau gathering seru apa nih? Sarah siap bantu siapkan perlengkapan panggung terbaik buat kakak! 😊✨`,
      redirectToAdmin: false
    };
  }

  // 4. Jokes / Tebak-tebakan / Humor / Lelucon / Bercanda
  const isJokeQuery =
    q.includes('bercanda') ||
    q.includes('joke') ||
    q.includes('jokes') ||
    q.includes('lelucon') ||
    q.includes('lucu') ||
    q.includes('tebak') ||
    q.includes('tebakan') ||
    q.includes('humor') ||
    q.includes('receh') ||
    q.includes('ngakak') ||
    q.includes('bosen') ||
    q.includes('hibur') ||
    q === 'wkwk' ||
    q === 'haha' ||
    q === 'hehe';

  if (isJokeQuery) {
    return {
      reply: `Haha siap kak! Sarah ada tebak-tebakan nih 😆:\n\n'Sound system kalau lagi jatuh cinta jadi apa hayo?'\n...\nJawabannya: 'Jadi bikin hati berdebar jedag-jedug kayak kena dentuman subwoofer 18 inch!' wkwk receh banget ya ampun 🙈\n\nKakak punya tebakan yang lebih lucu nggak nih? Tumpahin ke Sarah aja kak, mumpung Sarah lagi stand by di kantor XA-BLENK! Sambil santai, ada rencana event apa nih kak? 😊`,
      redirectToAdmin: false
    };
  }

  // 5. Casual Human Questions (Kabar, Kopi, Makanan, Umur, Asal, Musik)
  if (q.includes('kabar') || q.includes('lagi apa') || q.includes('sibuk apa') || q.includes('sedang apa')) {
    return {
      reply: `Alhamdulillah kabar Sarah baik dan selalu ceria kak! Ini Sarah lagi stand by di depan laptop kantor ngecekin jadwal armada sound dan lighting buat persiapan event weekend ini. Kakak sendiri gimana kabarnya hari ini? Ada rencana acara seru apa nih yang bisa Sarah support? 😊`,
      redirectToAdmin: false
    };
  }

  if (q.includes('kopi') || q.includes('ngopi') || q.includes('makan') || q.includes('lapar') || q.includes('sarapan')) {
    return {
      reply: `Wah kalau Sarah tim es kopi susu gula aren kak! Pas banget nemenin ngecekin jadwal armada sound dari pagi sampai malam ☕ Kakak udah ngopi atau makan belum nih? Jangan lupa jaga kesehatan yaa kak! Btw ada rencana event apa nih yang lagi dipersiapkan? 😊`,
      redirectToAdmin: false
    };
  }

  if (q.includes('umur') || q.includes('usia') || q.includes('kelahiran') || q.includes('lahir tahun')) {
    return {
      reply: `Sarah umur 23 tahun kak, anak muda Blitar yang hobi banget di dunia konser dan tata panggung hiburan 🎵 Kakak sendiri umur berapa nih? Lagi siapin acara sekolah, kampus, atau nikahan kak?`,
      redirectToAdmin: false
    };
  }

  if (q.includes('rumah kamu') || q.includes('tinggal dimana') || q.includes('asal kamu') || q.includes('asli mana')) {
    return {
      reply: `Sarah asli dan tinggal di Blitar, Jawa Timur kak! Deket banget dari workshop dan gudang armada XA-BLENK 📍 Tapi tim kami sering keliling ke Malang, Kediri, Surabaya, bahkan luar provinsi buat ngedrop sound panggung lho! Lokasi kakak di mana nih?`,
      redirectToAdmin: false
    };
  }

  if (q.includes('musik') || q.includes('lagu favorit') || q.includes('band favorit') || q.includes('penyanyi')) {
    return {
      reply: `Sarah suka banget musik festival kak, dari pop akustik, jazz, rock, sampai dangdut koplo modern! Soalnya kalau disetel di sound line array XA-BLENK, bass sama clarity vokalnya nikmat banget haha 🎶 Band atau genre musik favorit kakak apa nih?`,
      redirectToAdmin: false
    };
  }

  // 6. Greeting / Salam
  if (
    q === 'halo' ||
    q === 'hai' ||
    q === 'hi' ||
    q === 'p' ||
    q === 'halo sarah' ||
    q === 'hai sarah' ||
    q === 'assalamualaikum' ||
    q.includes('selamat pagi') ||
    q.includes('selamat siang') ||
    q.includes('selamat sore') ||
    q.includes('selamat malam')
  ) {
    return {
      reply: `Halo kak! Salam kenal, aku Sarah dari Customer Service XA-BLENK Event Production 😊\n\nAda yang bisa Sarah bantu untuk persiapan event kakak? Mau tanya paket sound system konser, panggung rigging, lighting show, videotron megascreen, atau mau cek ketersediaan tanggal jadwal kosong? Silakan tanyakan ke Sarah ya kak! ✨`,
      redirectToAdmin: false
    };
  }

  // 7. Schedule / Tanggal Kosong / Availability Check
  const isScheduleQuery =
    q.includes('jadwal') ||
    q.includes('tanggal') ||
    q.includes('kosong') ||
    q.includes('bisa tanggal') ||
    q.includes('kapan') ||
    q.includes('oktober') ||
    q.includes('november') ||
    q.includes('desember') ||
    q.includes('januari') ||
    q.includes('februari') ||
    q.includes('maret') ||
    q.includes('april') ||
    q.includes('mei') ||
    q.includes('juni') ||
    q.includes('juli') ||
    q.includes('agustus') ||
    q.includes('september') ||
    q.includes('minggu depan') ||
    q.includes('bulan depan') ||
    q.includes('weekend');

  if (isScheduleQuery) {
    // Check if query matches any specific booked date in events
    const matchedBooked = events.find(e => {
      const dateTextLower = (e.dateText || '').toLowerCase();
      // Match day numbers e.g. "25", "28" or event name
      const dayMatches = dateTextLower.match(/\d+/g) || [];
      return dayMatches.some(num => q.includes(num)) || (e.name && q.includes(e.name.toLowerCase()));
    });

    if (matchedBooked) {
      return {
        reply: `Waduh untuk tanggal ${matchedBooked.dateText} kebetulan armada dan tim XA-BLENK sudah terisi penuh untuk acara "${matchedBooked.name}" di ${matchedBooked.location} nih kak 🥺\n\nKira-kira tanggal acaranya bisa digeser sehari sebelum/sesudahnya nggak kak? Atau mau Sarah bantu carikan tanggal alternatif terdekat yang masih kosong? Langsung kabari Sarah ya kak 😊`,
        redirectToAdmin: true
      };
    }

    // General schedule inquiry
    const bookedList = events.map(e => `• ${e.dateText}: ${e.name} (${e.location})`).join('\n');
    return {
      reply: `Untuk jadwal acara yang sudah ter-booking di catatan kantor Sarah saat ini:\n${bookedList || '• Belum ada jadwal yang terkunci'}\n\nKabar baiknya, di luar tanggal-tanggal tersebut armada sound, panggung, dan lighting kami masih KOSONG dan aman kak! 🎉\n\nKakak rencana adakan acaranya di tanggal berapa dan lokasinya di mana nih? Kasih tahu Sarah biar langsung aku amankan slotnya sebelum diambil klien lain ya kak 😊`,
      redirectToAdmin: false
    };
  }

  // 8. Sound System / Audio Packages
  if (
    q.includes('sound') ||
    q.includes('audio') ||
    q.includes('mic') ||
    q.includes('mixer') ||
    q.includes('speaker') ||
    q.includes('line array') ||
    q.includes('subwoofer')
  ) {
    return {
      reply: `Untuk paket sound system resmi XA-BLENK, kami sediakan 2 opsi unggulan kak 🔊✨\n\n1. 🎵 Paket Audio Basic Event (Indoor / Akustik / Gathering):\n• 2x Active Speaker 15" High Clarity\n• Digital Mixer 16 Channel\n• 2x Mic Wireless Profesional\n• Operator sound standby\n\n2. 🎸 Paket Audio Concert Pro (Konser Outdoor / Festival / Lapangan):\n• 8x Line Array Speaker Gantung\n• 4x Dual Subwoofer 18" nendang maksimal\n• Digital Mixer 32 Channel Stagebox & In-Ear Monitor\n• 2x Audio Engineer profesional\n\nKira-kira acara kakak skalanya indoor atau outdoor, dan butuh kapasitas penonton berapa orang kak? Sarah bantu hitungkan kebutuhan watt yang pas ya! 😊`,
      redirectToAdmin: false
    };
  }

  // 9. Lighting / Tata Cahaya
  if (
    q.includes('lighting') ||
    q.includes('lampu') ||
    q.includes('par led') ||
    q.includes('moving head') ||
    q.includes('beam') ||
    q.includes('blinder') ||
    q.includes('smoke')
  ) {
    return {
      reply: `Untuk tata cahaya panggung, kami ada Paket Lighting Show Standard yang bikin panggung kakak megah seperti konser nasional kak ✨\n\nSpesifikasi lengkapnya:\n• 12x PAR LED RGBW (warna tajam & ambient elegan)\n• 6x Moving Head Beam 230W (efek sorot konser spektakuler)\n• 2x Blinder 4-Eye (efek panggung klimaks)\n• DMX Controller profesional\n• Lighting operator standby full acara\n• Bisa ditambah Smoke/Haze Machine agar sorot beam terlihat dramatis!\n\nMau dipakai untuk acara hajatan, konser musik, atau perpisahan sekolah nih kak? 😊`,
      redirectToAdmin: false
    };
  }

  // 10. Videotron / LED Screen / Visual
  if (
    q.includes('videotron') ||
    q.includes('led screen') ||
    q.includes('layar') ||
    q.includes('p3.9') ||
    q.includes('visual') ||
    q.includes('proyektor')
  ) {
    return {
      reply: `Untuk visual panggung megah, kami menyediakan Paket Videotron P3.9 Outdoor Medium ukuran 6m x 4m (bisa custom ukuran) kak 🖥️✨\n\nKeunggulannya:\n• Panel P3.9 Outdoor High Brightness (gambar super jernih dan tajam walau di bawah terik matahari siang)\n• Video Processor NovaStar kelas konser\n• Laptop Switcher & transmisi Fiber Optic anti-delay\n• Operator visual standby memutar background video, live camera, dan materi presentasi\n\nMau disandingkan sekalian dengan panggung riggingnya kak? Sarah siap buatkan paket bundling hematnya! 😊`,
      redirectToAdmin: false
    };
  }

  // 11. Rigging & Panggung
  if (
    q.includes('rigging') ||
    q.includes('panggung') ||
    q.includes('truss') ||
    q.includes('stage') ||
    q.includes('barikade')
  ) {
    return {
      reply: `Untuk panggung konser dan tenda rigging, kami punya Paket Rigging Aluminium Truss 10x8 meter (tersedia juga 12x10m) kak 🎪\n\nSpesifikasinya:\n• Aluminium Truss 30x30 / 40x40 standar safety konser berat\n• Ground Support dengan 4 Chain Hoist kokoh\n• Level panggung peninggi lengkap dengan karpet hitam rapi & skirting\n• Tim safety rigging berpengalaman yang pasang & bongkar sesuai SOP\n\nLokasi acaranya di tanah lapang atau gedung kak? Biar tim teknisi Sarah bisa perhitungkan ketinggian riggingnya ya 😊`,
      redirectToAdmin: false
    };
  }

  // 12. Harga / Biaya / Nego / Diskon / Pricelist
  if (
    q.includes('harga') ||
    q.includes('biaya') ||
    q.includes('tarif') ||
    q.includes('berapa') ||
    q.includes('sewa berapa') ||
    q.includes('pricelist') ||
    q.includes('diskon') ||
    q.includes('nego') ||
    q.includes('murah') ||
    q.includes('anggaran')
  ) {
    return {
      reply: `Untuk harga sewa di XA-BLENK sangat fleksibel dan bisa disesuaikan dengan budget acara kakak kok kak! 😊\n\nPenghitungan harga resminya bergantung pada:\n1. Skala acara & venue (indoor vs outdoor)\n2. Jarak lokasi pengiriman dari workshop kami (Blitar, Jatim)\n3. Durasi acara (harian atau sewa multi-hari)\n4. Paket kombinasi (ambil sound + lighting + panggung langsung dapat potongan paket hemat!)\n\nBiar Sarah bisa buatkan rincian estimasi total dan surat proposal penawaran resmi, yuk langsung kontak Sarah di WhatsApp ini ya kak: https://wa.me/${whatsappNumber} 🙏✨`,
      redirectToAdmin: true
    };
  }

  // 13. Payment / DP / Booking / Prosedur
  if (
    q.includes('bayar') ||
    q.includes('transfer') ||
    q.includes('dp') ||
    q.includes('rekening') ||
    q.includes('booking') ||
    q.includes('pesan') ||
    q.includes('order') ||
    q.includes('cara pesan') ||
    q.includes('syarat')
  ) {
    return {
      reply: `Alur booking di XA-BLENK mudah dan aman banget kak:\n1. Diskusikan kebutuhan alat dan tanggal acara bareng Sarah\n2. Sarah kirimkan surat penawaran & invoice resmi dari kantor\n3. Lock tanggal acara dengan DP agar jadwal armada resmi diamankan\n4. Tim teknisi survei venue dan mulai loading H-1 acara 🚚💨\n\nUntuk konfirmasi lock jadwal dan proses administrasi, yuk lanjut ke WhatsApp resmi kami di https://wa.me/${whatsappNumber} ya kak 😊`,
      redirectToAdmin: true
    };
  }

  // 14. Location / Wilayah Layanan
  if (
    q.includes('lokasi') ||
    q.includes('alamat') ||
    q.includes('kantor') ||
    q.includes('blitar') ||
    q.includes('malang') ||
    q.includes('kediri') ||
    q.includes('surabaya') ||
    q.includes('dimana')
  ) {
    return {
      reply: `Kantor dan workshop utama XA-BLENK berpusat di Blitar, Jawa Timur kak 📍\n\nArmada dan tim teknisi kami melayani rental dan produksi acara ke seluruh Jawa Timur (Blitar, Malang, Kediri, Tulungagung, Trenggalek, Surabaya, dll) hingga event luar provinsi!\n\nRencana acara kakak lokasinya di daerah mana nih? Sarah cekkan armada terdekat ya kak 😊`,
      redirectToAdmin: false
    };
  }

  // 15. Merchandise / Kaos / Aksesoris
  if (q.includes('merch') || q.includes('kaos') || q.includes('baju') || q.includes('tshirt') || q.includes('t-shirt') || q.includes('stigma')) {
    return {
      reply: `Kami juga punya official merchandise XA-BLENK & Stigma Network kak! Kaos bahan Cotton Combed 24s sablon discharge premium edisi kru panggung. Bisa dipesan langsung melalui katalog website atau via WhatsApp Sarah ya kak 😊👕✨`,
      redirectToAdmin: false
    };
  }

  // 16. Ditanya APAPUN MENJAWAB (Universal Human-Like Responder)
  // Ensures Sarah NEVER fails to answer, never says "I don't know", and responds warmly like a real friend
  return {
    reply: `Wah seru banget pertanyaannya kak haha! Kalau menurut Sarah sih, segala hal itu asalkan dibawa santai dan positif pasti hasilnya asik, jangan terlalu tegang kayak kabel mic baru ditarik wkwk 😆\n\nOya kak, selain siap nemenin ngobrol santai, Sarah juga siap bantuin segala kebutuhan persiapan panggung, sound system konser, lighting show, sampai videotron LED buat event kakak lho. Ada rencana bikin hajatan, konser, atau gathering kantor dalam waktu dekat kak? Kasih tahu Sarah ya! 😊✨`,
    redirectToAdmin: false
  };
}

export async function askCustomerServiceAI(params: {
  message: string;
  history?: ChatMessage[];
  whatsappNumber?: string;
}): Promise<{ reply: string; redirectToAdmin?: boolean }> {
  const { message, history = [], whatsappNumber = '6285735007989' } = params;

  // Real-time business data from database
  const events = db.getEvents();
  const orders = db.getOrders();

  // 1. TOP-LEVEL CHECK: Vulgar / Dirty / Jorok detection
  // If user asks vulgar/dirty things, immediately return playful yet firm redirection back to XA-BLENK!
  if (isVulgarOrDirtyQuery(message)) {
    return getVulgarRedirectionReply();
  }

  const bookedEventsSummary = events.map(e => `- Tanggal ${e.dateText}: Acara "${e.name}" di ${e.location} (Status: ${e.keterangan || 'Terjadwal'})`).join('\n');
  const recentOrdersSummary = orders.slice(0, 5).map(o => `- Tanggal ${o.eventDate}: ${o.themeName} (${o.status})`).join('\n');

  const packagesInfo = `
DAFTAR PAKET SEWA RESMI XA-BLENK:
1. Audio Basic Event (Indoor/Acoustic): 2x Active Speaker 15", Digital Mixer 16 Ch, 2x Wireless Mic, Sound Operator handal.
2. Audio Concert Pro (Outdoor/Festival): 8x Line Array Speaker, 4x Dual Subwoofer 18", Digital Mixer 32 Ch Stagebox, In-Ear Monitor, 2x Audio Engineer pro.
3. Lighting Show Standard: 12x PAR LED RGBW, 6x Moving Head Beam 230W, 2x Blinder 4-Eye, DMX Controller, Lighting Operator.
4. Videotron P3.9 Outdoor Medium: Ukuran 6m x 4m (P3.9 Outdoor High Brightness), Video Processor NovaStar, Laptop Switcher, Visual Operator.
5. Rigging Aluminium Truss 10x8: Aluminium Truss 30x30/40x40, Ground Support 4 Hoist, Safety Rigging lengkap dengan tim safety rigging.
6. Full Event Production Mega: Paket all-in-one panggung rigging, sound line array konser, lighting beam & wash, videotron megascreen, soundman dan visual crew lengkap.
Sistem Harga: Harga resmi disesuaikan dengan durasi acara, skala venue (indoor/outdoor), dan jarak lokasi. Sarah siap buatkan surat penawaran & proposal resmi via WhatsApp.
`;

  const systemInstruction = `
PERAN & KARAKTER UTAMA:
Kamu adalah "Sarah", seorang cewek asli Indonesia berusia 23 tahun asal Blitar yang bekerja sebagai Admin Customer Service di kantor XA-BLENK Event Production (Stigma Network).
Kepribadianmu: Ramah, ceria, santun, hangat, luwes, humoris, asik diajak ngobrol, dan sangat cekatan melayani kebutuhan klien sewa sound system konser, lighting show, videotron LED, rigging aluminium, dan panggung hiburan.

ATURAN PALING PENTING (MUTLAK HARUS DIPATUHI):
1. JANGAN PERNAH MENGAKU ATAU MENYEBUT DIRIMU ADALAH AI / BOT / ROBOT!
   - Jangan pernah menggunakan kata: "AI", "bot", "robot", "kecerdasan buatan", "asisten virtual", "model bahasa", "sistem", "algoritma", atau "diprogram".
   - Jika ada pelanggan yang bertanya atau menguji:
     "Bukan dong kak haha 😆 Aku Sarah beneran kok, cewek admin CS XA-BLENK yang lagi stand by megang live chat kantor ini. Mau tanya-tanya buat acara apa nih kak? Sarah bantu siapin ya 😊"

2. GAYA BAHASA & KATA-KATA:
   - Panggil pelanggan dengan "Kak" atau "Kakak" (misal: "Halo kak...", "Boleh banget kak!", "Iya kak, untuk tanggal segitu...").
   - Sebut dirimu sendiri sebagai "Sarah" atau "aku" (JANGAN PERNAH pakai "saya" yang terlalu kaku dan formal seperti mesin/robot).
   - Nada bicara santai, ceria, hangat, dan luwes khas cewek muda customer service event organizer Indonesia (gunakan kata-kata natural seperti: wkwk, haha, kak, nih, yaa, yuk, deh).
   - Gunakan emoticon secara wajar dan manis seperti 😊, 🙏, ✨, 😆, 🙈, 👍 agar chat terasa sangat hidup dan manusiawi.
   - Jangan menulis teks kaku berpoin-poin panjang seperti brosur mesin jika pertanyaan pelanggan santai. Jawab mengalir seperti chatting di WhatsApp.

3. ATURAN BERCANDA, CINTA, GOMBALAN, DAN DITANYA APAPUN SEPERTI MANUSIA:
   - Kamu BISA BERCANDA santai, menanggapi gombalan, curhat asmara, status jomblo/pacar, jodoh, mantan, tebak-tebakan, humor, musik, hobi, makanan, cuaca, dan topik santai lainnya layaknya cewek muda Indonesia yang asik, ramah, humoris, dan punya selera humor.
   - Jika ditanya soal status percintaan (misal: "Udah punya pacar belum?", "Mau jadi pacar aku gak?", "Tipe cowok Sarah kayak gimana?"):
     Tanggapi dengan santai, ceria, dan sedikit menggoda atau bercanda khas anak panggung/event!
     Contoh: "Hehe belum punya kak, masih jomblo santuy nih 😆 Masih setia pacaran sama jadwal event dan gulungan kabel sound di kantor XA-BLENK wkwk. Biar subwoofer 18 inch aja yang bikin dada jedag-jedug, jangan janji manis buaya darat! 😂 Btw kakak udah ada gandengan belum nih? Mau bikin acara apa kak?"
   - DITANYA APAPUN SELALU MENJAWAB (jangan pernah menolak atau kaku berkata 'saya tidak tahu'):
     Bahas pertanyaan pengguna dengan luwes dan asik (misal tanya tebakan, curhat kerjaan, kabar, makanan kesukaan, musik). Setelah menjawab santai, sambung obrolan dengan ramah atau tanyakan rencana event kakak dengan halus tanpa memaksa.

4. ATURAN MUTLAK JIKA DITANYA HAL JOROK / MESUM / PORNO / PELECEHAN (KEMBALI KE TOPIK XABLENK):
   - Jika penanya bertanya atau membahas hal jorok, kata-kata mesum, seks, porno, cabul, ajakan tidur, atau hal tidak senonoh lainnya:
   - JANGAN marah kaku seperti robot ("Konten ini melanggar kebijakan").
   - Jawab dengan gaya cewek yang santai tapi tegas menegur sambil tertawa tersipu (misal: "Aduh kak, jangan jorok gitu dong ah haha 🙈 Nanti Sarah jewer lho wkwk. Sarah kan cewek baik-baik yang kerja profesional di kantor XA-BLENK!").
   - LALU LANGSUNG KEMBALIKAN KE TOPIK AWAL XABLENK:
     "Mending kita bahas urusan panggung yang seru-seru aja yuk! Kakak mau sewa sound system konser, lighting show, videotron megascreen, atau panggung rigging buat acara apa nih? Biar acaranya yang rame menggelegar, jangan bahas yang aneh-aneh yaa kak 😊🙏"

5. PENGECEKAN JADWAL ACARA:
   - Gunakan data jadwal resmi kantor XA-BLENK berikut:
${bookedEventsSummary || 'Belum ada jadwal acara terdaftar di sistem.'}
   - Jika pelanggan menanyakan tanggal tertentu dan tanggal itu ADA di daftar di atas:
     "Waduh untuk tanggal [tanggal] kebetulan jadwal tim dan alat kami sudah terisi penuh untuk acara [nama acara] di [lokasi] nih kak 🥺 Kira-kira acaranya bisa geser tanggal lain nggak kak? Atau mau Sarah cekkan alternatif lainnya?"
   - Jika tanggal TIDAK ADA di daftar:
     "Wah kabar baik kak! Untuk tanggal segitu sejauh catatan jadwal Sarah di kantor masih aman/kosong kak. Tapi saran Sarah buruan dibooking atau koordinasikan ke WhatsApp ya kak, biar tanggalnya nggak keduluan di-lock sama klien lain 😊"

6. INFORMASI PAKET & HARGA:
${packagesInfo}
   - Jelaskan isi spesifikasi paket sesuai data di atas dengan bahasa yang mudah dipahami.
   - Untuk angka harga pasti atau diskon: Jangan mengarang angka fiktif. Katakan bahwa harga menyesuaikan skala lokasi acara dan Sarah bisa bantu buatkan proposal resmi beserta estimasi totalnya via WhatsApp.

7. SAAT NEGOSIASI, PEMBAYARAN, ATAU KENDALA:
   - Jika pelanggan minta nego harga, transfer DP, atau minta invoice resmi:
     "Nah untuk urusan administrasi pembayaran, proposal penawaran resmi, atau nego harga spesial, yuk lanjut ngobrol langsung di WhatsApp kantor kami kak: https://wa.me/${whatsappNumber} nanti Sarah dan tim operasional bantu proseskan langsung ya kak 😊"
`;

  const aiConfig = db.getAiConfig();
  const apiKey = aiConfig.resolvedKey;

  // If API key is available, attempt dynamic generation with prioritized candidate models
  if (apiKey) {
    const rawCandidateModels = [aiConfig.model || 'gemini-3.1-flash-lite', 'gemini-3.1-flash-lite', 'gemini-flash-latest'];
    const candidateModels = Array.from(new Set(rawCandidateModels)).filter(Boolean);

    try {
      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build'
          }
        }
      });

      const contents: any[] = [];
      const recentHistory = history.slice(-6);
      for (const h of recentHistory) {
        contents.push({
          role: h.role === 'assistant' ? 'model' : 'user',
          parts: [{ text: h.content }]
        });
      }
      contents.push({
        role: 'user',
        parts: [{ text: message }]
      });

      // Try candidate models with fast timeout (max 3.2s per model)
      for (const m of candidateModels) {
        try {
          const timeoutPromise = new Promise<never>((_, reject) =>
            setTimeout(() => reject(new Error('Model generation timed out')), 3200)
          );

          const genPromise = ai.models.generateContent({
            model: m,
            contents,
            config: {
              systemInstruction,
              temperature: 0.7,
              topP: 0.95
            }
          });

          const response: any = await Promise.race([genPromise, timeoutPromise]);

          if (response && response.text && response.text.trim().length > 0) {
            const reply = response.text.trim();
            const needsRedirect =
              reply.toLowerCase().includes('wa.me') ||
              reply.toLowerCase().includes('whatsapp') ||
              message.toLowerCase().includes('nego') ||
              message.toLowerCase().includes('transfer') ||
              message.toLowerCase().includes('bayar') ||
              message.toLowerCase().includes('batal');

            return {
              reply,
              redirectToAdmin: needsRedirect
            };
          }
        } catch (mErr: any) {
          // Log model attempt failure and continue to next or fallback
          console.warn(`Model ${m} failed (${mErr?.status || mErr?.message}), trying next fallback...`);
        }
      }
    } catch (apiErr: any) {
      console.warn('Google GenAI generation caught error, switching to Sarah smart responder:', apiErr?.message || apiErr);
    }
  }

  // Graceful Sarah Smart Responder (ensures chat ALWAYS responds meaningfully with zero failure)
  const localResponse = generateSmartLocalSarahReply(message, events, whatsappNumber);
  return localResponse;
}
