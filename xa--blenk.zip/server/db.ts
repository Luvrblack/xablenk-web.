import fs from 'fs';
import path from 'path';

export interface Order {
  id: string;
  customerName: string;
  phone: string;
  address: string;
  themeName: string;
  eventDate: string;
  eventTime: string;
  services: string[];
  notes: string;
  status: 'Pending' | 'Dikonfirmasi' | 'Selesai' | 'Dibatalkan';
  createdAt: string;
  totalEstimate?: string;
}

export interface ScheduledEvent {
  id: string;
  no: string;
  name: string;
  dateText: string;
  client: string;
  location: string;
  timeText: string;
  keterangan: string;
  timestamp: number;
}

export interface AIConfig {
  customApiKey?: string;
  model: string;
  lastTested?: string;
  status: 'connected' | 'unconfigured' | 'error';
  lastError?: string;
}

const DATA_DIR = path.resolve(process.cwd(), '.data');
const ORDERS_FILE = path.join(DATA_DIR, 'orders.json');
const EVENTS_FILE = path.join(DATA_DIR, 'events.json');
const AI_CONFIG_FILE = path.join(DATA_DIR, 'ai_config.json');

// Ensure directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Initial seed data
const initialEvents: ScheduledEvent[] = [
  {
    id: '1',
    no: '01',
    name: 'Konser Musik',
    dateText: 'Sabtu, 25 Oktober 2026',
    client: 'Penyewa DEMO',
    location: 'Blitar',
    timeText: '19.00 WIB',
    keterangan: 'Full Sound & Lighting Setup',
    timestamp: Date.now()
  },
  {
    id: '2',
    no: '02',
    name: 'Wedding Event',
    dateText: 'Rabu, 28 Oktober 2026',
    client: 'Penyewa DEMO',
    location: 'Malang',
    timeText: '10.00 WIB',
    keterangan: 'Acoustic & Stage Production',
    timestamp: Date.now()
  }
];

const initialOrders: Order[] = [
  {
    id: 'ORD-2026-001',
    customerName: 'Budi Santoso',
    phone: '081234567890',
    address: 'Jl. Merdeka No. 45, Blitar',
    themeName: 'Konser Akustik Kampus',
    eventDate: '2026-10-30',
    eventTime: '18:30 WIB',
    services: ['Audio System', 'Lighting System'],
    notes: 'Mohon sound engineer standby mulai jam 15:00',
    status: 'Dikonfirmasi',
    createdAt: new Date().toISOString()
  }
];

function readJson<T>(filePath: string, fallback: T): T {
  try {
    if (!fs.existsSync(filePath)) {
      fs.writeFileSync(filePath, JSON.stringify(fallback, null, 2), 'utf-8');
      return fallback;
    }
    const data = fs.readFileSync(filePath, 'utf-8');
    return JSON.parse(data);
  } catch (err) {
    console.error(`Error reading ${filePath}:`, err);
    return fallback;
  }
}

function writeJson<T>(filePath: string, data: T): void {
  try {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    console.error(`Error writing ${filePath}:`, err);
  }
}

// Simple XOR / Base64 obfuscation for server-side key protection so it's not stored in raw plaintext
const SALT = 'XA-BLENK-SECURE-SALT-2026';
function encryptKey(text: string): string {
  if (!text) return '';
  const buffer = Buffer.from(text);
  const encrypted = Buffer.from(buffer.map((byte, i) => byte ^ SALT.charCodeAt(i % SALT.length)));
  return 'ENC:' + encrypted.toString('base64');
}

function decryptKey(enc: string): string {
  if (!enc) return '';
  if (!enc.startsWith('ENC:')) return enc;
  const raw = enc.substring(4);
  const buffer = Buffer.from(raw, 'base64');
  const decrypted = Buffer.from(buffer.map((byte, i) => byte ^ SALT.charCodeAt(i % SALT.length)));
  return decrypted.toString('utf-8');
}

export const db = {
  // Orders
  getOrders(): Order[] {
    return readJson<Order[]>(ORDERS_FILE, initialOrders);
  },

  createOrder(orderData: Omit<Order, 'id' | 'createdAt' | 'status'> & Partial<Order>): Order {
    const orders = this.getOrders();
    const newOrder: Order = {
      id: `ORD-${Date.now().toString().slice(-6)}`,
      customerName: orderData.customerName || 'Pelanggan',
      phone: orderData.phone || '',
      address: orderData.address || '',
      themeName: orderData.themeName || '',
      eventDate: orderData.eventDate || '',
      eventTime: orderData.eventTime || '',
      services: orderData.services || [],
      notes: orderData.notes || '',
      status: orderData.status || 'Pending',
      createdAt: new Date().toISOString(),
      totalEstimate: orderData.totalEstimate
    };
    orders.unshift(newOrder);
    writeJson(ORDERS_FILE, orders);
    return newOrder;
  },

  updateOrderStatus(id: string, status: Order['status']): Order | null {
    const orders = this.getOrders();
    const index = orders.findIndex(o => o.id === id);
    if (index === -1) return null;
    orders[index].status = status;
    writeJson(ORDERS_FILE, orders);
    return orders[index];
  },

  deleteOrder(id: string): boolean {
    const orders = this.getOrders();
    const filtered = orders.filter(o => o.id !== id);
    if (filtered.length === orders.length) return false;
    writeJson(ORDERS_FILE, filtered);
    return true;
  },

  // Events
  getEvents(): ScheduledEvent[] {
    return readJson<ScheduledEvent[]>(EVENTS_FILE, initialEvents);
  },

  createEvent(event: Omit<ScheduledEvent, 'id' | 'timestamp'> & { id?: string }): ScheduledEvent {
    const events = this.getEvents();
    const newEvent: ScheduledEvent = {
      id: event.id || String(Date.now()),
      no: event.no || String(events.length + 1).padStart(2, '0'),
      name: event.name,
      dateText: event.dateText,
      client: event.client,
      location: event.location,
      timeText: event.timeText,
      keterangan: event.keterangan || '',
      timestamp: Date.now()
    };
    events.push(newEvent);
    writeJson(EVENTS_FILE, events);
    return newEvent;
  },

  deleteEvent(id: string): boolean {
    const events = this.getEvents();
    const filtered = events.filter(e => e.id !== id);
    if (filtered.length === events.length) return false;
    writeJson(EVENTS_FILE, filtered);
    return true;
  },

  // AI Configuration
  getAiConfig(): AIConfig & { resolvedKey: string } {
    const stored = readJson<any>(AI_CONFIG_FILE, {
      model: 'gemini-3.1-flash-lite',
      status: 'unconfigured'
    });

    const decrypted = stored.encryptedKey ? decryptKey(stored.encryptedKey) : '';
    const envKey = process.env.GEMINI_API_KEY || '';
    const resolvedKey = decrypted || envKey;

    let computedStatus: AIConfig['status'] = stored.status || 'unconfigured';
    if (!resolvedKey) {
      computedStatus = 'unconfigured';
    } else if (computedStatus === 'unconfigured') {
      computedStatus = 'connected';
    }

    return {
      model: stored.model || 'gemini-3.1-flash-lite',
      lastTested: stored.lastTested,
      status: computedStatus,
      lastError: stored.lastError,
      resolvedKey
    };
  },

  saveAiConfig(data: { apiKey?: string; model?: string; status?: AIConfig['status']; lastError?: string }) {
    const current = readJson<any>(AI_CONFIG_FILE, {
      model: 'gemini-3.1-flash-lite',
      status: 'unconfigured'
    });

    if (data.apiKey !== undefined) {
      current.encryptedKey = data.apiKey ? encryptKey(data.apiKey) : '';
    }
    if (data.model) {
      current.model = data.model;
    }
    if (data.status) {
      current.status = data.status;
    }
    if (data.lastError !== undefined) {
      current.lastError = data.lastError;
    }
    current.lastTested = new Date().toISOString();

    writeJson(AI_CONFIG_FILE, current);
    return this.getAiConfig();
  },

  deleteAiConfig() {
    writeJson(AI_CONFIG_FILE, {
      model: 'gemini-3.1-flash-lite',
      status: 'unconfigured',
      encryptedKey: ''
    });
  }
};
