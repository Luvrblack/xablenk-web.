/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import MerchandiseSection from './components/MerchandiseSection';
import Services from './components/Services';
import RentalPackages from './components/RentalPackages';
import EventScheduleTable from './components/EventScheduleTable';
import PortfolioGallery from './components/PortfolioGallery';
import BookingForm from './components/BookingForm';
import Footer from './components/Footer';
import AdminDashboard from './components/AdminDashboard';
import CustomerServiceChat from './components/CustomerServiceChat';
import { Lock, Home, Package, ShoppingBag, Image as ImageIcon, MessageSquare } from 'lucide-react';

export default function App() {
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('beranda');

  useEffect(() => {
    const handleHashChange = () => {
      if (window.location.hash === '#admin') {
        setIsAdminOpen(true);
      } else {
        setIsAdminOpen(false);
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      // Shortcut Ctrl+Shift+A or Alt+A to open Admin Control Panel
      if ((e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 'a') || (e.altKey && e.key.toLowerCase() === 'a')) {
        e.preventDefault();
        setIsAdminOpen(prev => !prev);
      }
    };

    if (window.location.hash === '#admin') {
      setIsAdminOpen(true);
    }
    window.addEventListener('hashchange', handleHashChange);
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('hashchange', handleHashChange);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, []);

  return (
    <div className="min-h-screen bg-black-main text-white selection:bg-red-main selection:text-white relative pb-20 lg:pb-0">
      {/* Mobile App Installer Header Bar */}
      <div className="lg:hidden bg-black-secondary/90 border-b border-red-main/20 px-4 py-2 flex items-center justify-between text-[11px] font-mono tracking-wider">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-red-main animate-pulse"></span>
          <span className="text-gray-main">APP INSTALLED:</span>
          <span className="text-white font-bold">XA-BLENK MOBILE</span>
        </div>
        <a 
          href="#admin" 
          onClick={() => setIsAdminOpen(true)}
          className="text-red-main font-bold flex items-center gap-1 bg-red-main/10 px-2.5 py-1 rounded-sm border border-red-main/30"
        >
          <Lock className="w-3 h-3" /> C-Panel
        </a>
      </div>

      <Header />
      <Hero />
      <Services />
      <RentalPackages />
      <EventScheduleTable />
      <MerchandiseSection />
      <PortfolioGallery />
      <BookingForm />
      <Footer />

      {/* Customer Service AI Floating Widget */}
      <CustomerServiceChat />

      {/* Floating Admin Trigger Button (Desktop) - Hidden per user request */}
      <a
        href="#admin"
        onClick={() => setIsAdminOpen(true)}
        className="hidden fixed bottom-6 right-6 z-40 bg-bg-card hover:bg-red-main text-white p-3 rounded-full border border-red-main/50 shadow-2xl transition-all duration-300 items-center gap-2 group glow-border"
        style={{ display: 'none' }}
        title="Admin Control Panel"
        aria-hidden="true"
      >
        <Lock className="w-4 h-4 text-red-main group-hover:text-white" />
        <span className="text-[10px] font-bold uppercase tracking-wider pr-1 hidden group-hover:inline">C-Panel Admin</span>
      </a>

      {/* Mobile Bottom Navigation Bar (Installer App Style) */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-black-main/95 backdrop-blur-lg border-t border-red-main/30 px-2 py-2.5 flex justify-around items-center shadow-[0_-10px_30px_rgba(0,0,0,0.8)]">
        <a
          href="#beranda"
          onClick={() => setActiveTab('beranda')}
          className={`flex flex-col items-center gap-1 transition-colors ${activeTab === 'beranda' ? 'text-red-main font-bold' : 'text-gray-main hover:text-white'}`}
        >
          <Home className="w-5 h-5" />
          <span className="text-[9px] uppercase tracking-wider">Beranda</span>
        </a>
        <a
          href="#paket"
          onClick={() => setActiveTab('paket')}
          className={`flex flex-col items-center gap-1 transition-colors ${activeTab === 'paket' ? 'text-red-main font-bold' : 'text-gray-main hover:text-white'}`}
        >
          <Package className="w-5 h-5" />
          <span className="text-[9px] uppercase tracking-wider">Paket</span>
        </a>
        <a
          href="#merchandise"
          onClick={() => setActiveTab('merchandise')}
          className={`flex flex-col items-center gap-1 transition-colors ${activeTab === 'merchandise' ? 'text-red-main font-bold' : 'text-gray-main hover:text-white'}`}
        >
          <ShoppingBag className="w-5 h-5" />
          <span className="text-[9px] uppercase tracking-wider">Store</span>
        </a>
        <a
          href="#galeri"
          onClick={() => setActiveTab('galeri')}
          className={`flex flex-col items-center gap-1 transition-colors ${activeTab === 'galeri' ? 'text-red-main font-bold' : 'text-gray-main hover:text-white'}`}
        >
          <ImageIcon className="w-5 h-5" />
          <span className="text-[9px] uppercase tracking-wider">Galeri</span>
        </a>
        <a
          href="#kontak"
          onClick={() => setActiveTab('kontak')}
          className={`flex flex-col items-center gap-1 transition-colors ${activeTab === 'kontak' ? 'text-red-main font-bold' : 'text-gray-main hover:text-white'}`}
        >
          <MessageSquare className="w-5 h-5" />
          <span className="text-[9px] uppercase tracking-wider">Booking</span>
        </a>
        <a
          href="#admin"
          onClick={() => {
            setActiveTab('admin');
            setIsAdminOpen(true);
          }}
          className={`flex flex-col items-center gap-1 transition-colors ${activeTab === 'admin' ? 'text-red-main font-bold' : 'text-gray-main hover:text-white'}`}
        >
          <Lock className="w-5 h-5 text-red-main" />
          <span className="text-[9px] uppercase tracking-wider text-red-main">C-Panel</span>
        </a>
      </nav>

      {/* Admin Dashboard Modal / View */}
      {isAdminOpen && (
        <AdminDashboard
          onClose={() => {
            setIsAdminOpen(false);
            window.location.hash = '';
            setActiveTab('beranda');
          }}
        />
      )}
    </div>
  );
}
