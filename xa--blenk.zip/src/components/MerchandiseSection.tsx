import { useState, useEffect } from 'react';
import { ShoppingBag, MessageSquare, Check, Sparkles, Phone, ShieldCheck, HelpCircle, Trash2, Plus, Minus, ShoppingCart, X, ArrowRight } from 'lucide-react';

export interface MerchandiseItem {
  id: string;
  name: string;
  image: string;
  price: string;
  sizes: string[];
  description: string;
  status: 'Ready' | 'Pre-Order';
}

export interface CartItem {
  cartId: string;
  item: MerchandiseItem;
  size: string;
  quantity: number;
  customNote?: string;
}

export const initialMerchandise: MerchandiseItem[] = [
  {
    id: 'm1',
    name: 'Official XA-BLENK Hoodie Tour Edition',
    image: 'https://images.unsplash.com/photo-1556905055-8f358a7a47b2?q=80&w=800',
    price: 'Rp 250.000',
    sizes: ['S', 'M', 'L', 'XL', 'XXL', 'Custom Size'],
    description: 'Hoodie premium cotton fleece tebal dengan sablon plastisol high-density tahan lama.',
    status: 'Ready'
  },
  {
    id: 'm2',
    name: 'Crewneck Audio & Lighting Tech',
    image: 'https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?q=80&w=800',
    price: 'Rp 220.000',
    sizes: ['S', 'M', 'L', 'XL', 'XXL', 'Custom Size'],
    description: 'Crewneck eksklusif crew produksi dengan bordir tebal di dada dan lengan.',
    status: 'Ready'
  },
  {
    id: 'm3',
    name: 'T-Shirt Stage Production Official',
    image: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?q=80&w=800',
    price: 'Rp 150.000',
    sizes: ['S', 'M', 'L', 'XL', 'XXL', 'Custom Size'],
    description: 'Kaos 100% Cotton Combed 24s adem dengan sablon DTF full color desain futuristik.',
    status: 'Ready'
  },
  {
    id: 'm4',
    name: 'Snapback Cap XA-BLENK Red Energy',
    image: 'https://images.unsplash.com/photo-1588850561407-ed78c282e89b?q=80&w=800',
    price: 'Rp 110.000',
    sizes: ['All Size (Adjustable)', 'Custom Size'],
    description: 'Topi snapback bordir timbul logo XA-BLENK dengan pengait belakang.',
    status: 'Ready'
  },
  {
    id: 'm5',
    name: 'Lanyard & ID Holder Crew',
    image: 'https://images.unsplash.com/photo-1618354691373-d851c5c3a990?q=80&w=800',
    price: 'Rp 45.000',
    sizes: ['Standard', 'Custom Length'],
    description: 'Tali lanyard bahan tissue premium lembut dengan cetak bolak-balik high-res.',
    status: 'Ready'
  },
  {
    id: 'm6',
    name: 'Windbreaker Jacket Event Production',
    image: 'https://images.unsplash.com/photo-1544441893-675973e31985?q=80&w=800',
    price: 'Rp 320.000',
    sizes: ['S', 'M', 'L', 'XL', 'XXL', 'Custom Size'],
    description: 'Jaket parasut anti angin dan tahan air (water repellent) cocok untuk kru panggung.',
    status: 'Pre-Order'
  }
];

export default function MerchandiseSection() {
  const [merchList, setMerchList] = useState<MerchandiseItem[]>(() => {
    const saved = localStorage.getItem('xablenk_merchandise');
    return saved ? JSON.parse(saved) : initialMerchandise;
  });
  const [activeSubTab, setActiveSubTab] = useState<'catalog' | 'contact'>('catalog');
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [selectedSizes, setSelectedSizes] = useState<{ [key: string]: string }>({});
  const [customInputValues, setCustomInputValues] = useState<{ [key: string]: string }>({});
  const [cartItems, setCartItems] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('xablenk_cart_items');
    return saved ? JSON.parse(saved) : [];
  });
  const [notification, setNotification] = useState<string | null>(null);
  const [merchandiseWaNumber, setMerchandiseWaNumber] = useState<string>('6285735007989');

  useEffect(() => {
    const updateData = () => {
      const saved = localStorage.getItem('xablenk_merchandise');
      if (saved) setMerchList(JSON.parse(saved));
      const savedWa = localStorage.getItem('xablenk_merchandise_whatsapp') || localStorage.getItem('xablenk_whatsapp_number');
      if (savedWa) setMerchandiseWaNumber(savedWa);
    };
    updateData();
    const interval = setInterval(updateData, 1000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    localStorage.setItem('xablenk_cart_items', JSON.stringify(cartItems));
  }, [cartItems]);

  const handleSizeSelect = (itemKey: string, size: string) => {
    setSelectedSizes(prev => ({ ...prev, [itemKey]: size }));
  };

  const handleAddToCartAndOpenModal = (item: MerchandiseItem) => {
    const chosenSize = selectedSizes[item.id] || item.sizes[0] || 'Standard';
    const customNote = customInputValues[item.id] || '';
    const cartId = `${item.id}-${chosenSize}-${customNote}`;
    
    setCartItems(prev => {
      const existing = prev.find(ci => ci.cartId === cartId);
      if (existing) {
        return prev.map(ci => ci.cartId === cartId ? { ...ci, quantity: ci.quantity + 1 } : ci);
      } else {
        return [...prev, { cartId, item, size: chosenSize, quantity: 1, customNote }];
      }
    });

    setNotification(`"${item.name}" (${chosenSize}) ditambahkan ke keranjang!`);
    setTimeout(() => setNotification(null), 2500);
    setIsCartOpen(true);
  };

  const handleUpdateQuantity = (cartId: string, delta: number) => {
    setCartItems(prev => prev.map(ci => {
      if (ci.cartId === cartId) {
        const newQty = ci.quantity + delta;
        return newQty > 0 ? { ...ci, quantity: newQty } : null;
      }
      return ci;
    }).filter(Boolean) as CartItem[]);
  };

  const handleRemoveCartItem = (cartId: string) => {
    setCartItems(prev => prev.filter(ci => ci.cartId !== cartId));
  };

  const handleCheckoutCartWhatsApp = () => {
    if (cartItems.length === 0) return;
    const whatsappNum = localStorage.getItem('xablenk_merchandise_whatsapp') || localStorage.getItem('xablenk_whatsapp_number') || '6285735007989';
    
    let productDetails = cartItems.map((ci, idx) => 
      `${idx + 1}. *${ci.item.name}*\n   - Ukuran: ${ci.size}${ci.customNote ? `\n   - Catatan: ${ci.customNote}` : ''}\n   - Jumlah: ${ci.quantity} pcs\n   - Harga: ${ci.item.price} per pcs`
    ).join('\n\n');

    const message = encodeURIComponent(
      `*PEMESANAN / CHECKOUT MERCHANDISE - XA-BLENK*\n----------------------------------------\n${productDetails}\n----------------------------------------\nHalo Admin Merchandise XA-BLENK, saya ingin memesan produk di atas. Mohon konfirmasi total pembayaran dan ketersediaannya.`
    );
    window.open(`https://wa.me/${whatsappNum}?text=${message}`, '_blank');
    setIsCartOpen(false);
  };

  const [heroSettings, setHeroSettings] = useState<{ backgroundImage?: string }>(() => {
    const saved = localStorage.getItem('xablenk_hero_settings');
    return saved ? JSON.parse(saved) : { backgroundImage: '' };
  });

  useEffect(() => {
    const interval = setInterval(() => {
      const saved = localStorage.getItem('xablenk_hero_settings');
      if (saved) setHeroSettings(JSON.parse(saved));
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const totalCartCount = cartItems.reduce((acc, ci) => acc + ci.quantity, 0);

  return (
    <section 
      id="merchandise" 
      className="py-24 relative overflow-hidden bg-black-main"
      style={heroSettings.backgroundImage ? {
        backgroundImage: `linear-gradient(to bottom, rgba(5,5,5,0.88), rgba(5,5,5,0.96)), url(${heroSettings.backgroundImage})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center'
      } : {
        backgroundImage: `linear-gradient(to bottom, rgba(5,5,5,0.92), rgba(5,5,5,0.96)), radial-gradient(circle at 50% 30%, rgba(128,0,0,0.25) 0%, rgba(5,5,5,0.95) 70%)`
      }}
    >
      <div className="absolute top-1/2 left-0 w-[400px] h-[400px] bg-[#cc0000]/5 rounded-full blur-[140px] pointer-events-none" />
      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-sm bg-bg-card border border-[#cc0000]/30 text-[#cc0000] text-xs uppercase tracking-widest font-bold mb-3 shadow-[0_0_15px_rgba(204,0,0,0.2)]">
            <Sparkles className="w-3.5 h-3.5" /> E-COMMERCE SHOP / MARKETPLACE
          </div>
          <h2 className="text-3xl md:text-5xl font-black tracking-tight mb-4">
            XA-BLENK <span className="text-[#cc0000]">OFFICIAL STORE</span>
          </h2>
          <p className="text-gray-main text-xs md:text-sm">
            Katalog merchandise resmi. Klik tombol Keranjang pada produk untuk langsung membuka pop-up keranjang belanja.
          </p>
          
          {/* Sub-navigation tabs & Floating Cart Trigger */}
          <div className="flex justify-center flex-wrap gap-3 mt-8">
            <button
              onClick={() => setActiveSubTab('catalog')}
              className={`px-6 py-3 rounded-sm text-xs font-bold uppercase transition-all flex items-center gap-2 ${
                activeSubTab === 'catalog'
                  ? 'bg-[#cc0000] text-white glow-border'
                  : 'bg-bg-card text-gray-main border border-gray-main/30 hover:text-white'
              }`}
            >
              <ShoppingBag className="w-4 h-4" /> Katalog Produk ({merchList.length})
            </button>

            <button
              onClick={() => setIsCartOpen(true)}
              className="px-6 py-3 rounded-sm text-xs font-bold uppercase transition-all flex items-center gap-2 bg-[#cc0000] hover:bg-[#800000] text-white glow-border relative"
            >
              <ShoppingCart className="w-4 h-4" /> Buka Keranjang
              {totalCartCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-white text-[#cc0000] text-[10px] font-black w-5 h-5 rounded-full flex items-center justify-center shadow-md animate-bounce">
                  {totalCartCount}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveSubTab('contact')}
              className={`px-6 py-3 rounded-sm text-xs font-bold uppercase transition-all flex items-center gap-2 ${
                activeSubTab === 'contact'
                  ? 'bg-[#cc0000] text-white glow-border'
                  : 'bg-bg-card text-gray-main border border-gray-main/30 hover:text-white'
              }`}
            >
              <MessageSquare className="w-4 h-4" /> Kontak Admin
            </button>
          </div>
        </div>

        {notification && (
          <div className="fixed bottom-24 right-6 z-50 bg-[#cc0000] text-white px-6 py-3 rounded-sm shadow-2xl flex items-center gap-2 text-xs font-bold uppercase animate-fade-in glow-border">
            <Check className="w-4 h-4" /> {notification}
          </div>
        )}

        {/* SUBTAB 1: CATALOG - SHOPEE E-COMMERCE STYLE GRID */}
        {activeSubTab === 'catalog' && (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 sm:gap-4">
            {merchList.map(item => {
              const currentSize = selectedSizes[item.id] || item.sizes[0] || 'Standard';
              return (
                <div
                  key={item.id}
                  className="bg-bg-card border border-gray-main/20 rounded-sm overflow-hidden flex flex-col justify-between hover:border-[#cc0000] transition-all duration-300 group shadow-md hover:shadow-[0_0_20px_rgba(204,0,0,0.2)]"
                >
                  <div>
                    {/* Square Image Thumbnail */}
                    <div 
                      onClick={() => handleAddToCartAndOpenModal(item)}
                      className="relative aspect-square w-full overflow-hidden bg-black-secondary cursor-pointer"
                      title="Klik untuk tambah ke keranjang"
                    >
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                      <div className="absolute top-2 left-2 flex gap-1">
                        <span className={`px-2 py-0.5 rounded-sm text-[9px] font-bold uppercase tracking-wider ${
                          item.status === 'Ready' ? 'bg-green-600 text-white' : 'bg-yellow-600 text-white'
                        }`}>
                          {item.status}
                        </span>
                      </div>
                      <div className="absolute inset-0 bg-[#cc0000]/10 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <span className="bg-[#cc0000] text-white text-[10px] font-bold uppercase px-2.5 py-1 rounded-sm shadow-lg">
                          + Keranjang
                        </span>
                      </div>
                    </div>

                    <div className="p-3 space-y-2">
                      <h3 className="text-xs font-bold text-white group-hover:text-[#cc0000] transition-colors line-clamp-2 leading-tight">
                        {item.name}
                      </h3>
                      
                      <div className="text-sm font-black text-[#cc0000]">
                        {item.price}
                      </div>

                      {/* Size Selector (Compact) */}
                      <div>
                        <div className="flex flex-wrap gap-1">
                          {item.sizes.slice(0, 4).map(size => (
                            <button
                              key={size}
                              type="button"
                              onClick={() => handleSizeSelect(item.id, size)}
                              className={`px-1.5 py-0.5 rounded text-[10px] font-bold transition-all border ${
                                currentSize === size
                                  ? 'bg-[#cc0000] text-white border-[#cc0000]'
                                  : 'bg-black-main text-gray-main border-gray-main/30 hover:border-white'
                              }`}
                            >
                              {size}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Keranjang Button (Replaced 'Beli') */}
                  <div className="p-3 pt-0 border-t border-gray-main/10 mt-2 flex justify-center items-center">
                    <button
                      onClick={() => handleAddToCartAndOpenModal(item)}
                      className="w-full bg-[#cc0000] hover:bg-[#800000] text-white py-2 rounded-sm text-[10px] font-bold uppercase transition-colors flex items-center justify-center gap-1.5 glow-border shadow-md"
                    >
                      <ShoppingCart className="w-3.5 h-3.5" /> Keranjang
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* SUBTAB 2: KONTAK ADMIN MERCHANDISE */}
        {activeSubTab === 'contact' && (
          <div className="max-w-3xl mx-auto bg-bg-card border border-[#cc0000]/30 rounded-sm p-8 md:p-12 glow-border space-y-8 animate-fade-in">
            <div className="text-center space-y-3">
              <div className="w-16 h-16 bg-[#cc0000]/20 border border-[#cc0000]/50 rounded-full flex items-center justify-center mx-auto text-[#cc0000]">
                <MessageSquare className="w-8 h-8" />
              </div>
              <h3 className="text-2xl md:text-3xl font-black text-white">PUSAT BANTUAN & KONTAK ADMIN MERCHANDISE</h3>
              <p className="text-xs text-gray-main max-w-lg mx-auto">
                Hubungi staf khusus divisi apparel & merchandise XA-BLENK untuk pemesanan khusus, custom uniform crew, atau pengecekan resi pengiriman.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-6 pt-4 border-t border-gray-main/20">
              <div className="bg-black-main p-6 rounded-sm border border-gray-main/20 space-y-3">
                <div className="flex items-center gap-3 text-[#cc0000] font-bold text-sm">
                  <Phone className="w-5 h-5" /> Nomor WhatsApp Resmi
                </div>
                <p className="text-xs text-gray-main">Nomor khusus admin merchandise (berbeda dengan admin sound rental):</p>
                <div className="text-lg font-black text-white font-mono">+{merchandiseWaNumber}</div>
                <a
                  href={`https://wa.me/${merchandiseWaNumber}?text=${encodeURIComponent('Halo Admin Merchandise XA-BLENK, saya ingin bertanya seputar produk merchandise.')}`}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-2 bg-[#cc0000] hover:bg-[#800000] text-white px-4 py-2.5 rounded-sm text-xs font-bold uppercase transition-colors w-full justify-center"
                >
                  <MessageSquare className="w-4 h-4" /> Chat WhatsApp Sekarang
                </a>
              </div>

              <div className="bg-black-main p-6 rounded-sm border border-gray-main/20 space-y-3">
                <div className="flex items-center gap-3 text-[#cc0000] font-bold text-sm">
                  <ShieldCheck className="w-5 h-5" /> Jam Operasional Layanan
                </div>
                <p className="text-xs text-gray-main">Senin s.d. Sabtu: 09.00 - 20.00 WIB</p>
                <p className="text-xs text-gray-main">Minggu / Hari Libur Nasional: Slow Response / Chat Only</p>
                <div className="pt-2 text-[11px] text-green-400 font-bold flex items-center gap-1">
                  <ShieldCheck className="w-4 h-4" /> Transaksi Aman & Terpercaya
                </div>
              </div>
            </div>

            <div className="bg-black-main p-6 rounded-sm border border-gray-main/20 space-y-4">
              <h4 className="font-bold text-sm text-white flex items-center gap-2">
                <HelpCircle className="w-4 h-4 text-[#cc0000]" /> Ketentuan Pemesanan Custom & Grosir
              </h4>
              <ul className="text-xs text-gray-main space-y-2 list-disc list-inside">
                <li>Pemesanan dengan ukuran custom (spesial lingkar dada / panjang) memakan waktu produksi 2-3 hari kerja.</li>
                <li>Untuk pemesanan seragam kru event / kaos komunitas (minimal 12 pcs), dapatkan harga khusus grosir dengan menghubungi admin via WhatsApp di atas.</li>
                <li>Pengiriman seluruh Indonesia menggunakan ekspedisi terpercaya (JNE, J&T, SiCepat) dari Blitar, Jawa Timur.</li>
              </ul>
            </div>
          </div>
        )}

        {/* SHOPPING CART POPUP MODAL (POP-UP KERANJANG BELANJA) */}
        {isCartOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in">
            <div className="bg-bg-card border border-[#cc0000]/50 max-w-xl w-full rounded-sm shadow-2xl relative overflow-hidden glow-border flex flex-col max-h-[85vh]">
              
              {/* Modal Header */}
              <div className="p-5 border-b border-gray-main/20 flex justify-between items-center bg-black-secondary">
                <div className="flex items-center gap-2.5">
                  <ShoppingCart className="w-5 h-5 text-[#cc0000]" />
                  <h3 className="text-lg font-black text-white">POP-UP KERANJANG BELANJA</h3>
                </div>
                <button
                  onClick={() => setIsCartOpen(false)}
                  className="bg-black-main text-gray-main hover:text-white p-2 rounded-full hover:bg-[#cc0000] transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Modal Body / Cart Items */}
              <div className="p-6 overflow-y-auto flex-1 space-y-4">
                {cartItems.length === 0 ? (
                  <div className="text-center py-12 space-y-3">
                    <ShoppingCart className="w-12 h-12 text-gray-600 mx-auto" />
                    <p className="text-xs font-bold text-gray-main">Keranjang belanja Anda masih kosong.</p>
                    <p className="text-[11px] text-gray-500">Klik tombol "Keranjang" pada produk apa saja untuk memasukkannya ke sini.</p>
                  </div>
                ) : (
                  <div className="divide-y divide-gray-main/15">
                    {cartItems.map((ci) => (
                      <div key={ci.cartId} className="py-3 flex items-center justify-between gap-3">
                        <div className="flex items-center gap-3">
                          <img src={ci.item.image} alt={ci.item.name} className="w-12 h-12 object-cover rounded-sm border border-gray-main/20" />
                          <div>
                            <h4 className="font-bold text-xs text-white line-clamp-1">{ci.item.name}</h4>
                            <p className="text-[11px] text-[#cc0000] font-black">{ci.item.price}</p>
                            <p className="text-[10px] text-gray-main">Ukuran: <span className="text-white">{ci.size}</span></p>
                          </div>
                        </div>

                        <div className="flex items-center gap-3">
                          <div className="flex items-center border border-gray-main/30 rounded-sm bg-black-main">
                            <button
                              onClick={() => handleUpdateQuantity(ci.cartId, -1)}
                              className="p-1 text-gray-main hover:text-white"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="px-2.5 text-xs font-bold text-white">{ci.quantity}</span>
                            <button
                              onClick={() => handleUpdateQuantity(ci.cartId, 1)}
                              className="p-1 text-gray-main hover:text-white"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>

                          <button
                            onClick={() => handleRemoveCartItem(ci.cartId)}
                            className="p-1.5 text-red-400 hover:text-white hover:bg-red-600/20 rounded transition-colors"
                            title="Hapus"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Modal Footer (Tambah Barang Lainnya & Checkout WA Admin) */}
              <div className="p-5 border-t border-gray-main/20 bg-black-secondary space-y-3">
                <div className="flex items-center justify-between text-xs font-bold text-gray-main">
                  <span>Total Produk di Keranjang:</span>
                  <span className="text-white font-black">{totalCartCount} Item</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <button
                    onClick={() => setIsCartOpen(false)}
                    className="bg-black-main hover:bg-gray-800 text-white border border-gray-main/30 py-3 rounded-sm text-xs font-bold uppercase transition-colors flex items-center justify-center gap-1.5"
                  >
                    <Plus className="w-4 h-4 text-[#cc0000]" /> Tambah Barang Lainnya
                  </button>

                  <button
                    onClick={handleCheckoutCartWhatsApp}
                    disabled={cartItems.length === 0}
                    className={`py-3 rounded-sm text-xs font-black uppercase tracking-wider transition-all duration-300 flex items-center justify-center gap-2 glow-border ${
                      cartItems.length === 0
                        ? 'bg-gray-800 text-gray-500 cursor-not-allowed border border-gray-700'
                        : 'bg-[#cc0000] hover:bg-[#800000] text-white shadow-xl'
                    }`}
                  >
                    <MessageSquare className="w-4 h-4" /> Checkout / Hubungi Admin WA <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

            </div>
          </div>
        )}

      </div>
    </section>
  );
}
