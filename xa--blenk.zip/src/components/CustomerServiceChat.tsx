import { useState, useEffect, useRef } from 'react';
import { MessageSquare, Send, X, User, Sparkles, ExternalLink, RefreshCw } from 'lucide-react';
import SarahAvatar from './SarahAvatar';

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  redirectToAdmin?: boolean;
}

export default function CustomerServiceChat() {
  const [isOpen, setIsOpen] = useState(false);
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [whatsappNumber, setWhatsappNumber] = useState<string>(() => {
    return localStorage.getItem('xablenk_whatsapp_number') || '6285735007989';
  });

  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    const saved = sessionStorage.getItem('xablenk_chat_history');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          // Filter out any stale generic error messages
          const cleaned = parsed.filter(
            (m: ChatMessage) =>
              !m.content?.includes('terputus sebentar') &&
              !m.content?.includes('ngadat sedikit') &&
              !m.content?.includes('terhenti sebentar')
          );
          if (cleaned.length > 0) return cleaned;
        }
      } catch {}
    }
    return [
      {
        id: 'msg-welcome',
        role: 'assistant',
        content: 'Halo kak! Kenalin aku Sarah dari Customer Service XA-BLENK Event Production 😊 Ada yang bisa Sarah bantu untuk kebutuhan event kakak? Mau tanya paket sound, lighting, videotron, panggung rigging, atau mau cek tanggal kosong? Boleh banget tanyain langsung ke Sarah yaa!',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ];
  });

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Auto-focus input when chat is opened
  useEffect(() => {
    if (isOpen) {
      const timer = setTimeout(() => {
        inputRef.current?.focus();
      }, 150);
      return () => clearTimeout(timer);
    }
  }, [isOpen]);

  // Sync WhatsApp number from settings
  useEffect(() => {
    const interval = setInterval(() => {
      const num = localStorage.getItem('xablenk_whatsapp_number');
      if (num && num !== whatsappNumber) {
        setWhatsappNumber(num);
      }
    }, 2000);
    return () => clearInterval(interval);
  }, [whatsappNumber]);

  // Save chat to session
  useEffect(() => {
    sessionStorage.setItem('xablenk_chat_history', JSON.stringify(messages));
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isOpen]);

  const handleSendMessage = async (textToSend?: string) => {
    const msg = (textToSend || inputMessage).trim();
    if (!msg || isLoading) return;

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      role: 'user',
      content: msg,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInputMessage('');
    setIsLoading(true);

    try {
      const historyPayload = messages.slice(-5).map(m => ({
        role: m.role,
        content: m.content
      }));

      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: msg,
          history: historyPayload,
          whatsappNumber
        })
      });

      const data = await response.json();
      const aiReply = data.reply || 'Halo kak! Boleh langsung lanjut chat Sarah di WhatsApp yaa 😊';

      const assistantMsg: ChatMessage = {
        id: `msg-${Date.now()}-ai`,
        role: 'assistant',
        content: aiReply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        redirectToAdmin: data.redirectToAdmin || aiReply.includes('wa.me') || aiReply.includes('WhatsApp')
      };

      setMessages(prev => [...prev, assistantMsg]);
    } catch (err) {
      console.error('Chat error:', err);
      // Client-side smart fallback so chat NEVER fails
      let clientFallback = 'Halo kak! Mengenai kebutuhan acara kakak, Sarah dan seluruh tim XA-BLENK siap siapkan sound system, lighting show, videotron LED, hingga panggung rigging yang terbaik 😊 Mau tanya paket apa nih kak?';
      const q = msg.toLowerCase();
      if (
        q.includes('jorok') || q.includes('mesum') || q.includes('bokep') || q.includes('porno') ||
        q.includes('sex') || q.includes('bugil') || q.includes('telanjang') || q.includes('kontol') ||
        q.includes('memek') || q.includes('toket') || q.includes('tete') || q.includes('ngentot')
      ) {
        clientFallback = 'Aduh kak, jangan jorok gitu dong ah haha 🙈 Nanti Sarah jewer lho wkwk. Sarah kan cewek baik-baik yang kerja profesional di kantor XA-BLENK! Mending kita bahas sound system konser, lighting show, atau panggung acara aja yuk! 😊';
      } else if (q.includes('pacar') || q.includes('jodoh') || q.includes('cinta') || q.includes('nikah') || q.includes('jomblo') || q.includes('gombal') || q.includes('cantik')) {
        clientFallback = 'Hehe Sarah masih jomblo santuy nih kak 😆 Masih setia pacaran sama jadwal event dan gulungan kabel sound di kantor XA-BLENK wkwk. Biar subwoofer 18 inch aja yang bikin dada jedag-jedug, jangan janji manis buaya darat! Mau bikin acara apa nih kak? ✨';
      } else if (q.includes('bercanda') || q.includes('joke') || q.includes('lucu') || q.includes('tebak') || q.includes('humor')) {
        clientFallback = 'Haha Sarah ada tebakan nih kak 😆: Sound system kalau lagi jatuh cinta jadi apa hayo? ... Jawabannya: Jadi bikin hati jedag-jedug kayak dentuman subwoofer 18 inch! Wkwk receh banget ya 🙈';
      } else if (q.includes('jadwal') || q.includes('tanggal') || q.includes('kosong')) {
        clientFallback = 'Untuk cek jadwal kosong, armada sound & lighting XA-BLENK saat ini siap melayani di luar tanggal konser yang sudah ter-booking (25 & 28 Oktober 2026). Tanggal acara kakak di tanggal berapa nih? Kasih tahu Sarah ya kak! 😊';
      } else if (q.includes('sound') || q.includes('audio') || q.includes('speaker')) {
        clientFallback = 'Untuk sound system resmi XA-BLENK, kami ada Paket Audio Basic (indoor/akustik) dan Paket Audio Concert Pro (outdoor Line Array megah). Mau dipakai buat acara indoor atau outdoor kak? 😊';
      } else if (q.includes('harga') || q.includes('biaya') || q.includes('sewa')) {
        clientFallback = `Untuk estimasi harga sewa, Sarah bisa bantu buatkan rincian proposal penawaran resmi ya kak! Boleh langsung hubungi Sarah via WhatsApp di https://wa.me/${whatsappNumber} 🙏✨`;
      } else if (q.includes('cewek') || q.includes('robot') || q.includes('ai') || q.includes('siapa')) {
        clientFallback = 'Bukan robot kok kak haha 😆 Aku Sarah beneran, admin Customer Service cewek XA-BLENK yang lagi stand by live chat. Mau tanya-tanya paket apa nih kak? 😊';
      }

      setMessages(prev => [
        ...prev,
        {
          id: `msg-${Date.now()}-resp`,
          role: 'assistant',
          content: clientFallback,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          redirectToAdmin: clientFallback.includes('wa.me')
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleClearChat = () => {
    const initial: ChatMessage[] = [
      {
        id: `msg-${Date.now()}`,
        role: 'assistant',
        content: 'Obrolan sudah Sarah bersihkan ya kak 😊 Silakan kalau ada yang mau ditanyakan lagi ke Sarah terkait jadwal atau paket sewa!',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ];
    setMessages(initial);
    sessionStorage.setItem('xablenk_chat_history', JSON.stringify(initial));
  };

  const quickPrompts = [
    'Ada jadwal kosong?',
    'Paket sound konser',
    'Sarah udah punya pacar? 😆',
    'Lighting & Videotron',
    'Bisa nego harga?'
  ];

  return (
    <>
      {/* Floating Toggle Button */}
      <div className="fixed bottom-20 lg:bottom-6 left-6 z-40 flex items-center gap-3">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="relative bg-gradient-to-r from-[#cc0000] to-[#800000] text-white p-1 rounded-full shadow-2xl hover:scale-105 active:scale-95 transition-all duration-300 border-2 border-[#ff4d4d]/60 flex items-center justify-center group glow-border"
          title="Tanya Admin Sarah"
        >
          {isOpen ? (
            <div className="w-11 h-11 flex items-center justify-center">
              <X className="w-6 h-6" />
            </div>
          ) : (
            <div className="relative">
              <SarahAvatar className="w-11 h-11 rounded-full shadow-inner" />
              <span className="absolute -top-1 -right-1 flex h-3.5 w-3.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-emerald-500 border-2 border-black"></span>
              </span>
            </div>
          )}
        </button>

        {!isOpen && (
          <button
            onClick={() => setIsOpen(true)}
            className="flex items-center gap-2.5 bg-black/90 backdrop-blur-md border border-[#cc0000]/50 hover:border-[#ff4d4d] px-3.5 py-1.5 rounded-full text-xs font-mono tracking-wide text-white transition-all shadow-[0_4px_20px_rgba(204,0,0,0.3)] hover:scale-105 group"
          >
            <SarahAvatar className="w-6 h-6 rounded-full border border-[#cc0000]/60 ring-1 ring-[#cc0000]/30 shadow-sm shrink-0" />
            <div className="flex flex-col text-left leading-tight">
              <span className="font-bold text-white text-xs group-hover:text-[#ff4d4d] transition-colors">Tanya Admin Sarah</span>
              <span className="text-[9px] text-gray-400 font-sans flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                Online CS 24/7
              </span>
            </div>
          </button>
        )}
      </div>

      {/* Chat Window Modal */}
      {isOpen && (
        <div className="fixed bottom-24 lg:bottom-20 left-4 sm:left-6 z-50 w-[calc(100vw-32px)] sm:w-[380px] md:w-[420px] h-[520px] max-h-[80vh] bg-[#0c0c0c] border border-[#cc0000]/50 rounded-lg shadow-2xl flex flex-col overflow-hidden animate-in fade-in slide-in-from-bottom-5 duration-300">
          
          {/* Header */}
          <div className="bg-gradient-to-r from-[#170000] via-[#240000] to-[#0c0c0c] border-b border-[#cc0000]/30 p-3.5 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="relative">
                <SarahAvatar className="w-10 h-10 rounded-full border-2 border-[#cc0000] shadow-md" />
                <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-emerald-500 border-2 border-black animate-pulse"></span>
              </div>
              <div>
                <h3 className="text-xs font-bold text-white flex items-center gap-1.5 font-mono">
                  Admin Sarah
                  <span className="text-[9px] bg-[#cc0000]/20 text-[#ff4d4d] px-1.5 py-0.2 rounded border border-[#cc0000]/40 font-sans">
                    CS RESMI
                  </span>
                </h3>
                <div className="flex items-center gap-1.5 text-[10px] text-gray-400">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                  <span className="text-emerald-400 font-medium">Sedang Online</span>
                  <span className="text-gray-500">•</span>
                  <span>Balas Cepat</span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-1">
              <button
                onClick={handleClearChat}
                className="p-1.5 text-gray-400 hover:text-white rounded hover:bg-white/5 transition-colors"
                title="Reset Obrolan"
              >
                <RefreshCw className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setIsOpen(false)}
                className="p-1.5 text-gray-400 hover:text-white rounded hover:bg-white/5 transition-colors"
                title="Tutup Chat"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Quick Prompts Bar */}
          <div className="bg-[#141414] border-b border-white/5 p-2 flex gap-1.5 overflow-x-auto scrollbar-none text-[10px]">
            {quickPrompts.map((prompt, idx) => (
              <button
                key={idx}
                onClick={() => handleSendMessage(prompt)}
                disabled={isLoading}
                className="whitespace-nowrap bg-black/50 hover:bg-[#cc0000]/20 text-gray-300 hover:text-white px-2.5 py-1 rounded border border-white/10 hover:border-[#cc0000]/40 transition-colors"
              >
                {prompt}
              </button>
            ))}
          </div>

          {/* Messages Area */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3.5 bg-gradient-to-b from-[#0a0a0a] to-[#070707] text-xs">
            {messages.map((m) => (
              <div
                key={m.id}
                className={`flex gap-2.5 ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                {m.role === 'assistant' && (
                  <div className="shrink-0 mt-0.5">
                    <SarahAvatar className="w-6 h-6 rounded-full border border-[#cc0000]/60 shadow-sm" />
                  </div>
                )}

                <div className={`max-w-[85%] rounded-lg p-3 ${
                  m.role === 'user'
                    ? 'bg-[#cc0000] text-white rounded-br-none shadow-md'
                    : 'bg-[#181818] border border-white/10 text-gray-200 rounded-bl-none'
                }`}>
                  <p className="whitespace-pre-line leading-relaxed">{m.content}</p>

                  {/* Direct WhatsApp Action if suggested */}
                  {m.redirectToAdmin && (
                    <div className="mt-2.5 pt-2 border-t border-white/10">
                      <a
                        href={`https://wa.me/${whatsappNumber}?text=${encodeURIComponent('Halo Admin Sarah & Tim XA-BLENK, saya ingin bertanya lebih lanjut terkait pemesanan event.')}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white px-3 py-1.5 rounded text-[11px] font-bold transition-colors w-full justify-center shadow"
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                        Chat Admin via WhatsApp
                        <ExternalLink className="w-3 h-3 ml-0.5" />
                      </a>
                    </div>
                  )}

                  <span className={`block text-[9px] mt-1 text-right ${
                    m.role === 'user' ? 'text-white/70' : 'text-gray-500'
                  }`}>
                    {m.timestamp}
                  </span>
                </div>

                {m.role === 'user' && (
                  <div className="w-6 h-6 rounded-full bg-neutral-800 border border-neutral-700 flex items-center justify-center shrink-0 text-white mt-1">
                    <User className="w-3.5 h-3.5" />
                  </div>
                )}
              </div>
            ))}

            {isLoading && (
              <div className="flex gap-2.5 items-center">
                <div className="shrink-0">
                  <SarahAvatar className="w-6 h-6 rounded-full border border-[#cc0000]/60 shadow-sm animate-pulse" />
                </div>
                <div className="bg-[#181818] border border-white/10 rounded-lg p-2.5 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-[#cc0000] animate-bounce"></span>
                  <span className="w-2 h-2 rounded-full bg-[#cc0000] animate-bounce [animation-delay:0.2s]"></span>
                  <span className="w-2 h-2 rounded-full bg-[#cc0000] animate-bounce [animation-delay:0.4s]"></span>
                  <span className="text-[10px] text-gray-400 ml-1">Sarah sedang mengetik...</span>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Input Box */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="p-2.5 bg-[#121212] border-t border-white/10 flex items-center gap-2"
          >
            <input
              ref={inputRef}
              type="text"
              placeholder="Tanya Sarah di sini kak (cth: jadwal kosong bulan depan)..."
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              disabled={isLoading}
              className="flex-1 bg-black/60 border border-white/15 focus:border-[#cc0000] rounded px-3 py-2 text-xs text-white placeholder-gray-500 focus:outline-none"
            />
            <button
              type="submit"
              disabled={isLoading || !inputMessage.trim()}
              className="bg-[#cc0000] hover:bg-[#800000] disabled:bg-gray-800 disabled:text-gray-600 text-white p-2 rounded transition-colors"
              title="Kirim ke Sarah"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>

        </div>
      )}
    </>
  );
}
