import { useState, useEffect } from 'react';
import { ArrowUp, MessageSquare, Globe, Share2, ExternalLink } from 'lucide-react';
import { SocialLink } from './AdminDashboard';

export default function Footer() {
  const [socials, setSocials] = useState<SocialLink[]>(() => {
    const saved = localStorage.getItem('xablenk_socials');
    return saved ? JSON.parse(saved) : [
      { id: 's1', name: 'Instagram', url: 'https://instagram.com/xablenk_audio', icon: 'instagram' },
      { id: 's2', name: 'Facebook', url: 'https://facebook.com', icon: 'facebook' },
      { id: 's3', name: 'YouTube', url: 'https://youtube.com', icon: 'youtube' },
      { id: 's4', name: 'WhatsApp', url: 'https://whatsapp.com', icon: 'whatsapp' }
    ];
  });

  useEffect(() => {
    const interval = setInterval(() => {
      const savedSocials = localStorage.getItem('xablenk_socials');
      if (savedSocials) setSocials(JSON.parse(savedSocials));
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const getSocialIcon = (icon: SocialLink['icon']) => {
    switch (icon) {
      case 'instagram': return <Share2 className="w-4 h-4" />;
      case 'facebook': return <Globe className="w-4 h-4" />;
      case 'youtube': return <ExternalLink className="w-4 h-4" />;
      case 'whatsapp': return <MessageSquare className="w-4 h-4" />;
      case 'github': return <Globe className="w-4 h-4" />;
      case 'twitter': return <Share2 className="w-4 h-4" />;
      default: return <Globe className="w-4 h-4" />;
    }
  };

  return (
    <footer className="bg-black-main border-t border-gray-main/20 py-16 text-gray-main text-sm">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-4 gap-10 mb-12">
          <div>
            <div className="text-2xl font-bold tracking-tighter text-white mb-4 flex items-center gap-2">
              XA-<span className="text-red-main">BLENK</span>
            </div>
            <p className="text-xs leading-relaxed text-gray-main mb-4">
              AUDIO & LIGHTING | Sound System, Lighting, Stage & Event Equipment Management. Garum, Blitar, Jawa Timur.
            </p>
            <p className="text-xs text-red-main font-bold mb-6">
              WhatsApp: 0857-3500-7989
            </p>
            <div className="flex space-x-3 flex-wrap gap-y-2">
              {socials.map(s => (
                <a
                  key={s.id}
                  href={s.url}
                  target="_blank"
                  rel="noreferrer"
                  title={s.name}
                  className="w-9 h-9 bg-bg-card border border-gray-main/20 flex items-center justify-center rounded-sm text-white hover:bg-red-main hover:border-red-main transition-colors"
                >
                  {getSocialIcon(s.icon)}
                </a>
              ))}
            </div>
          </div>
          <div>
            <h4 className="text-white font-bold uppercase text-xs tracking-widest mb-4">Navigasi Cepat</h4>
            <ul className="space-y-2 text-xs">
              <li><a href="#beranda" className="hover:text-red-main transition-colors">Beranda</a></li>
              <li><a href="#layanan" className="hover:text-red-main transition-colors">Layanan Utama</a></li>
              <li><a href="#paket" className="hover:text-red-main transition-colors">Paket Rental</a></li>
              <li><a href="#jadwal" className="hover:text-red-main transition-colors">Jadwal Acara</a></li>
            </ul>
          </div>
          <div>
            <h4 className="text-white font-bold uppercase text-xs tracking-widest mb-4">Layanan Produksi</h4>
            <ul className="space-y-2 text-xs">
              <li><span className="text-gray-main">Audio System & Line Array</span></li>
              <li><span className="text-gray-main">Lighting Moving Head & PAR</span></li>
              <li><span className="text-gray-main">Videotron Indoor / Outdoor</span></li>
              <li><span className="text-gray-main">Rigging & Stage Modular</span></li>
            </ul>
          </div>
          <div>
            <h4 className="text-white font-bold uppercase text-xs tracking-widest mb-4">Alamat & Kontak Resmi</h4>
            <p className="text-xs mb-2 text-gray-main">Jl. Bromo no. 24 - Tawangsari, Garum, Blitar, Jawa Timur</p>
            <p className="text-xs mb-2 text-gray-main">WhatsApp: 0857-3500-7989</p>
            <p className="text-xs mb-4 text-gray-main">Email: xablenk.audio.real@gmail.com</p>
            <button
              onClick={scrollToTop}
              className="bg-bg-card hover:bg-red-main text-white px-4 py-2 rounded-sm text-xs font-bold uppercase border border-gray-main/20 flex items-center gap-2 transition-colors"
            >
              <ArrowUp className="w-3.5 h-3.5" /> Kembali ke Atas
            </button>
          </div>
        </div>
        <div className="border-t border-gray-main/10 pt-8 text-center text-xs text-gray-main">
          &copy; {new Date().getFullYear()} STIGMA NETWORK Develop. All rights reserved. Designed with Dark Industrial & Red Energy theme.
        </div>
      </div>
    </footer>
  );
}
