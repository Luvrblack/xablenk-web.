import { useState, useEffect } from 'react';
import { MessageSquare, CheckCircle, User, MapPin, Phone, Calendar, Clock, Layers, FileText } from 'lucide-react';

export default function BookingForm() {
  const [formData, setFormData] = useState({
    name: '',
    address: '',
    whatsapp: '',
    themeName: '',
    eventDateText: '',
    eventTimeText: '',
    services: [] as string[],
    notes: ''
  });
  const [submitted, setSubmitted] = useState(false);
  const [serviceOptions, setServiceOptions] = useState<string[]>(() => {
    const saved = localStorage.getItem('xablenk_service_options');
    return saved ? JSON.parse(saved) : [
      'Audio System',
      'Lighting System',
      'Videotron',
      'Rigging & Truss',
      'Stage & Backdrop',
      'Full Event Production',
      'Layanan Lainnya'
    ];
  });

  const [heroSettings, setHeroSettings] = useState<{ backgroundImage?: string }>(() => {
    const saved = localStorage.getItem('xablenk_hero_settings');
    return saved ? JSON.parse(saved) : { backgroundImage: '' };
  });

  useEffect(() => {
    const interval = setInterval(() => {
      const saved = localStorage.getItem('xablenk_hero_settings');
      if (saved) setHeroSettings(JSON.parse(saved));
      const savedServices = localStorage.getItem('xablenk_service_options');
      if (savedServices) setServiceOptions(JSON.parse(savedServices));
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleCheckboxChange = (service: string) => {
    setFormData(prev => ({
      ...prev,
      services: prev.services.includes(service)
        ? prev.services.filter(s => s !== service)
        : [...prev.services, service]
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.whatsapp || !formData.themeName) {
      alert('Mohon isi kolom wajib: Nama Pemesan, Nomor WhatsApp, dan Nama Tema Kegiatan.');
      return;
    }

    // Save order to backend database/API
    try {
      await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customerName: formData.name,
          phone: formData.whatsapp,
          address: formData.address,
          themeName: formData.themeName,
          eventDate: formData.eventDateText,
          eventTime: formData.eventTimeText,
          services: formData.services,
          notes: formData.notes
        })
      });
    } catch (err) {
      console.warn('Backend order sync fallback:', err);
    }

    const text = `*PERMINTAAN BOOKING EVENT - XA-BLENK*\n----------------------------------------\n*Nama Pemesan :* ${formData.name}\n*Alamat :* ${formData.address || '-'}\n*No. WhatsApp :* ${formData.whatsapp}\n*Nama Tema Kegiatan :* ${formData.themeName}\n*Hari Tanggal Bulan Acara :* ${formData.eventDateText || '-'}\n*Acara Pukul :* ${formData.eventTimeText || '-'}\n*Pilihan Layanan :* ${formData.services.join(', ') || 'Belum dipilih'}\n*Keterangan :* ${formData.notes || '-'}`;
    const encodedText = encodeURIComponent(text);
    const businessWhatsApp = localStorage.getItem('xablenk_whatsapp_number') || '6285735007989';
    window.open(`https://wa.me/${businessWhatsApp}?text=${encodedText}`, '_blank');
    setSubmitted(true);
  };

  return (
    <section 
      id="kontak" 
      className="py-24 relative overflow-hidden bg-black-secondary"
      style={heroSettings.backgroundImage ? {
        backgroundImage: `linear-gradient(to bottom, rgba(5,5,5,0.88), rgba(5,5,5,0.96)), url(${heroSettings.backgroundImage})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center'
      } : {
        backgroundImage: `linear-gradient(to bottom, rgba(5,5,5,0.92), rgba(5,5,5,0.96)), radial-gradient(circle at 50% 50%, rgba(128,0,0,0.2) 0%, rgba(5,5,5,0.95) 70%)`
      }}
    >
      <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-[#cc0000]/10 rounded-full blur-[150px] pointer-events-none" />
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-3xl mx-auto bg-black/40 backdrop-blur-md border border-[#cc0000]/30 p-8 md:p-12 rounded-sm shadow-2xl glow-border">
          <div className="text-center mb-10">
            <span className="text-[#cc0000] text-xs uppercase tracking-[0.25em] font-bold block mb-3">
              KONSULTASI & PEMESANAN
            </span>
            <h2 className="text-3xl md:text-5xl font-black tracking-tight mb-4">
              BOOKING <span className="text-[#cc0000]">EVENT.</span>
            </h2>
            <p className="text-gray-main text-xs md:text-sm max-w-lg mx-auto">
              Lengkapi formulir ringkas di bawah ini. Permintaan akan langsung terhubung ke WhatsApp official XA-BLENK.
            </p>
          </div>

          {submitted ? (
            <div className="text-center py-12">
              <CheckCircle className="w-16 h-16 text-[#cc0000] mx-auto mb-4 animate-bounce" />
              <h3 className="text-2xl font-bold mb-2 text-white">Formulir Terkirim ke WhatsApp!</h3>
              <p className="text-gray-main text-xs mb-6">
                Silakan lanjutkan percakapan di WhatsApp untuk konfirmasi ketersediaan dan detail penawaran.
              </p>
              <button
                onClick={() => setSubmitted(false)}
                className="bg-[#cc0000] text-white px-6 py-3 rounded-sm font-bold uppercase text-xs hover:bg-[#800000] transition-colors"
              >
                Kirim Permintaan Lain
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs uppercase font-bold text-gray-main mb-2 flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-[#cc0000]" /> Nama Pemesan : *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Nama lengkap Anda..."
                    value={formData.name}
                    onChange={e => setFormData({...formData, name: e.target.value})}
                    className="w-full bg-black-main border border-gray-main/30 rounded-sm px-4 py-3 text-white text-xs md:text-sm focus:border-[#cc0000] outline-none transition-colors"
                  />
                </div>

                <div>
                  <label className="block text-xs uppercase font-bold text-gray-main mb-2 flex items-center gap-1.5">
                    <Phone className="w-3.5 h-3.5 text-[#cc0000]" /> Nomor WhatsApp : *
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder="Contoh: 08123456789..."
                    value={formData.whatsapp}
                    onChange={e => setFormData({...formData, whatsapp: e.target.value})}
                    className="w-full bg-black-main border border-gray-main/30 rounded-sm px-4 py-3 text-white text-xs md:text-sm focus:border-[#cc0000] outline-none transition-colors"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs uppercase font-bold text-gray-main mb-2 flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-[#cc0000]" /> Alamat :
                </label>
                <input
                  type="text"
                  placeholder="Alamat lengkap lokasi acara / penyelenggara..."
                  value={formData.address}
                  onChange={e => setFormData({...formData, address: e.target.value})}
                  className="w-full bg-black-main border border-gray-main/30 rounded-sm px-4 py-3 text-white text-xs md:text-sm focus:border-[#cc0000] outline-none transition-colors"
                />
              </div>

              <div>
                <label className="block text-xs uppercase font-bold text-gray-main mb-2 flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5 text-[#cc0000]" /> Nama Tema Kegiatan : *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Konser Musik Rock Festival / Pernikahan Adat..."
                  value={formData.themeName}
                  onChange={e => setFormData({...formData, themeName: e.target.value})}
                  className="w-full bg-black-main border border-gray-main/30 rounded-sm px-4 py-3 text-white text-xs md:text-sm focus:border-[#cc0000] outline-none transition-colors"
                />
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs uppercase font-bold text-gray-main mb-2 flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-[#cc0000]" /> Hari Tanggal Bulan Acara :
                  </label>
                  <input
                    type="text"
                    placeholder="Contoh: Sabtu, 25 Oktober 2026..."
                    value={formData.eventDateText}
                    onChange={e => setFormData({...formData, eventDateText: e.target.value})}
                    className="w-full bg-black-main border border-gray-main/30 rounded-sm px-4 py-3 text-white text-xs md:text-sm focus:border-[#cc0000] outline-none transition-colors"
                  />
                </div>

                <div>
                  <label className="block text-xs uppercase font-bold text-gray-main mb-2 flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-[#cc0000]" /> Acara Pukul :
                  </label>
                  <input
                    type="text"
                    placeholder="Contoh: 19.00 WIB - Selesai..."
                    value={formData.eventTimeText}
                    onChange={e => setFormData({...formData, eventTimeText: e.target.value})}
                    className="w-full bg-black-main border border-gray-main/30 rounded-sm px-4 py-3 text-white text-xs md:text-sm focus:border-[#cc0000] outline-none transition-colors"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs uppercase font-bold text-gray-main mb-3 flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5 text-[#cc0000]" /> Pilihan Layanan : (Bisa pilih lebih dari satu)
                </label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {serviceOptions.map(service => (
                    <button
                      type="button"
                      key={service}
                      onClick={() => handleCheckboxChange(service)}
                      className={`p-3 rounded-sm text-xs font-bold text-left transition-all border ${
                        formData.services.includes(service)
                          ? 'bg-[#cc0000]/25 border-[#cc0000] text-white shadow-[0_0_15px_rgba(204,0,0,0.3)]'
                          : 'bg-black-main border-gray-main/20 text-gray-main hover:border-gray-main'
                      }`}
                    >
                      {service}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs uppercase font-bold text-gray-main mb-2">Keterangan :</label>
                <textarea
                  rows={4}
                  placeholder="Catatan tambahan, detail panggung, sound setup, atau permintaan khusus..."
                  value={formData.notes}
                  onChange={e => setFormData({...formData, notes: e.target.value})}
                  className="w-full bg-black-main border border-gray-main/30 rounded-sm p-4 text-white text-xs md:text-sm focus:border-[#cc0000] outline-none resize-none transition-colors"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-[#cc0000] hover:bg-[#800000] text-white py-4 rounded-sm font-black uppercase tracking-wider text-xs md:text-sm transition-all duration-300 flex items-center justify-center gap-2 glow-border shadow-xl"
              >
                <MessageSquare className="w-4 h-4" /> Kirim Pemesanan via WhatsApp
              </button>
            </form>
          )}
        </div>
      </div>
    </section>
  );
}
