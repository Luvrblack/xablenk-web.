import { useState, useEffect } from 'react';
import { events, Event } from '../data/events';
import { rentalPackages, RentalPackage } from '../data/packages';
import { portfolioItems, PortfolioItem } from '../data/portfolio';
import { MerchandiseItem, initialMerchandise } from './MerchandiseSection';
import { LogOut, Calendar, Package, Image as ImageIcon, ShoppingBag, Plus, Edit, Trash2, X, Camera, Upload, Link, MessageSquare, Globe, Share2, Bot, ClipboardList, CheckCircle2, AlertTriangle, Key, ExternalLink, ShieldCheck, Eye, EyeOff, Search, Clock, MapPin, User, Phone, RefreshCw } from 'lucide-react';

export interface AdminOrder {
  id: string;
  customerName: string;
  phone: string;
  address: string;
  themeName: string;
  eventDate: string;
  eventTime: string;
  services: string[];
  notes: string;
  status: 'Pending' | 'Dikonfirmasi' | 'Selesai' | 'Dibatalkan';
  createdAt: string;
}

export interface SocialLink {
  id: string;
  name: string;
  url: string;
  icon: 'instagram' | 'facebook' | 'youtube' | 'tiktok' | 'github' | 'twitter' | 'whatsapp' | 'globe';
}

export interface HeroSettings {
  title: string;
  subtitle: string;
  image: string;
  logo: string;
  headerLogo?: string;
  backgroundImage?: string;
}

export interface GallerySettings {
  heading: string;
  subheading: string;
  description: string;
}

export default function AdminDashboard({ onClose }: { onClose: () => void }) {
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(() => {
    return sessionStorage.getItem('xablenk_admin_logged') === 'true';
  });
  const [usernameInput, setUsernameInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [loginError, setLoginError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (usernameInput === 'admin' && passwordInput === 'admin123') {
      setIsLoggedIn(true);
      sessionStorage.setItem('xablenk_admin_logged', 'true');
      setLoginError('');
    } else {
      setLoginError('Username atau Password salah! (Gunakan admin / admin123)');
    }
  };

  const handleLogout = () => {
    sessionStorage.removeItem('xablenk_admin_logged');
    setIsLoggedIn(false);
    window.location.hash = '';
    onClose();
  };

  const [activeTab, setActiveTab] = useState<'events' | 'packages' | 'portfolio' | 'merchandise' | 'whatsapp' | 'hero_socials' | 'orders' | 'ai_settings'>('orders');

  // Orders Management State
  const [ordersList, setOrdersList] = useState<AdminOrder[]>([]);
  const [orderSearch, setOrderSearch] = useState('');
  const [orderStatusFilter, setOrderStatusFilter] = useState<'Semua' | 'Pending' | 'Dikonfirmasi' | 'Selesai' | 'Dibatalkan'>('Semua');
  const [loadingOrders, setLoadingOrders] = useState(false);

  // AI Settings State
  const [aiStatus, setAiStatus] = useState<{
    configured: boolean;
    model: string;
    maskedKey: string;
    status: 'connected' | 'unconfigured' | 'error';
    lastTested?: string;
    lastError?: string;
  }>({
    configured: false,
    model: 'gemini-flash-latest',
    maskedKey: '',
    status: 'unconfigured'
  });
  const [inputApiKey, setInputApiKey] = useState('');
  const [selectedModel, setSelectedModel] = useState('gemini-flash-latest');
  const [showApiKey, setShowApiKey] = useState(false);
  const [aiTesting, setAiTesting] = useState(false);
  const [aiTestResult, setAiTestResult] = useState<{ success?: boolean; message: string } | null>(null);
  const [aiSaveSuccess, setAiSaveSuccess] = useState(false);

  const ADMIN_TOKEN = 'xablenk_admin_secret_token';

  const fetchOrders = async () => {
    setLoadingOrders(true);
    try {
      const res = await fetch('/api/orders');
      if (res.ok) {
        const data = await res.json();
        setOrdersList(data);
      }
    } catch (err) {
      console.error('Failed to fetch orders:', err);
    } finally {
      setLoadingOrders(false);
    }
  };

  const fetchAiStatus = async () => {
    try {
      const res = await fetch('/api/admin/ai/status', {
        headers: { 'x-admin-token': ADMIN_TOKEN }
      });
      if (res.ok) {
        const data = await res.json();
        setAiStatus(data);
        if (data.model) setSelectedModel(data.model);
      }
    } catch (err) {
      console.error('Failed to fetch AI status:', err);
    }
  };

  const handleUpdateOrderStatus = async (id: string, status: AdminOrder['status']) => {
    try {
      const res = await fetch(`/api/orders/${id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-token': ADMIN_TOKEN
        },
        body: JSON.stringify({ status })
      });
      if (res.ok) {
        setOrdersList(prev => prev.map(o => o.id === id ? { ...o, status } : o));
      }
    } catch (err) {
      alert('Gagal memperbarui status pesanan');
    }
  };

  const handleDeleteOrder = async (id: string) => {
    if (!window.confirm('Yakin ingin menghapus pesanan ini?')) return;
    try {
      const res = await fetch(`/api/orders/${id}`, {
        method: 'DELETE',
        headers: { 'x-admin-token': ADMIN_TOKEN }
      });
      if (res.ok) {
        setOrdersList(prev => prev.filter(o => o.id !== id));
      }
    } catch (err) {
      alert('Gagal menghapus pesanan');
    }
  };

  const handleSaveAiConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/admin/ai/config', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-token': ADMIN_TOKEN
        },
        body: JSON.stringify({
          apiKey: inputApiKey ? inputApiKey.trim() : undefined,
          model: selectedModel
        })
      });
      if (res.ok) {
        const data = await res.json();
        setAiStatus(prev => ({
          ...prev,
          configured: true,
          maskedKey: data.maskedKey || prev.maskedKey,
          model: data.model || selectedModel,
          status: data.status || 'connected'
        }));
        setInputApiKey('');
        setAiSaveSuccess(true);
        setTimeout(() => setAiSaveSuccess(false), 3000);
      } else {
        const errData = await res.json();
        alert(errData.error || 'Gagal menyimpan konfigurasi');
      }
    } catch (err) {
      alert('Gagal menghubungi server untuk menyimpan konfigurasi');
    }
  };

  const handleTestAiConnection = async () => {
    setAiTesting(true);
    setAiTestResult(null);
    try {
      const res = await fetch('/api/admin/ai/test', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-token': ADMIN_TOKEN
        },
        body: JSON.stringify({
          apiKey: inputApiKey ? inputApiKey.trim() : undefined,
          model: selectedModel
        })
      });
      const data = await res.json();
      setAiTestResult({
        success: data.success,
        message: data.message || (data.success ? 'Koneksi Berhasil!' : 'Koneksi Gagal')
      });
      fetchAiStatus();
    } catch (err: any) {
      setAiTestResult({
        success: false,
        message: 'Koneksi server gagal atau tidak merespon.'
      });
    } finally {
      setAiTesting(false);
    }
  };

  const handleDeleteAiKey = async () => {
    if (!window.confirm('Yakin ingin menghapus API key dari server? CS AI tidak akan bisa memproses chat jika API key dihapus.')) return;
    try {
      const res = await fetch('/api/admin/ai/config', {
        method: 'DELETE',
        headers: { 'x-admin-token': ADMIN_TOKEN }
      });
      if (res.ok) {
        setAiStatus({
          configured: false,
          model: 'gemini-flash-latest',
          maskedKey: '',
          status: 'unconfigured'
        });
        setInputApiKey('');
        setAiTestResult({ success: true, message: 'API Key berhasil dihapus dari server.' });
      }
    } catch (err) {
      alert('Gagal menghapus API key');
    }
  };

  useEffect(() => {
    if (isLoggedIn) {
      fetchOrders();
      fetchAiStatus();
    }
  }, [isLoggedIn]);

  // Local state for events with automatic 1-month deletion filtering
  const [eventList, setEventList] = useState<Event[]>(() => {
    const saved = localStorage.getItem('xablenk_events');
    const list: Event[] = saved ? JSON.parse(saved) : events;
    const now = Date.now();
    const oneMonthMs = 30 * 24 * 60 * 60 * 1000;
    return list.filter(ev => !ev.timestamp || (now - ev.timestamp < oneMonthMs));
  });

  const [packageList, setPackageList] = useState<RentalPackage[]>(() => {
    const saved = localStorage.getItem('xablenk_packages');
    return saved ? JSON.parse(saved) : rentalPackages;
  });

  const [portfolioList, setPortfolioList] = useState<PortfolioItem[]>(() => {
    const saved = localStorage.getItem('xablenk_portfolio');
    return saved ? JSON.parse(saved) : portfolioItems;
  });

  const [merchList, setMerchList] = useState<MerchandiseItem[]>(() => {
    const saved = localStorage.getItem('xablenk_merchandise');
    return saved ? JSON.parse(saved) : initialMerchandise;
  });

  const [editingMerch, setEditingMerch] = useState<MerchandiseItem | null>(null);
  const [isAddingMerch, setIsAddingMerch] = useState(false);
  const [merchImageInput, setMerchImageInput] = useState('');

  // WhatsApp Number setting
  const [whatsappNumber, setWhatsappNumber] = useState<string>(() => {
    return localStorage.getItem('xablenk_whatsapp_number') || '6285735007989';
  });
  const [merchandiseWhatsapp, setMerchandiseWhatsapp] = useState<string>(() => {
    return localStorage.getItem('xablenk_merchandise_whatsapp') || '6285735007989';
  });
  const [saveWhatsappSuccess, setSaveWhatsappSuccess] = useState(false);

  // Hero Settings
  const [heroSettings, setHeroSettings] = useState<HeroSettings>(() => {
    const saved = localStorage.getItem('xablenk_hero_settings');
    return saved ? JSON.parse(saved) : {
      title: 'BRING THE EVENT TO THE NEXT LEVEL.',
      subtitle: 'Solusi produksi acara profesional melalui layanan audio, lighting, videotron, rigging, dan panggung untuk menghadirkan pengalaman event yang berkesan.',
      image: 'https://images.unsplash.com/photo-1516450360452-9312f5e86578?q=80&w=1000',
      logo: '',
      headerLogo: '',
      backgroundImage: ''
    };
  });
  const [heroImageInput, setHeroImageInput] = useState('');
  const [heroLogoInput, setHeroLogoInput] = useState('');
  const [headerLogoInput, setHeaderLogoInput] = useState('');
  const [bgImageInput, setBgImageInput] = useState('');
  const [saveHeroSuccess, setSaveHeroSuccess] = useState(false);

  // Gallery Settings
  const [gallerySettings, setGallerySettings] = useState<GallerySettings>(() => {
    const saved = localStorage.getItem('xablenk_gallery_settings');
    return saved ? JSON.parse(saved) : {
      heading: 'OUR WORK. OUR ENERGY.',
      subheading: 'PORTFOLIO & DOKUMENTASI',
      description: 'Saksikan galeri pekerjaan nyata produksi panggung, konser, festival, dan event spektakuler bersama XA- BLENK.'
    };
  });
  const [saveGallerySuccess, setSaveGallerySuccess] = useState(false);

  // Social Links
  const [socialLinks, setSocialLinks] = useState<SocialLink[]>(() => {
    const saved = localStorage.getItem('xablenk_socials');
    return saved ? JSON.parse(saved) : [
      { id: 's1', name: 'Instagram', url: 'https://instagram.com/xablenk_audio', icon: 'instagram' },
      { id: 's2', name: 'Facebook', url: 'https://facebook.com', icon: 'facebook' },
      { id: 's3', name: 'YouTube', url: 'https://youtube.com', icon: 'youtube' },
      { id: 's4', name: 'WhatsApp', url: 'https://whatsapp.com', icon: 'whatsapp' }
    ];
  });
  const [newSocialName, setNewSocialName] = useState('');
  const [newSocialUrl, setNewSocialUrl] = useState('');
  const [newSocialIcon, setNewSocialIcon] = useState<SocialLink['icon']>('instagram');

  // Booking Service Options (Dynamic)
  const [serviceOptions, setServiceOptions] = useState<string[]>(() => {
    const saved = localStorage.getItem('xablenk_service_options');
    return saved ? JSON.parse(saved) : [
      'Audio System',
      'Lighting System',
      'Videotron',
      'Rigging & Truss',
      'Stage & Backdrop',
      'Full Event Production',
      'Layanan Lainnya'
    ];
  });
  const [newServiceOption, setNewServiceOption] = useState('');

  // Modal / Form states
  const [editingEvent, setEditingEvent] = useState<Event | null>(null);
  const [isAddingEvent, setIsAddingEvent] = useState(false);
  const [editingPkg, setEditingPkg] = useState<RentalPackage | null>(null);
  const [isAddingPkg, setIsAddingPkg] = useState(false);
  const [pkgImageInput, setPkgImageInput] = useState('');
  const [editingPort, setEditingPort] = useState<PortfolioItem | null>(null);
  const [isAddingPort, setIsAddingPort] = useState(false);
  const [portImageInput, setPortImageInput] = useState('');

  useEffect(() => {
    localStorage.setItem('xablenk_events', JSON.stringify(eventList));
  }, [eventList]);

  useEffect(() => {
    localStorage.setItem('xablenk_packages', JSON.stringify(packageList));
  }, [packageList]);

  useEffect(() => {
    localStorage.setItem('xablenk_portfolio', JSON.stringify(portfolioList));
  }, [portfolioList]);

  useEffect(() => {
    localStorage.setItem('xablenk_merchandise', JSON.stringify(merchList));
  }, [merchList]);

  useEffect(() => {
    localStorage.setItem('xablenk_whatsapp_number', whatsappNumber);
  }, [whatsappNumber]);

  useEffect(() => {
    localStorage.setItem('xablenk_merchandise_whatsapp', merchandiseWhatsapp);
  }, [merchandiseWhatsapp]);

  useEffect(() => {
    localStorage.setItem('xablenk_hero_settings', JSON.stringify(heroSettings));
  }, [heroSettings]);

  useEffect(() => {
    localStorage.setItem('xablenk_gallery_settings', JSON.stringify(gallerySettings));
  }, [gallerySettings]);

  useEffect(() => {
    localStorage.setItem('xablenk_socials', JSON.stringify(socialLinks));
  }, [socialLinks]);

  useEffect(() => {
    localStorage.setItem('xablenk_service_options', JSON.stringify(serviceOptions));
  }, [serviceOptions]);

  const handleImageFileChange = (e: React.ChangeEvent<HTMLInputElement>, setImageState: (val: string) => void) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          setImageState(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // --- EVENTS CRUD ---
  const handleDeleteEvent = (id: string) => {
    if (confirm('Hapus jadwal acara ini?')) {
      setEventList(eventList.filter(ev => ev.id !== id));
    }
  };

  const handleSaveEvent = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const newEvent: Event = {
      id: editingEvent ? editingEvent.id : Date.now().toString(),
      no: formData.get('no') as string || '01',
      name: formData.get('name') as string,
      dateText: formData.get('dateText') as string,
      client: formData.get('client') as string,
      location: formData.get('location') as string,
      timeText: formData.get('timeText') as string,
      keterangan: formData.get('keterangan') as string,
      timestamp: editingEvent?.timestamp || Date.now(),
    };
    if (editingEvent) {
      setEventList(eventList.map(ev => ev.id === editingEvent.id ? newEvent : ev));
      setEditingEvent(null);
    } else {
      setEventList([newEvent, ...eventList]);
      setIsAddingEvent(false);
    }
  };

  // --- PACKAGES CRUD ---
  const handleDeletePkg = (id: string) => {
    if (confirm('Hapus paket rental ini?')) {
      setPackageList(packageList.filter(p => p.id !== id));
    }
  };

  const handleSavePkg = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const newPkg: RentalPackage = {
      id: editingPkg ? editingPkg.id : 'pkg-' + Date.now(),
      category: formData.get('category') as any,
      name: formData.get('name') as string,
      image: pkgImageInput || editingPkg?.image || 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?q=80&w=800',
      description: formData.get('description') as string,
      specs: (formData.get('specs') as string).split(',').map(s => s.trim()),
      priceTag: formData.get('priceTag') as string || 'Hubungi untuk Penawaran'
    };
    if (editingPkg) {
      setPackageList(packageList.map(p => p.id === editingPkg.id ? newPkg : p));
      setEditingPkg(null);
    } else {
      setPackageList([newPkg, ...packageList]);
      setIsAddingPkg(false);
    }
    setPkgImageInput('');
  };

  // --- PORTFOLIO CRUD ---
  const handleDeletePort = (id: string) => {
    if (confirm('Hapus portofolio ini?')) {
      setPortfolioList(portfolioList.filter(item => item.id !== id));
    }
  };

  const handleSavePort = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const newItem: PortfolioItem = {
      id: editingPort ? editingPort.id : 'p-' + Date.now(),
      title: formData.get('title') as string,
      category: formData.get('category') as any,
      image: portImageInput || editingPort?.image || 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?q=80&w=1200',
      location: formData.get('location') as string,
      date: formData.get('date') as string,
      description: formData.get('description') as string
    };
    if (editingPort) {
      setPortfolioList(portfolioList.map(item => item.id === editingPort.id ? newItem : item));
      setEditingPort(null);
    } else {
      setPortfolioList([newItem, ...portfolioList]);
      setIsAddingPort(false);
    }
    setPortImageInput('');
  };

  // --- MERCHANDISE CRUD ---
  const handleDeleteMerch = (id: string) => {
    if (confirm('Hapus produk merchandise ini?')) {
      setMerchList(merchList.filter(m => m.id !== id));
    }
  };

  const handleSaveMerch = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const newMerch: MerchandiseItem = {
      id: editingMerch ? editingMerch.id : 'm-' + Date.now(),
      name: formData.get('name') as string,
      image: merchImageInput || editingMerch?.image || 'https://images.unsplash.com/photo-1556905055-8f358a7a47b2?q=80&w=800',
      price: formData.get('price') as string,
      sizes: (formData.get('sizes') as string).split(',').map(s => s.trim()),
      description: formData.get('description') as string,
      status: formData.get('status') as any
    };
    if (editingMerch) {
      setMerchList(merchList.map(m => m.id === editingMerch.id ? newMerch : m));
      setEditingMerch(null);
    } else {
      setMerchList([newMerch, ...merchList]);
      setIsAddingMerch(false);
    }
    setMerchImageInput('');
  };

  // --- SOCIAL LINKS CRUD ---
  const handleAddSocial = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSocialName || !newSocialUrl) return;
    const newLink: SocialLink = {
      id: 'soc-' + Date.now(),
      name: newSocialName,
      url: newSocialUrl,
      icon: newSocialIcon
    };
    setSocialLinks([...socialLinks, newLink]);
    setNewSocialName('');
    setNewSocialUrl('');
  };

  const handleDeleteSocial = (id: string) => {
    setSocialLinks(socialLinks.filter(s => s.id !== id));
  };

  // --- SERVICE OPTIONS CRUD ---
  const handleAddServiceOption = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newServiceOption.trim()) return;
    if (!serviceOptions.includes(newServiceOption.trim())) {
      setServiceOptions([...serviceOptions, newServiceOption.trim()]);
    }
    setNewServiceOption('');
  };

  const handleDeleteServiceOption = (service: string) => {
    setServiceOptions(serviceOptions.filter(s => s !== service));
  };

  if (!isLoggedIn) {
    return (
      <div className="fixed inset-0 z-50 bg-black-main overflow-y-auto flex items-center justify-center p-4">
        <div className="bg-bg-card border border-[#cc0000]/40 p-8 rounded-sm max-w-md w-full shadow-2xl relative glow-border animate-fade-in">
          <button
            onClick={() => { window.location.hash = ''; onClose(); }}
            className="absolute top-4 right-4 text-gray-main hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
          
          <div className="text-center mb-8">
            <span className="text-[#cc0000] font-mono text-2xl font-black">&lt;/&gt;</span>
            <h2 className="text-xl font-black tracking-wider text-white mt-2">XA-BLENK C-PANEL LOGIN</h2>
            <p className="text-xs text-gray-main mt-1">Masukkan kredensial administrator untuk mengelola konten.</p>
          </div>

          {loginError && (
            <div className="mb-4 p-3 bg-red-900/30 border border-[#cc0000] text-red-300 text-xs rounded-sm">
              {loginError}
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-[10px] uppercase font-bold text-gray-main mb-1">Username</label>
              <input
                type="text"
                required
                value={usernameInput}
                onChange={(e) => setUsernameInput(e.target.value)}
                placeholder="Username (admin)"
                className="w-full bg-black-main border border-gray-main/30 rounded-sm p-3 text-xs text-white focus:border-[#cc0000] outline-none transition-colors"
              />
            </div>
            <div>
              <label className="block text-[10px] uppercase font-bold text-gray-main mb-1">Password</label>
              <input
                type="password"
                required
                value={passwordInput}
                onChange={(e) => setPasswordInput(e.target.value)}
                placeholder="Password (admin123)"
                className="w-full bg-black-main border border-gray-main/30 rounded-sm p-3 text-xs text-white focus:border-[#cc0000] outline-none transition-colors"
              />
            </div>
            <button
              type="submit"
              className="w-full bg-[#cc0000] hover:bg-[#800000] text-white py-3 rounded-sm text-xs font-bold uppercase tracking-wider transition-colors glow-border mt-2"
            >
              Masuk C-Panel
            </button>
          </form>

          <div className="mt-6 pt-4 border-t border-gray-main/10 text-center">
            <button
              onClick={() => { window.location.hash = ''; onClose(); }}
              className="text-xs text-gray-main hover:text-white underline"
            >
              Kembali ke Beranda Website
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 bg-black-main overflow-y-auto flex flex-col animate-fade-in">
      {/* Admin Header */}
      <header className="bg-black-secondary border-b border-gray-main/20 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <span className="text-[#cc0000] font-mono font-black">&lt;/&gt;</span>
          <h1 className="text-lg font-black tracking-wider text-white">XA-BLENK C-PANEL</h1>
          <span className="bg-[#cc0000]/20 text-[#cc0000] text-[10px] uppercase font-bold px-2 py-0.5 border border-[#cc0000]/30">Admin Control Center</span>
        </div>
        <div className="flex items-center gap-4">
          <button
            onClick={() => { window.location.hash = ''; onClose(); }}
            className="text-xs text-gray-main hover:text-white underline"
          >
            Lihat Web
          </button>
          <button
            onClick={handleLogout}
            className="bg-[#cc0000]/20 hover:bg-[#cc0000] text-red-300 hover:text-white px-4 py-2 rounded-sm text-xs font-bold uppercase transition-colors flex items-center gap-1.5"
          >
            <LogOut className="w-3.5 h-3.5" /> Keluar C-Panel
          </button>
        </div>
      </header>

      {/* Admin Body */}
      <div className="flex-1 flex flex-col md:flex-row">
        {/* Sidebar */}
        <aside className="w-full md:w-64 bg-bg-card border-r border-gray-main/10 p-6 space-y-2">
          <button
            onClick={() => { setActiveTab('orders'); fetchOrders(); }}
            className={`w-full flex items-center justify-between px-4 py-3 rounded-sm text-xs font-bold uppercase transition-colors ${
              activeTab === 'orders' ? 'bg-[#cc0000] text-white glow-border' : 'text-gray-main hover:text-white hover:bg-black-main'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <ClipboardList className="w-4 h-4 text-[#ff4d4d]" />
              <span>Manajemen Pesanan</span>
            </div>
            {ordersList.filter(o => o.status === 'Pending').length > 0 && (
              <span className="bg-amber-500 text-black text-[10px] px-2 py-0.5 rounded-full font-black">
                {ordersList.filter(o => o.status === 'Pending').length}
              </span>
            )}
          </button>

          <button
            onClick={() => { setActiveTab('ai_settings'); fetchAiStatus(); }}
            className={`w-full flex items-center justify-between px-4 py-3 rounded-sm text-xs font-bold uppercase transition-colors ${
              activeTab === 'ai_settings' ? 'bg-[#cc0000] text-white glow-border' : 'text-gray-main hover:text-white hover:bg-black-main'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <Bot className="w-4 h-4 text-[#ff4d4d]" />
              <span>Pengaturan AI Gemini</span>
            </div>
            <span
              className={`w-2 h-2 rounded-full ${
                aiStatus.status === 'connected'
                  ? 'bg-emerald-500'
                  : aiStatus.status === 'error'
                  ? 'bg-rose-500'
                  : 'bg-amber-500'
              }`}
              title={`Status AI: ${aiStatus.status}`}
            />
          </button>

          <div className="pt-2 pb-1 border-t border-gray-main/10 text-[10px] font-mono text-gray-500 uppercase px-1">
            Konten Website
          </div>

          <button
            onClick={() => setActiveTab('hero_socials')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-sm text-xs font-bold uppercase transition-colors ${
              activeTab === 'hero_socials' ? 'bg-[#cc0000] text-white glow-border' : 'text-gray-main hover:text-white hover:bg-black-main'
            }`}
          >
            <Globe className="w-4 h-4" /> Beranda & Medsos & BG
          </button>
          <button
            onClick={() => setActiveTab('packages')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-sm text-xs font-bold uppercase transition-colors ${
              activeTab === 'packages' ? 'bg-[#cc0000] text-white glow-border' : 'text-gray-main hover:text-white hover:bg-black-main'
            }`}
          >
            <Package className="w-4 h-4" /> Paket Rental
          </button>
          <button
            onClick={() => setActiveTab('events')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-sm text-xs font-bold uppercase transition-colors ${
              activeTab === 'events' ? 'bg-[#cc0000] text-white glow-border' : 'text-gray-main hover:text-white hover:bg-black-main'
            }`}
          >
            <Calendar className="w-4 h-4" /> Kelola Jadwal
          </button>
          <button
            onClick={() => setActiveTab('merchandise')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-sm text-xs font-bold uppercase transition-colors ${
              activeTab === 'merchandise' ? 'bg-[#cc0000] text-white glow-border' : 'text-gray-main hover:text-white hover:bg-black-main'
            }`}
          >
            <ShoppingBag className="w-4 h-4" /> Merchandise
          </button>
          <button
            onClick={() => setActiveTab('portfolio')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-sm text-xs font-bold uppercase transition-colors ${
              activeTab === 'portfolio' ? 'bg-[#cc0000] text-white glow-border' : 'text-gray-main hover:text-white hover:bg-black-main'
            }`}
          >
            <ImageIcon className="w-4 h-4" /> Galeri
          </button>
          <button
            onClick={() => setActiveTab('whatsapp')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-sm text-xs font-bold uppercase transition-colors ${
              activeTab === 'whatsapp' ? 'bg-[#cc0000] text-white glow-border' : 'text-gray-main hover:text-white hover:bg-black-main'
            }`}
          >
            <MessageSquare className="w-4 h-4" /> No WhatsApp
          </button>
        </aside>

        {/* Main Content Area */}
        <main className="flex-1 p-6 md:p-10 bg-black-main overflow-y-auto">

          {/* TAB: MANAJEMEN PESANAN (ORDERS) */}
          {activeTab === 'orders' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-gray-main/20 pb-6">
                <div>
                  <h2 className="text-2xl font-black text-white flex items-center gap-2.5">
                    <ClipboardList className="w-6 h-6 text-[#cc0000]" />
                    Manajemen Pesanan Masuk
                  </h2>
                  <p className="text-xs text-gray-main mt-1">
                    Daftar pemesanan event yang diajukan pelanggan melalui formulir website dan terintegrasi dengan WhatsApp.
                  </p>
                </div>
                <button
                  onClick={fetchOrders}
                  disabled={loadingOrders}
                  className="bg-black-secondary hover:bg-neutral-800 border border-gray-main/30 text-white px-4 py-2 rounded-sm text-xs font-bold uppercase transition-colors flex items-center gap-2"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${loadingOrders ? 'animate-spin' : ''}`} />
                  Segarkan Data
                </button>
              </div>

              {/* Statistics Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-bg-card border border-white/10 p-4 rounded-sm">
                  <span className="text-[10px] text-gray-main uppercase font-bold block">Total Pesanan</span>
                  <span className="text-2xl font-black text-white">{ordersList.length}</span>
                </div>
                <div className="bg-bg-card border border-amber-500/30 p-4 rounded-sm">
                  <span className="text-[10px] text-amber-400 uppercase font-bold block">Menunggu Konfirmasi</span>
                  <span className="text-2xl font-black text-amber-400">
                    {ordersList.filter(o => o.status === 'Pending').length}
                  </span>
                </div>
                <div className="bg-bg-card border border-emerald-500/30 p-4 rounded-sm">
                  <span className="text-[10px] text-emerald-400 uppercase font-bold block">Dikonfirmasi</span>
                  <span className="text-2xl font-black text-emerald-400">
                    {ordersList.filter(o => o.status === 'Dikonfirmasi').length}
                  </span>
                </div>
                <div className="bg-bg-card border border-blue-500/30 p-4 rounded-sm">
                  <span className="text-[10px] text-blue-400 uppercase font-bold block">Selesai</span>
                  <span className="text-2xl font-black text-blue-400">
                    {ordersList.filter(o => o.status === 'Selesai').length}
                  </span>
                </div>
              </div>

              {/* Search & Filter Bar */}
              <div className="flex flex-col sm:flex-row gap-3 bg-bg-card p-3 rounded-sm border border-white/10">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 absolute left-3 top-3 text-gray-500" />
                  <input
                    type="text"
                    placeholder="Cari nama pemesan, no HP, atau tema acara..."
                    value={orderSearch}
                    onChange={e => setOrderSearch(e.target.value)}
                    className="w-full bg-black-main border border-white/10 focus:border-[#cc0000] rounded-sm pl-9 pr-3 py-2 text-xs text-white outline-none"
                  />
                </div>
                <div className="flex gap-1.5 overflow-x-auto pb-1 sm:pb-0 text-xs font-bold">
                  {(['Semua', 'Pending', 'Dikonfirmasi', 'Selesai', 'Dibatalkan'] as const).map(st => (
                    <button
                      key={st}
                      onClick={() => setOrderStatusFilter(st)}
                      className={`px-3 py-1.5 rounded-sm whitespace-nowrap transition-colors ${
                        orderStatusFilter === st
                          ? 'bg-[#cc0000] text-white'
                          : 'bg-black-main text-gray-400 hover:text-white'
                      }`}
                    >
                      {st}
                    </button>
                  ))}
                </div>
              </div>

              {/* Orders List */}
              <div className="space-y-4">
                {ordersList
                  .filter(o => {
                    if (orderStatusFilter !== 'Semua' && o.status !== orderStatusFilter) return false;
                    if (!orderSearch) return true;
                    const q = orderSearch.toLowerCase();
                    return (
                      o.customerName?.toLowerCase().includes(q) ||
                      o.phone?.includes(q) ||
                      o.themeName?.toLowerCase().includes(q) ||
                      o.address?.toLowerCase().includes(q)
                    );
                  })
                  .map(order => {
                    const cleanPhone = (order.phone || '').replace(/\D/g, '');
                    const waPhone = cleanPhone.startsWith('0') ? '62' + cleanPhone.slice(1) : cleanPhone;
                    const waText = encodeURIComponent(
                      `Halo ${order.customerName}, kami dari Official Admin XA-BLENK Event Production ingin mengonfirmasi detail pemesanan Anda untuk acara "${order.themeName}" pada tanggal ${order.eventDate}. Apakah jadwal dan kebutuhan alat sudah sesuai?`
                    );

                    return (
                      <div
                        key={order.id}
                        className="bg-bg-card border border-white/10 p-5 rounded-sm shadow-md hover:border-[#cc0000]/40 transition-colors"
                      >
                        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-white/5 pb-3 mb-3">
                          <div className="flex items-center gap-3">
                            <span className="font-mono text-xs font-bold text-[#cc0000] bg-[#cc0000]/10 px-2.5 py-1 rounded border border-[#cc0000]/30">
                              {order.id}
                            </span>
                            <span className="text-xs text-gray-400 font-mono">
                              Dibuat: {new Date(order.createdAt).toLocaleDateString('id-ID', { dateStyle: 'medium' })}
                            </span>
                          </div>

                          <div className="flex items-center gap-2">
                            <span
                              className={`text-[11px] font-bold uppercase px-3 py-1 rounded border ${
                                order.status === 'Pending'
                                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                                  : order.status === 'Dikonfirmasi'
                                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                                  : order.status === 'Selesai'
                                  ? 'bg-blue-500/20 text-blue-300 border-blue-500/40'
                                  : 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                              }`}
                            >
                              Status: {order.status}
                            </span>
                          </div>
                        </div>

                        {/* Order Details Grid */}
                        <div className="grid md:grid-cols-2 gap-4 text-xs">
                          <div className="space-y-2">
                            <div className="flex items-center gap-2">
                              <User className="w-3.5 h-3.5 text-[#cc0000]" />
                              <span className="text-gray-400">Pemesan:</span>
                              <strong className="text-white text-sm">{order.customerName}</strong>
                            </div>
                            <div className="flex items-center gap-2">
                              <Phone className="w-3.5 h-3.5 text-[#cc0000]" />
                              <span className="text-gray-400">WhatsApp:</span>
                              <span className="text-white font-mono">{order.phone}</span>
                            </div>
                            <div className="flex items-start gap-2">
                              <MapPin className="w-3.5 h-3.5 text-[#cc0000] shrink-0 mt-0.5" />
                              <span className="text-gray-400">Alamat:</span>
                              <span className="text-gray-200">{order.address || '-'}</span>
                            </div>
                          </div>

                          <div className="space-y-2">
                            <div className="flex items-center gap-2">
                              <Calendar className="w-3.5 h-3.5 text-[#cc0000]" />
                              <span className="text-gray-400">Tema Kegiatan:</span>
                              <strong className="text-white">{order.themeName}</strong>
                            </div>
                            <div className="flex items-center gap-2">
                              <Clock className="w-3.5 h-3.5 text-[#cc0000]" />
                              <span className="text-gray-400">Jadwal Acara:</span>
                              <span className="text-gray-200 font-mono">
                                {order.eventDate || '-'} ({order.eventTime || '-'})
                              </span>
                            </div>
                            <div>
                              <span className="text-gray-400 block mb-1">Layanan Terpilih:</span>
                              <div className="flex flex-wrap gap-1.5">
                                {order.services && order.services.length > 0 ? (
                                  order.services.map((srv, idx) => (
                                    <span
                                      key={idx}
                                      className="bg-black-main border border-white/20 text-gray-300 px-2 py-0.5 rounded text-[10px]"
                                    >
                                      {srv}
                                    </span>
                                  ))
                                ) : (
                                  <span className="text-gray-500 italic">Tidak ada layanan spesifik</span>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>

                        {order.notes && (
                          <div className="mt-3 pt-3 border-t border-white/5 text-xs bg-black-main/40 p-2.5 rounded">
                            <span className="text-gray-400 font-bold block mb-1">Catatan Tambahan:</span>
                            <p className="text-gray-300 italic">{order.notes}</p>
                          </div>
                        )}

                        {/* Action Buttons */}
                        <div className="mt-4 pt-3 border-t border-white/5 flex flex-wrap items-center justify-between gap-2">
                          <div className="flex items-center gap-1.5">
                            <span className="text-[11px] text-gray-400 mr-1">Ubah Status:</span>
                            {(['Pending', 'Dikonfirmasi', 'Selesai', 'Dibatalkan'] as const).map(st => (
                              <button
                                key={st}
                                onClick={() => handleUpdateOrderStatus(order.id, st)}
                                className={`px-2.5 py-1 rounded text-[10px] font-bold transition-colors ${
                                  order.status === st
                                    ? 'bg-[#cc0000] text-white'
                                    : 'bg-black-main hover:bg-neutral-800 text-gray-400 border border-white/10'
                                }`}
                              >
                                {st}
                              </button>
                            ))}
                          </div>

                          <div className="flex items-center gap-2">
                            <a
                              href={`https://wa.me/${waPhone}?text=${waText}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="bg-emerald-600 hover:bg-emerald-500 text-white px-3.5 py-1.5 rounded-sm font-bold text-xs flex items-center gap-1.5 transition-colors shadow"
                            >
                              <MessageSquare className="w-3.5 h-3.5" />
                              Hubungi via WhatsApp
                            </a>
                            <button
                              onClick={() => handleDeleteOrder(order.id)}
                              className="p-1.5 bg-rose-950/40 hover:bg-rose-600 text-rose-300 hover:text-white rounded border border-rose-900/50 transition-colors"
                              title="Hapus Pesanan"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}

                {ordersList.length === 0 && (
                  <div className="text-center py-16 bg-bg-card border border-white/10 rounded-sm">
                    <ClipboardList className="w-12 h-12 text-gray-600 mx-auto mb-3" />
                    <p className="text-gray-300 text-sm font-bold">Belum Ada Pesanan Masuk</p>
                    <p className="text-gray-500 text-xs mt-1">
                      Pesanan yang diinput pelanggan dari website akan otomatis tercatat di sini.
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB: PENGATURAN AI GEMINI */}
          {activeTab === 'ai_settings' && (
            <div className="space-y-8 max-w-4xl">
              <div>
                <h2 className="text-2xl font-black text-white flex items-center gap-2.5">
                  <Bot className="w-6 h-6 text-[#cc0000]" />
                  Pengaturan Customer Service AI (Gemini API)
                </h2>
                <p className="text-xs text-gray-main mt-1">
                  Konfigurasikan model dan Google Gemini API Key Anda. API key disimpan secara aman di sisi server backend, bukan di browser.
                </p>
              </div>

              {/* Status Banner */}
              <div className="bg-bg-card border border-white/10 p-6 rounded-sm space-y-4">
                <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3 border-b border-white/5 pb-4">
                  <div>
                    <span className="text-[10px] text-gray-main uppercase font-bold block mb-1">Status Koneksi AI</span>
                    <div className="flex items-center gap-2">
                      <span
                        className={`w-3 h-3 rounded-full ${
                          aiStatus.status === 'connected'
                            ? 'bg-emerald-500 animate-pulse'
                            : aiStatus.status === 'error'
                            ? 'bg-rose-500'
                            : 'bg-amber-500'
                        }`}
                      />
                      <span className="text-base font-bold text-white capitalize">
                        {aiStatus.status === 'connected'
                          ? 'Terhubung (Aktif)'
                          : aiStatus.status === 'error'
                          ? 'Gagal Terhubung'
                          : 'Belum Dikonfigurasi'}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={handleTestAiConnection}
                      disabled={aiTesting}
                      className="bg-neutral-800 hover:bg-neutral-700 text-white px-4 py-2 rounded-sm text-xs font-bold uppercase transition-colors flex items-center gap-1.5 border border-white/10"
                    >
                      <RefreshCw className={`w-3.5 h-3.5 ${aiTesting ? 'animate-spin' : ''}`} />
                      {aiTesting ? 'Sedang Menguji...' : 'Uji Koneksi'}
                    </button>
                    {aiStatus.configured && (
                      <button
                        type="button"
                        onClick={handleDeleteAiKey}
                        className="bg-rose-950/40 hover:bg-rose-600 text-rose-300 hover:text-white px-3 py-2 rounded-sm text-xs font-bold uppercase transition-colors border border-rose-900/40"
                      >
                        Hapus Key
                      </button>
                    )}
                  </div>
                </div>

                <div className="grid sm:grid-cols-2 gap-4 text-xs">
                  <div>
                    <span className="text-gray-400 block mb-0.5">Model AI Terpilih:</span>
                    <span className="text-white font-mono font-bold bg-black-main px-2.5 py-1 rounded inline-block border border-white/10">
                      {aiStatus.model || 'gemini-flash-latest'}
                    </span>
                  </div>
                  <div>
                    <span className="text-gray-400 block mb-0.5">Google Gemini API Key:</span>
                    <span className="text-white font-mono bg-black-main px-2.5 py-1 rounded inline-block border border-white/10">
                      {aiStatus.maskedKey || 'Belum diisi'}
                    </span>
                  </div>
                </div>

                {/* Secure storage badge */}
                <div className="flex items-center gap-2 p-3 bg-emerald-950/20 border border-emerald-900/40 rounded text-emerald-300 text-xs">
                  <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>
                    <strong>Penyimpanan Aman:</strong> Kunci API disimpan secara terenkripsi di server backend. Kunci mentah tidak pernah dikirimkan atau dipaparkan ke browser pelanggan.
                  </span>
                </div>

                {/* Test Feedback Notice */}
                {aiTestResult && (
                  <div
                    className={`p-3 rounded text-xs flex items-center gap-2 ${
                      aiTestResult.success
                        ? 'bg-emerald-950/30 border border-emerald-500/50 text-emerald-200'
                        : 'bg-rose-950/30 border border-rose-500/50 text-rose-200'
                    }`}
                  >
                    {aiTestResult.success ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    ) : (
                      <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                    )}
                    <span>{aiTestResult.message}</span>
                  </div>
                )}

                {aiSaveSuccess && (
                  <div className="p-3 bg-emerald-950/30 border border-emerald-500/50 text-emerald-200 rounded text-xs flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>Konfigurasi AI berhasil disimpan dan diperbarui di server backend.</span>
                  </div>
                )}
              </div>

              {/* API Key Form */}
              <div className="bg-bg-card border border-white/10 p-6 rounded-sm">
                <h3 className="text-base font-bold text-white mb-4 flex items-center gap-2">
                  <Key className="w-4 h-4 text-[#cc0000]" />
                  Input / Ganti Google Gemini API Key
                </h3>

                <form onSubmit={handleSaveAiConfig} className="space-y-4">
                  <div>
                    <label className="block text-[11px] uppercase font-bold text-gray-main mb-1.5">
                      Pilih Model Gemini
                    </label>
                    <select
                      value={selectedModel}
                      onChange={e => setSelectedModel(e.target.value)}
                      className="w-full bg-black-main border border-gray-main/30 rounded-sm p-3 text-xs text-white focus:border-[#cc0000] outline-none"
                    >
                      <option value="gemini-3.1-flash-lite">gemini-3.1-flash-lite (Rekomendasi - Cepat & Hemat Kuota)</option>
                      <option value="gemini-flash-latest">gemini-flash-latest (Standar Flash)</option>
                    </select>
                    <p className="text-[10px] text-gray-500 mt-1">
                      Model resmi Google GenAI SDK untuk Admin Sarah melayani obrolan customer service secara responsif.
                    </p>
                  </div>

                  <div>
                    <label className="block text-[11px] uppercase font-bold text-gray-main mb-1.5 flex items-center justify-between">
                      <span>Google Gemini API Key (Server-Side)</span>
                      <button
                        type="button"
                        onClick={() => setShowApiKey(!showApiKey)}
                        className="text-gray-400 hover:text-white flex items-center gap-1 text-[10px] lowercase"
                      >
                        {showApiKey ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                        {showApiKey ? 'sembunyikan' : 'tampilkan'}
                      </button>
                    </label>
                    <input
                      type={showApiKey ? 'text' : 'password'}
                      placeholder={aiStatus.configured ? 'Ketik API key baru jika ingin mengganti...' : 'AIzaSy...'}
                      value={inputApiKey}
                      onChange={e => setInputApiKey(e.target.value)}
                      className="w-full bg-black-main border border-gray-main/30 rounded-sm p-3 text-xs text-white focus:border-[#cc0000] outline-none font-mono"
                    />
                    <p className="text-[10px] text-gray-500 mt-1">
                      Input disembunyikan sebagai password demi keamanan. Tidak akan disimpan dalam riwayat browser.
                    </p>
                  </div>

                  <div className="flex flex-wrap gap-3 pt-2">
                    <button
                      type="submit"
                      className="bg-[#cc0000] hover:bg-[#800000] text-white px-6 py-2.5 rounded-sm text-xs font-bold uppercase tracking-wider transition-colors glow-border"
                    >
                      Simpan Pengaturan
                    </button>
                    <button
                      type="button"
                      onClick={handleTestAiConnection}
                      disabled={aiTesting}
                      className="bg-black-main hover:bg-neutral-800 border border-white/20 text-white px-5 py-2.5 rounded-sm text-xs font-bold uppercase transition-colors flex items-center gap-1.5"
                    >
                      <RefreshCw className={`w-3.5 h-3.5 ${aiTesting ? 'animate-spin' : ''}`} />
                      Uji Koneksi
                    </button>
                  </div>
                </form>
              </div>

              {/* Tutorial: How to get Gemini API Key */}
              <div className="bg-[#121212] border border-white/10 p-6 rounded-sm text-xs space-y-3">
                <h4 className="font-bold text-white flex items-center gap-2 text-sm">
                  <ExternalLink className="w-4 h-4 text-[#cc0000]" />
                  Cara Mendapatkan Google Gemini API Key Gratis di Google AI Studio:
                </h4>
                <ol className="list-decimal list-inside space-y-2 text-gray-300 leading-relaxed">
                  <li>
                    Buka situs resmi Google AI Studio melalui tautan:{' '}
                    <a
                      href="https://aistudio.google.com/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[#cc0000] underline font-bold"
                    >
                      https://aistudio.google.com/
                    </a>
                  </li>
                  <li>Masuk (Login) menggunakan akun Google pribadi atau bisnis Anda.</li>
                  <li>Di menu sebelah kiri, klik tombol <strong>"Get API key"</strong>.</li>
                  <li>
                    Klik tombol biru <strong>"Create API key"</strong>, lalu pilih proyek Google Cloud yang diinginkan.
                  </li>
                  <li>
                    Salin (Copy) string API key yang berawalan <code>AIzaSy...</code> tersebut.
                  </li>
                  <li>
                    Tempelkan ke kolom form <strong>"Google Gemini API Key"</strong> di atas, lalu klik{' '}
                    <strong>"Simpan Pengaturan"</strong> dan <strong>"Uji Koneksi"</strong>.
                  </li>
                </ol>
              </div>
            </div>
          )}

          {/* TAB 1: EVENTS (7 exact fields with auto 1-month cleanup) */}
          {activeTab === 'events' && (
            <div>
              <div className="flex justify-between items-center mb-8">
                <div>
                  <h2 className="text-2xl font-black text-white">Kelola Jadwal Kegiatan</h2>
                  <p className="text-xs text-gray-main">Kegiatan otomatis terhapus dari sistem setelah 1 bulan.</p>
                </div>
                <button
                  onClick={() => { setEditingEvent(null); setIsAddingEvent(true); }}
                  className="bg-[#cc0000] hover:bg-[#800000] text-white px-4 py-2.5 rounded-sm text-xs font-bold uppercase flex items-center gap-2 glow-border"
                >
                  <Plus className="w-4 h-4" /> Tambah Kegiatan
                </button>
              </div>

              {(isAddingEvent || editingEvent) && (
                <div className="mb-10 bg-bg-card border border-[#cc0000]/40 p-6 rounded-sm">
                  <h3 className="text-lg font-bold mb-4 text-white">{editingEvent ? 'Edit Jadwal Kegiatan' : 'Tambah Kegiatan Baru'}</h3>
                  <form onSubmit={handleSaveEvent} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] uppercase font-bold text-gray-main mb-1">1. Nomer</label>
                      <input name="no" defaultValue={editingEvent?.no || `0${eventList.length + 1}`} required className="w-full bg-black-main border border-gray-main/30 rounded-sm p-2.5 text-xs text-white" />
                    </div>
                    <div>
                      <label className="block text-[10px] uppercase font-bold text-gray-main mb-1">2. Acara</label>
                      <input name="name" defaultValue={editingEvent?.name || ''} required placeholder="Nama Acara" className="w-full bg-black-main border border-gray-main/30 rounded-sm p-2.5 text-xs text-white" />
                    </div>
                    <div>
                      <label className="block text-[10px] uppercase font-bold text-gray-main mb-1">3. Hari Tanggal Bulan</label>
                      <input name="dateText" defaultValue={editingEvent?.dateText || ''} required placeholder="Sabtu, 25 Oktober 2026" className="w-full bg-black-main border border-gray-main/30 rounded-sm p-2.5 text-xs text-white" />
                    </div>
                    <div>
                      <label className="block text-[10px] uppercase font-bold text-gray-main mb-1">4. Penyewa</label>
                      <input name="client" defaultValue={editingEvent?.client || ''} required placeholder="Nama Penyewa" className="w-full bg-black-main border border-gray-main/30 rounded-sm p-2.5 text-xs text-white" />
                    </div>
                    <div>
                      <label className="block text-[10px] uppercase font-bold text-gray-main mb-1">5. Lokasi</label>
                      <input name="location" defaultValue={editingEvent?.location || ''} required placeholder="Lokasi Acara" className="w-full bg-black-main border border-gray-main/30 rounded-sm p-2.5 text-xs text-white" />
                    </div>
                    <div>
                      <label className="block text-[10px] uppercase font-bold text-gray-main mb-1">6. Acara Pukul</label>
                      <input name="timeText" defaultValue={editingEvent?.timeText || ''} required placeholder="19.00 WIB" className="w-full bg-black-main border border-gray-main/30 rounded-sm p-2.5 text-xs text-white" />
                    </div>
                    <div className="md:col-span-2">
                      <label className="block text-[10px] uppercase font-bold text-gray-main mb-1">7. Keterangan</label>
                      <input name="keterangan" defaultValue={editingEvent?.keterangan || ''} required placeholder="Keterangan / Tema / Status..." className="w-full bg-black-main border border-gray-main/30 rounded-sm p-2.5 text-xs text-white" />
                    </div>
                    <div className="md:col-span-2 flex justify-end gap-3 mt-4">
                      <button type="button" onClick={() => { setIsAddingEvent(false); setEditingEvent(null); }} className="px-4 py-2 bg-gray-800 text-xs rounded-sm">Batal</button>
                      <button type="submit" className="px-6 py-2 bg-[#cc0000] text-white text-xs font-bold uppercase rounded-sm">Simpan Kegiatan</button>
                    </div>
                  </form>
                </div>
              )}

              <div className="bg-bg-card rounded-sm overflow-hidden border border-gray-main/20">
                <table className="w-full text-xs text-left">
                  <thead className="bg-[#141414] text-gray-main uppercase border-b border-[#cc0000]/30">
                    <tr>
                      <th className="p-3">Nomer</th>
                      <th className="p-3">Acara</th>
                      <th className="p-3">Hari Tanggal Bulan</th>
                      <th className="p-3">Penyewa</th>
                      <th className="p-3">Lokasi</th>
                      <th className="p-3">Acara Pukul</th>
                      <th className="p-3">Keterangan</th>
                      <th className="p-3 text-right">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-main/10">
                    {eventList.map((ev) => (
                      <tr key={ev.id} className="hover:bg-[#cc0000]/10">
                        <td className="p-3 text-[#cc0000] font-bold">{ev.no}</td>
                        <td className="p-3 font-bold text-white">{ev.name}</td>
                        <td className="p-3 text-gray-main">{ev.dateText || '-'}</td>
                        <td className="p-3 text-gray-main">{ev.client}</td>
                        <td className="p-3 text-gray-main">{ev.location}</td>
                        <td className="p-3 text-[#cc0000] font-semibold">{ev.timeText || '-'}</td>
                        <td className="p-3 text-gray-main">{ev.keterangan}</td>
                        <td className="p-3 text-right space-x-2">
                          <button onClick={() => setEditingEvent(ev)} className="p-1.5 bg-blue-600/20 text-blue-400 rounded hover:bg-blue-600 hover:text-white"><Edit className="w-3.5 h-3.5" /></button>
                          <button onClick={() => handleDeleteEvent(ev.id)} className="p-1.5 bg-red-600/20 text-red-400 rounded hover:bg-red-600 hover:text-white"><Trash2 className="w-3.5 h-3.5" /></button>
                        </td>
                      </tr>
                    ))}
                    {eventList.length === 0 && (
                      <tr>
                        <td colSpan={8} className="p-8 text-center text-gray-main">Belum ada kegiatan aktif (otomatis terhapus setelah 1 bulan).</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 2: PACKAGES */}
          {activeTab === 'packages' && (
            <div>
              <div className="flex justify-between items-center mb-8">
                <div>
                  <h2 className="text-2xl font-black">Paket Rental</h2>
                  <p className="text-xs text-gray-main">Tambah, edit, unggah dari kamera HP / file, atau masukkan URL foto.</p>
                </div>
                <button
                  onClick={() => { setEditingPkg(null); setPkgImageInput(''); setIsAddingPkg(true); }}
                  className="bg-[#cc0000] hover:bg-[#800000] text-white px-4 py-2.5 rounded-sm text-xs font-bold uppercase flex items-center gap-2 glow-border"
                >
                  <Plus className="w-4 h-4" /> Tambah Paket
                </button>
              </div>

              {(isAddingPkg || editingPkg) && (
                <div className="mb-10 bg-bg-card border border-[#cc0000]/30 p-6 rounded-sm">
                  <h3 className="text-lg font-bold mb-4">{editingPkg ? 'Edit Paket Rental' : 'Tambah Paket Baru'}</h3>
                  <form onSubmit={handleSavePkg} className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[10px] uppercase font-bold text-gray-main mb-1">Nama Paket</label>
                        <input name="name" defaultValue={editingPkg?.name || ''} required placeholder="Audio Concert Pro" className="w-full bg-black-main border border-gray-main/30 rounded-sm p-2.5 text-xs text-white" />
                      </div>
                      <div>
                        <label className="block text-[10px] uppercase font-bold text-gray-main mb-1">Kategori</label>
                        <select name="category" defaultValue={editingPkg?.category || 'Audio'} className="w-full bg-black-main border border-gray-main/30 rounded-sm p-2.5 text-xs text-white">
                          <option value="Audio">Audio</option>
                          <option value="Lighting">Lighting</option>
                          <option value="Videotron">Videotron</option>
                          <option value="Rigging">Rigging</option>
                          <option value="Stage">Stage</option>
                          <option value="Full Production">Full Production</option>
                        </select>
                      </div>
                    </div>

                    <div className="space-y-2 bg-black-main/50 p-4 rounded-sm border border-gray-main/20">
                      <label className="block text-[10px] uppercase font-bold text-[#cc0000] mb-1 flex items-center gap-2">
                        <Camera className="w-4 h-4" /> Foto Peralatan (Kamera HP / File / URL)
                      </label>
                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <span className="text-[10px] text-gray-main block mb-1">Upload dari File / Foto Kamera HP:</span>
                          <label className="flex items-center justify-center gap-2 px-4 py-3 bg-bg-card hover:bg-gray-800 border border-gray-main/30 rounded-sm cursor-pointer text-xs font-bold text-white transition-colors">
                            <Upload className="w-4 h-4 text-[#cc0000]" /> Pilih Foto / Ambil Gambar
                            <input
                              type="file"
                              accept="image/*"
                              capture="environment"
                              className="hidden"
                              onChange={(e) => handleImageFileChange(e, setPkgImageInput)}
                            />
                          </label>
                        </div>
                        <div>
                          <span className="text-[10px] text-gray-main block mb-1">Atau Masukkan URL Gambar:</span>
                          <div className="relative">
                            <Link className="absolute left-3 top-3 w-3.5 h-3.5 text-gray-main" />
                            <input
                              type="url"
                              placeholder="https://..."
                              value={pkgImageInput || editingPkg?.image || ''}
                              onChange={(e) => setPkgImageInput(e.target.value)}
                              className="w-full bg-bg-card border border-gray-main/30 rounded-sm pl-9 pr-3 py-2.5 text-xs text-white"
                            />
                          </div>
                        </div>
                      </div>
                      {(pkgImageInput || editingPkg?.image) && (
                        <div className="mt-2 flex items-center gap-3">
                          <img src={pkgImageInput || editingPkg?.image} alt="Preview" className="w-16 h-16 object-cover rounded-sm border border-[#cc0000]/50" />
                          <span className="text-[10px] text-gray-main">Preview Foto Aktif</span>
                        </div>
                      )}
                    </div>

                    <div>
                      <label className="block text-[10px] uppercase font-bold text-gray-main mb-1">Deskripsi</label>
                      <textarea name="description" rows={2} defaultValue={editingPkg?.description || ''} required placeholder="Deskripsi paket..." className="w-full bg-black-main border border-gray-main/30 rounded-sm p-2.5 text-xs text-white" />
                    </div>
                    <div>
                      <label className="block text-[10px] uppercase font-bold text-gray-main mb-1">Spesifikasi (Pisahkan dengan koma)</label>
                      <input name="specs" defaultValue={editingPkg?.specs.join(', ') || ''} required placeholder="2x Active Speaker, 1x Mixer, Mic" className="w-full bg-black-main border border-gray-main/30 rounded-sm p-2.5 text-xs text-white" />
                    </div>
                    <div>
                      <label className="block text-[10px] uppercase font-bold text-gray-main mb-1">Harga / Label</label>
                      <input name="priceTag" defaultValue={editingPkg?.priceTag || 'Hubungi untuk Penawaran'} required className="w-full bg-black-main border border-gray-main/30 rounded-sm p-2.5 text-xs text-white" />
                    </div>
                    <div className="flex justify-end gap-3 pt-2">
                      <button type="button" onClick={() => { setIsAddingPkg(false); setEditingPkg(null); }} className="px-4 py-2 bg-gray-800 text-xs rounded-sm">Batal</button>
                      <button type="submit" className="px-6 py-2 bg-[#cc0000] text-white text-xs font-bold uppercase rounded-sm">Simpan Paket</button>
                    </div>
                  </form>
                </div>
              )}

              <div className="grid md:grid-cols-2 gap-6">
                {packageList.map(pkg => (
                  <div key={pkg.id} className="bg-bg-card p-6 rounded-sm border border-gray-main/20 flex flex-col justify-between">
                    <div className="flex gap-4">
                      <img src={pkg.image} alt={pkg.name} className="w-24 h-24 object-cover rounded-sm border border-gray-main/20" />
                      <div>
                        <span className="text-[10px] text-[#cc0000] font-bold uppercase">{pkg.category}</span>
                        <h3 className="font-bold text-sm mb-1">{pkg.name}</h3>
                        <p className="text-xs text-gray-main line-clamp-2 mb-2">{pkg.description}</p>
                        <span className="text-xs text-[#cc0000] font-bold">{pkg.priceTag}</span>
                      </div>
                    </div>
                    <div className="flex justify-end gap-2 pt-4 mt-4 border-t border-gray-main/10">
                      <button onClick={() => { setEditingPkg(pkg); setPkgImageInput(pkg.image); }} className="px-3 py-1.5 bg-blue-600/20 text-blue-400 rounded text-xs font-bold hover:bg-blue-600 hover:text-white flex items-center gap-1"><Edit className="w-3.5 h-3.5" /> Edit</button>
                      <button onClick={() => handleDeletePkg(pkg.id)} className="px-3 py-1.5 bg-red-600/20 text-red-400 rounded text-xs font-bold hover:bg-red-600 hover:text-white flex items-center gap-1"><Trash2 className="w-3.5 h-3.5" /> Hapus</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: PORTFOLIO */}
          {activeTab === 'portfolio' && (
            <div>
              <div className="flex justify-between items-center mb-8">
                <div>
                  <h2 className="text-2xl font-black">Galeri</h2>
                  <p className="text-xs text-gray-main">Tambah, edit, ambil foto langsung dari kamera HP atau upload file.</p>
                </div>
                <button
                  onClick={() => { setEditingPort(null); setPortImageInput(''); setIsAddingPort(true); }}
                  className="bg-[#cc0000] hover:bg-[#800000] text-white px-4 py-2.5 rounded-sm text-xs font-bold uppercase flex items-center gap-2 glow-border"
                >
                  <Plus className="w-4 h-4" /> Tambah Portofolio
                </button>
              </div>

              {(isAddingPort || editingPort) && (
                <div className="mb-10 bg-bg-card border border-[#cc0000]/30 p-6 rounded-sm">
                  <h3 className="text-lg font-bold mb-4">{editingPort ? 'Edit Portofolio' : 'Tambah Portofolio Baru'}</h3>
                  <form onSubmit={handleSavePort} className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[10px] uppercase font-bold text-gray-main mb-1">Judul Proyek</label>
                        <input name="title" defaultValue={editingPort?.title || ''} required placeholder="Rock Arena Festival" className="w-full bg-black-main border border-gray-main/30 rounded-sm p-2.5 text-xs text-white" />
                      </div>
                      <div>
                        <label className="block text-[10px] uppercase font-bold text-gray-main mb-1">Kategori</label>
                        <select name="category" defaultValue={editingPort?.category || 'Concert'} className="w-full bg-black-main border border-gray-main/30 rounded-sm p-2.5 text-xs text-white">
                          <option value="Concert">Concert</option>
                          <option value="Festival">Festival</option>
                          <option value="Wedding">Wedding</option>
                          <option value="Corporate">Corporate</option>
                          <option value="Stage Production">Stage Production</option>
                        </select>
                      </div>
                    </div>

                    <div className="space-y-2 bg-black-main/50 p-4 rounded-sm border border-gray-main/20">
                      <label className="block text-[10px] uppercase font-bold text-[#cc0000] mb-1 flex items-center gap-2">
                        <Camera className="w-4 h-4" /> Foto Proyek (Kamera HP / File / URL)
                      </label>
                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <span className="text-[10px] text-gray-main block mb-1">Upload dari File / Foto Kamera HP:</span>
                          <label className="flex items-center justify-center gap-2 px-4 py-3 bg-bg-card hover:bg-gray-800 border border-gray-main/30 rounded-sm cursor-pointer text-xs font-bold text-white transition-colors">
                            <Upload className="w-4 h-4 text-[#cc0000]" /> Pilih Foto / Ambil Gambar
                            <input
                              type="file"
                              accept="image/*"
                              capture="environment"
                              className="hidden"
                              onChange={(e) => handleImageFileChange(e, setPortImageInput)}
                            />
                          </label>
                        </div>
                        <div>
                          <span className="text-[10px] text-gray-main block mb-1">Atau Masukkan URL Gambar:</span>
                          <div className="relative">
                            <Link className="absolute left-3 top-3 w-3.5 h-3.5 text-gray-main" />
                            <input
                              type="url"
                              placeholder="https://..."
                              value={portImageInput || editingPort?.image || ''}
                              onChange={(e) => setPortImageInput(e.target.value)}
                              className="w-full bg-bg-card border border-gray-main/30 rounded-sm pl-9 pr-3 py-2.5 text-xs text-white"
                            />
                          </div>
                        </div>
                      </div>
                      {(portImageInput || editingPort?.image) && (
                        <div className="mt-2 flex items-center gap-3">
                          <img src={portImageInput || editingPort?.image} alt="Preview" className="w-16 h-16 object-cover rounded-sm border border-[#cc0000]/50" />
                          <span className="text-[10px] text-gray-main">Preview Foto Aktif</span>
                        </div>
                      )}
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[10px] uppercase font-bold text-gray-main mb-1">Lokasi</label>
                        <input name="location" defaultValue={editingPort?.location || ''} required placeholder="Stadion GBK" className="w-full bg-black-main border border-gray-main/30 rounded-sm p-2.5 text-xs text-white" />
                      </div>
                      <div>
                        <label className="block text-[10px] uppercase font-bold text-gray-main mb-1">Tanggal</label>
                        <input name="date" defaultValue={editingPort?.date || ''} required placeholder="12 September 2026" className="w-full bg-black-main border border-gray-main/30 rounded-sm p-2.5 text-xs text-white" />
                      </div>
                    </div>
                    <div>
                      <label className="block text-[10px] uppercase font-bold text-gray-main mb-1">Deskripsi</label>
                      <textarea name="description" rows={2} defaultValue={editingPort?.description || ''} required placeholder="Deskripsi pekerjaan..." className="w-full bg-black-main border border-gray-main/30 rounded-sm p-2.5 text-xs text-white" />
                    </div>
                    <div className="flex justify-end gap-3 pt-2">
                      <button type="button" onClick={() => { setIsAddingPort(false); setEditingPort(null); }} className="px-4 py-2 bg-gray-800 text-xs rounded-sm">Batal</button>
                      <button type="submit" className="px-6 py-2 bg-[#cc0000] text-white text-xs font-bold uppercase rounded-sm">Simpan Portofolio</button>
                    </div>
                  </form>
                </div>
              )}

              <div className="grid md:grid-cols-3 gap-6">
                {portfolioList.map(item => (
                  <div key={item.id} className="bg-bg-card rounded-sm overflow-hidden border border-gray-main/20 flex flex-col justify-between">
                    <div>
                      <img src={item.image} alt={item.title} className="w-full h-40 object-cover border-b border-gray-main/20" />
                      <div className="p-4">
                        <span className="text-[10px] text-[#cc0000] font-bold uppercase">{item.category}</span>
                        <h3 className="font-bold text-sm mb-1">{item.title}</h3>
                        <p className="text-xs text-gray-main line-clamp-2">{item.description}</p>
                      </div>
                    </div>
                    <div className="p-4 pt-0 flex justify-end gap-2 border-t border-gray-main/10 mt-2">
                      <button onClick={() => { setEditingPort(item); setPortImageInput(item.image); }} className="px-3 py-1.5 bg-blue-600/20 text-blue-400 rounded text-xs font-bold hover:bg-blue-600 hover:text-white flex items-center gap-1"><Edit className="w-3.5 h-3.5" /> Edit</button>
                      <button onClick={() => handleDeletePort(item.id)} className="px-3 py-1.5 bg-red-600/20 text-red-400 rounded text-xs font-bold hover:bg-red-600 hover:text-white flex items-center gap-1"><Trash2 className="w-3.5 h-3.5" /> Hapus</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB: MERCHANDISE */}
          {activeTab === 'merchandise' && (
            <div>
              <div className="flex justify-between items-center mb-8">
                <div>
                  <h2 className="text-2xl font-black">Kelola Merchandise & Apparel</h2>
                  <p className="text-xs text-gray-main">Tambah, edit produk, foto dari kamera/file, harga, ukuran, dan status.</p>
                </div>
                <button
                  onClick={() => { setEditingMerch(null); setMerchImageInput(''); setIsAddingMerch(true); }}
                  className="bg-[#cc0000] hover:bg-[#800000] text-white px-4 py-2.5 rounded-sm text-xs font-bold uppercase flex items-center gap-2 glow-border"
                >
                  <Plus className="w-4 h-4" /> Tambah Produk
                </button>
              </div>

              {(isAddingMerch || editingMerch) && (
                <div className="mb-10 bg-bg-card border border-[#cc0000]/30 p-6 rounded-sm">
                  <h3 className="text-lg font-bold mb-4">{editingMerch ? 'Edit Produk Merchandise' : 'Tambah Produk Baru'}</h3>
                  <form onSubmit={handleSaveMerch} className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[10px] uppercase font-bold text-gray-main mb-1">Nama Produk</label>
                        <input name="name" defaultValue={editingMerch?.name || ''} required placeholder="Official XA-BLENK Hoodie" className="w-full bg-black-main border border-gray-main/30 rounded-sm p-2.5 text-xs text-white" />
                      </div>
                      <div>
                        <label className="block text-[10px] uppercase font-bold text-gray-main mb-1">Harga (Contoh: Rp 250.000)</label>
                        <input name="price" defaultValue={editingMerch?.price || ''} required placeholder="Rp 250.000" className="w-full bg-black-main border border-gray-main/30 rounded-sm p-2.5 text-xs text-white" />
                      </div>
                    </div>

                    <div className="space-y-2 bg-black-main/50 p-4 rounded-sm border border-gray-main/20">
                      <label className="block text-[10px] uppercase font-bold text-[#cc0000] mb-1 flex items-center gap-2">
                        <Camera className="w-4 h-4" /> Foto Produk (Kamera HP / File / URL)
                      </label>
                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <span className="text-[10px] text-gray-main block mb-1">Upload dari File / Foto Kamera HP:</span>
                          <label className="flex items-center justify-center gap-2 px-4 py-3 bg-bg-card hover:bg-gray-800 border border-gray-main/30 rounded-sm cursor-pointer text-xs font-bold text-white transition-colors">
                            <Upload className="w-4 h-4 text-[#cc0000]" /> Pilih Foto / Ambil Gambar
                            <input
                              type="file"
                              accept="image/*"
                              capture="environment"
                              className="hidden"
                              onChange={(e) => handleImageFileChange(e, setMerchImageInput)}
                            />
                          </label>
                        </div>
                        <div>
                          <span className="text-[10px] text-gray-main block mb-1">Atau Masukkan URL Gambar:</span>
                          <div className="relative">
                            <Link className="absolute left-3 top-3 w-3.5 h-3.5 text-gray-main" />
                            <input
                              type="url"
                              placeholder="https://..."
                              value={merchImageInput || editingMerch?.image || ''}
                              onChange={(e) => setMerchImageInput(e.target.value)}
                              className="w-full bg-bg-card border border-gray-main/30 rounded-sm pl-9 pr-3 py-2.5 text-xs text-white"
                            />
                          </div>
                        </div>
                      </div>
                      {(merchImageInput || editingMerch?.image) && (
                        <div className="mt-2 flex items-center gap-3">
                          <img src={merchImageInput || editingMerch?.image} alt="Preview" className="w-16 h-16 object-cover rounded-sm border border-[#cc0000]/50" />
                          <span className="text-[10px] text-gray-main">Preview Foto Aktif</span>
                        </div>
                      )}
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[10px] uppercase font-bold text-gray-main mb-1">Ukuran (Pisahkan dengan koma)</label>
                        <input name="sizes" defaultValue={editingMerch?.sizes.join(', ') || 'S, M, L, XL, XXL, Custom Size'} required placeholder="S, M, L, XL, Custom" className="w-full bg-black-main border border-gray-main/30 rounded-sm p-2.5 text-xs text-white" />
                      </div>
                      <div>
                        <label className="block text-[10px] uppercase font-bold text-gray-main mb-1">Status Produk</label>
                        <select name="status" defaultValue={editingMerch?.status || 'Ready'} className="w-full bg-black-main border border-gray-main/30 rounded-sm p-2.5 text-xs text-white">
                          <option value="Ready">Ready</option>
                          <option value="Pre-Order">Pre-Order</option>
                        </select>
                      </div>
                    </div>
                    <div>
                      <label className="block text-[10px] uppercase font-bold text-gray-main mb-1">Deskripsi Produk</label>
                      <textarea name="description" rows={2} defaultValue={editingMerch?.description || ''} required placeholder="Deskripsi merchandise..." className="w-full bg-black-main border border-gray-main/30 rounded-sm p-2.5 text-xs text-white" />
                    </div>
                    <div className="flex justify-end gap-3 pt-2">
                      <button type="button" onClick={() => { setIsAddingMerch(false); setEditingMerch(null); }} className="px-4 py-2 bg-gray-800 text-xs rounded-sm">Batal</button>
                      <button type="submit" className="px-6 py-2 bg-[#cc0000] text-white text-xs font-bold uppercase rounded-sm">Simpan Produk</button>
                    </div>
                  </form>
                </div>
              )}

              <div className="grid md:grid-cols-3 gap-6">
                {merchList.map(item => (
                  <div key={item.id} className="bg-bg-card rounded-sm overflow-hidden border border-gray-main/20 flex flex-col justify-between">
                    <div>
                      <img src={item.image} alt={item.name} className="w-full h-40 object-cover border-b border-gray-main/20" />
                      <div className="p-4">
                        <div className="flex justify-between items-center mb-1">
                          <span className={`px-2 py-0.5 rounded text-[9px] font-bold ${item.status === 'Ready' ? 'bg-green-600/20 text-green-400' : 'bg-yellow-600/20 text-yellow-400'}`}>{item.status}</span>
                          <span className="text-xs text-[#cc0000] font-bold">{item.price}</span>
                        </div>
                        <h3 className="font-bold text-sm mb-1">{item.name}</h3>
                        <p className="text-xs text-gray-main line-clamp-2 mb-2">{item.description}</p>
                        <p className="text-[10px] text-gray-400">Ukuran: {item.sizes.join(', ')}</p>
                      </div>
                    </div>
                    <div className="p-4 pt-0 flex justify-end gap-2 border-t border-gray-main/10 mt-2">
                      <button onClick={() => { setEditingMerch(item); setMerchImageInput(item.image); }} className="px-3 py-1.5 bg-blue-600/20 text-blue-400 rounded text-xs font-bold hover:bg-blue-600 hover:text-white flex items-center gap-1"><Edit className="w-3.5 h-3.5" /> Edit</button>
                      <button onClick={() => handleDeleteMerch(item.id)} className="px-3 py-1.5 bg-red-600/20 text-red-400 rounded text-xs font-bold hover:bg-red-600 hover:text-white flex items-center gap-1"><Trash2 className="w-3.5 h-3.5" /> Hapus</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: WHATSAPP */}
          {activeTab === 'whatsapp' && (
            <div>
              <h2 className="text-2xl font-black mb-2">No WhatsApp</h2>
              <p className="text-xs text-gray-main mb-8">Atur nomor WhatsApp resmi untuk Admin Sound Rental dan Admin Merchandise secara terpisah.</p>
              
              <div className="bg-bg-card p-8 rounded-sm border border-gray-main/20 max-w-xl space-y-6">
                {saveWhatsappSuccess && (
                  <div className="p-3 bg-green-500/20 border border-green-500 text-green-300 text-xs rounded-sm">
                    Nomor WhatsApp berhasil diperbarui!
                  </div>
                )}
                <div>
                  <label className="block text-xs uppercase font-bold text-gray-main mb-2">No. WhatsApp Admin Sound / Rental / Booking</label>
                  <div className="flex gap-3">
                    <div className="relative flex-1">
                      <MessageSquare className="absolute left-3 top-3.5 w-4 h-4 text-[#cc0000]" />
                      <input
                        type="text"
                        value={whatsappNumber}
                        onChange={e => setWhatsappNumber(e.target.value)}
                        placeholder="6285735007989"
                        className="w-full bg-black-main border border-gray-main/30 rounded-sm pl-10 pr-4 py-3 text-sm text-white focus:border-[#cc0000] outline-none"
                      />
                    </div>
                    <button
                      onClick={() => {
                        localStorage.setItem('xablenk_whatsapp_number', whatsappNumber);
                        setSaveWhatsappSuccess(true);
                        setTimeout(() => setSaveWhatsappSuccess(false), 3000);
                      }}
                      className="bg-[#cc0000] hover:bg-[#800000] text-white px-6 py-3 rounded-sm text-xs font-bold uppercase transition-colors"
                    >
                      Simpan
                    </button>
                  </div>
                  <p className="text-[11px] text-gray-main mt-1">
                    Digunakan untuk formulir booking sound system, lighting, dan paket rental.
                  </p>
                </div>

                <div className="pt-6 border-t border-gray-main/20">
                  <label className="block text-xs uppercase font-bold text-gray-main mb-2">No. WhatsApp Admin Merchandise / Apparel</label>
                  <div className="flex gap-3">
                    <div className="relative flex-1">
                      <MessageSquare className="absolute left-3 top-3.5 w-4 h-4 text-[#cc0000]" />
                      <input
                        type="text"
                        value={merchandiseWhatsapp}
                        onChange={e => setMerchandiseWhatsapp(e.target.value)}
                        placeholder="6285735007989"
                        className="w-full bg-black-main border border-gray-main/30 rounded-sm pl-10 pr-4 py-3 text-sm text-white focus:border-[#cc0000] outline-none"
                      />
                    </div>
                    <button
                      onClick={() => {
                        localStorage.setItem('xablenk_merchandise_whatsapp', merchandiseWhatsapp);
                        setSaveWhatsappSuccess(true);
                        setTimeout(() => setSaveWhatsappSuccess(false), 3000);
                      }}
                      className="bg-[#cc0000] hover:bg-[#800000] text-white px-6 py-3 rounded-sm text-xs font-bold uppercase transition-colors"
                    >
                      Simpan
                    </button>
                  </div>
                  <p className="text-[11px] text-gray-main mt-1">
                    Digunakan khusus untuk checkout pesanan merchandise dan kontak admin merchandise.
                  </p>
                </div>

                <div className="pt-4 border-t border-gray-main/10 space-y-2 text-xs text-gray-main">
                  <p><strong>Alamat Kantor:</strong> Jl. Bromo no. 24 - Tawangsari Garum Blitar Jawa-Timur</p>
                  <p><strong>Email:</strong> xablenk.audio.real@gmail.com</p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: HERO & SOCIALS & GALLERY SETTINGS & BACKGROUND UPLOAD */}
          {activeTab === 'hero_socials' && (
            <div className="space-y-12">
              {/* Background Upload Section */}
              <div className="bg-bg-card p-8 rounded-sm border border-[#cc0000]/40 glow-border">
                <h2 className="text-2xl font-black mb-2 text-white">Upload Background Website / Hero</h2>
                <p className="text-xs text-gray-main mb-6">Unggah atau pasang latar belakang kustom (background) untuk mempercantik tampilan beranda website.</p>
                
                {saveHeroSuccess && (
                  <div className="mb-4 p-3 bg-green-500/20 border border-green-500 text-green-300 text-xs rounded-sm">
                    Background website berhasil diperbarui!
                  </div>
                )}

                <div className="space-y-4 bg-black-main/60 p-6 rounded-sm border border-gray-main/20">
                  <label className="block text-xs uppercase font-bold text-[#cc0000] mb-2 flex items-center gap-2">
                    <Camera className="w-4 h-4" /> Pilih / Unggah Gambar Background (Kamera HP / File / URL)
                  </label>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="flex items-center justify-center gap-2 px-4 py-4 bg-bg-card hover:bg-gray-800 border border-gray-main/30 rounded-sm cursor-pointer text-xs font-bold text-white transition-colors">
                        <Upload className="w-4 h-4 text-[#cc0000]" /> Upload File / Ambil Foto HP
                        <input
                          type="file"
                          accept="image/*"
                          capture="environment"
                          className="hidden"
                          onChange={(e) => handleImageFileChange(e, setBgImageInput)}
                        />
                      </label>
                    </div>
                    <div>
                      <div className="relative">
                        <Link className="absolute left-3 top-3.5 w-3.5 h-3.5 text-gray-main" />
                        <input
                          type="url"
                          placeholder="Atau masukkan URL Background..."
                          value={bgImageInput}
                          onChange={(e) => setBgImageInput(e.target.value)}
                          className="w-full bg-bg-card border border-gray-main/30 rounded-sm pl-9 pr-3 py-3 text-xs text-white"
                        />
                      </div>
                    </div>
                  </div>

                  {(bgImageInput || heroSettings.backgroundImage) && (
                    <div className="mt-4 flex items-center gap-4 bg-black-secondary p-4 rounded-sm border border-[#cc0000]/30">
                      <img src={bgImageInput || heroSettings.backgroundImage} alt="Background Preview" className="w-20 h-20 object-cover rounded-sm border border-[#cc0000]/50" />
                      <div>
                        <p className="text-xs font-bold text-white">Background Kustom Aktif</p>
                        <p className="text-[10px] text-gray-main">Background akan diterapkan secara otomatis di beranda website dengan efek gelap dan merah elegan.</p>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setBgImageInput('');
                          setHeroSettings(prev => ({ ...prev, backgroundImage: '' }));
                          localStorage.setItem('xablenk_hero_settings', JSON.stringify({ ...heroSettings, backgroundImage: '' }));
                        }}
                        className="ml-auto px-3 py-1.5 bg-red-600/20 hover:bg-red-600 text-red-300 hover:text-white rounded text-xs font-bold transition-colors"
                      >
                        Reset Background
                      </button>
                    </div>
                  )}

                  <button
                    type="button"
                    onClick={() => {
                      const newBg = bgImageInput || heroSettings.backgroundImage || '';
                      setHeroSettings(prev => ({ ...prev, backgroundImage: newBg }));
                      localStorage.setItem('xablenk_hero_settings', JSON.stringify({ ...heroSettings, backgroundImage: newBg }));
                      setSaveHeroSuccess(true);
                      setTimeout(() => setSaveHeroSuccess(false), 3000);
                    }}
                    className="w-full bg-[#cc0000] hover:bg-[#800000] text-white py-3 rounded-sm text-xs font-bold uppercase transition-colors glow-border mt-2"
                  >
                    Simpan & Terapkan Background Website
                  </button>
                </div>
              </div>

              {/* Gallery Section Settings */}
              <div className="bg-bg-card p-8 rounded-sm border border-gray-main/20">
                <h2 className="text-2xl font-black mb-2">Pengaturan Teks Bagian Galeri</h2>
                <p className="text-xs text-gray-main mb-6">Ubah judul, sub-judul, dan deskripsi di bagian Galeri & Portofolio website.</p>
                {saveGallerySuccess && (
                  <div className="mb-4 p-3 bg-green-500/20 border border-green-500 text-green-300 text-xs rounded-sm">
                    Pengaturan galeri berhasil disimpan!
                  </div>
                )}
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    const form = e.currentTarget;
                    const subheading = (form.elements.namedItem('gallerySubheading') as HTMLInputElement).value;
                    const heading = (form.elements.namedItem('galleryHeading') as HTMLInputElement).value;
                    const description = (form.elements.namedItem('galleryDescription') as HTMLTextAreaElement).value;
                    setGallerySettings({ subheading, heading, description });
                    setSaveGallerySuccess(true);
                    setTimeout(() => setSaveGallerySuccess(false), 3000);
                  }}
                  className="space-y-4"
                >
                  <div>
                    <label className="block text-[10px] uppercase font-bold text-gray-main mb-1">Sub-Judul (Kecil di atas)</label>
                    <input
                      name="gallerySubheading"
                      defaultValue={gallerySettings.subheading}
                      required
                      className="w-full bg-black-main border border-gray-main/30 rounded-sm p-3 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] uppercase font-bold text-gray-main mb-1">Judul Utama (Heading Galeri)</label>
                    <input
                      name="galleryHeading"
                      defaultValue={gallerySettings.heading}
                      required
                      className="w-full bg-black-main border border-gray-main/30 rounded-sm p-3 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] uppercase font-bold text-gray-main mb-1">Deskripsi Galeri</label>
                    <textarea
                      name="galleryDescription"
                      rows={2}
                      defaultValue={gallerySettings.description}
                      required
                      className="w-full bg-black-main border border-gray-main/30 rounded-sm p-3 text-xs text-white"
                    />
                  </div>
                  <button type="submit" className="bg-[#cc0000] hover:bg-[#800000] text-white px-6 py-3 rounded-sm text-xs font-bold uppercase transition-colors">
                    Simpan Perubahan Teks Galeri
                  </button>
                </form>
              </div>

              {/* Hero Settings */}
              <div className="bg-bg-card p-8 rounded-sm border border-gray-main/20">
                <h2 className="text-2xl font-black mb-2">Pengaturan Beranda (Hero & Logo)</h2>
                <p className="text-xs text-gray-main mb-6">Ubah logo brand, judul, deskripsi, dan foto utama di bagian Beranda.</p>
                {saveHeroSuccess && (
                  <div className="mb-4 p-3 bg-green-500/20 border border-green-500 text-green-300 text-xs rounded-sm">
                    Pengaturan beranda berhasil disimpan!
                  </div>
                )}
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    const form = e.currentTarget;
                    const title = (form.elements.namedItem('heroTitle') as HTMLInputElement).value;
                    const subtitle = (form.elements.namedItem('heroSubtitle') as HTMLTextAreaElement).value;
                    const image = heroImageInput || heroSettings.image;
                    const logo = heroLogoInput || heroSettings.logo;
                    const headerLogo = headerLogoInput || heroSettings.headerLogo;
                    const backgroundImage = bgImageInput || heroSettings.backgroundImage;
                    setHeroSettings({ title, subtitle, image, logo, headerLogo, backgroundImage });
                    setSaveHeroSuccess(true);
                    setTimeout(() => setSaveHeroSuccess(false), 3000);
                  }}
                  className="space-y-6"
                >
                  {/* Header Logo Upload Section */}
                  <div className="space-y-2 bg-black-main/50 p-4 rounded-sm border border-gray-main/20">
                    <label className="block text-xs uppercase font-bold text-[#cc0000] mb-1 flex items-center gap-2">
                      <Camera className="w-4 h-4" /> Logo Navigasi Header Atas (Logo Menu Bar)
                    </label>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="flex items-center justify-center gap-2 px-4 py-3 bg-bg-card hover:bg-gray-800 border border-gray-main/30 rounded-sm cursor-pointer text-xs font-bold text-white transition-colors">
                          <Upload className="w-4 h-4 text-[#cc0000]" /> Upload File / Kamera HP
                          <input
                            type="file"
                            accept="image/*"
                            capture="environment"
                            className="hidden"
                            onChange={(e) => handleImageFileChange(e, setHeaderLogoInput)}
                          />
                        </label>
                      </div>
                      <div>
                        <input
                          type="url"
                          placeholder="Atau masukkan URL Header Logo..."
                          value={headerLogoInput}
                          onChange={(e) => setHeaderLogoInput(e.target.value)}
                          className="w-full bg-bg-card border border-gray-main/30 rounded-sm px-3 py-3 text-xs text-white"
                        />
                      </div>
                    </div>
                    {(headerLogoInput || heroSettings.headerLogo) && (
                      <div className="mt-2 flex items-center gap-3">
                        <img src={headerLogoInput || heroSettings.headerLogo} alt="Header Logo Preview" className="h-10 object-contain bg-black px-2 py-1 rounded-sm border border-[#cc0000]/50" />
                        <span className="text-[10px] text-gray-main">Header Logo Aktif</span>
                      </div>
                    )}
                  </div>

                  {/* Hero Logo Upload Section */}
                  <div className="space-y-2 bg-black-main/50 p-4 rounded-sm border border-gray-main/20">
                    <label className="block text-xs uppercase font-bold text-[#cc0000] mb-1 flex items-center gap-2">
                      <Camera className="w-4 h-4" /> Logo Brand Beranda (Di atas "PROFESSIONAL EVENT PRODUCTION")
                    </label>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="flex items-center justify-center gap-2 px-4 py-3 bg-bg-card hover:bg-gray-800 border border-gray-main/30 rounded-sm cursor-pointer text-xs font-bold text-white transition-colors">
                          <Upload className="w-4 h-4 text-[#cc0000]" /> Upload File / Kamera HP
                          <input
                            type="file"
                            accept="image/*"
                            capture="environment"
                            className="hidden"
                            onChange={(e) => handleImageFileChange(e, setHeroLogoInput)}
                          />
                        </label>
                      </div>
                      <div>
                        <input
                          type="url"
                          placeholder="Atau masukkan URL Logo Beranda..."
                          value={heroLogoInput}
                          onChange={(e) => setHeroLogoInput(e.target.value)}
                          className="w-full bg-bg-card border border-gray-main/30 rounded-sm px-3 py-3 text-xs text-white"
                        />
                      </div>
                    </div>
                    {(heroLogoInput || heroSettings.logo) && (
                      <div className="mt-2 flex items-center gap-3">
                        <img src={heroLogoInput || heroSettings.logo} alt="Logo Preview" className="w-16 h-16 object-contain bg-black p-1 rounded-sm border border-[#cc0000]/50" />
                        <span className="text-[10px] text-gray-main">Logo Beranda Aktif</span>
                      </div>
                    )}
                  </div>

                  <div>
                    <label className="block text-[10px] uppercase font-bold text-gray-main mb-1">Judul Utama (Heading)</label>
                    <input
                      name="heroTitle"
                      defaultValue={heroSettings.title}
                      required
                      className="w-full bg-black-main border border-gray-main/30 rounded-sm p-3 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] uppercase font-bold text-gray-main mb-1">Deskripsi / Slogan</label>
                    <textarea
                      name="heroSubtitle"
                      rows={3}
                      defaultValue={heroSettings.subtitle}
                      required
                      className="w-full bg-black-main border border-gray-main/30 rounded-sm p-3 text-xs text-white"
                    />
                  </div>

                  <div className="space-y-2 bg-black-main/50 p-4 rounded-sm border border-gray-main/20">
                    <label className="block text-xs uppercase font-bold text-[#cc0000] mb-1 flex items-center gap-2">
                      <Camera className="w-4 h-4" /> Foto Utama Beranda (Upload File / Kamera HP / URL)
                    </label>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <span className="text-[10px] text-gray-main block mb-1">Upload dari File / Foto Kamera HP:</span>
                        <label className="flex items-center justify-center gap-2 px-4 py-3 bg-bg-card hover:bg-gray-800 border border-gray-main/30 rounded-sm cursor-pointer text-xs font-bold text-white transition-colors">
                          <Upload className="w-4 h-4 text-[#cc0000]" /> Pilih File / Ambil Gambar
                          <input
                            type="file"
                            accept="image/*"
                            capture="environment"
                            className="hidden"
                            onChange={(e) => handleImageFileChange(e, setHeroImageInput)}
                          />
                        </label>
                      </div>
                      <div>
                        <span className="text-[10px] text-gray-main block mb-1">Atau Masukkan URL Gambar:</span>
                        <div className="relative">
                          <Link className="absolute left-3 top-3 w-3.5 h-3.5 text-gray-main" />
                          <input
                            type="url"
                            placeholder="https://..."
                            value={heroImageInput}
                            onChange={(e) => setHeroImageInput(e.target.value)}
                            className="w-full bg-bg-card border border-gray-main/30 rounded-sm pl-9 pr-3 py-2.5 text-xs text-white"
                          />
                        </div>
                      </div>
                    </div>
                    {(heroImageInput || heroSettings.image) && (
                      <div className="mt-2 flex items-center gap-3">
                        <img src={heroImageInput || heroSettings.image} alt="Hero Preview" className="w-16 h-16 object-cover rounded-sm border border-[#cc0000]/50" />
                        <span className="text-[10px] text-gray-main">Foto Beranda Aktif</span>
                      </div>
                    )}
                  </div>

                  <button type="submit" className="bg-[#cc0000] hover:bg-[#800000] text-white px-6 py-3 rounded-sm text-xs font-bold uppercase transition-colors">
                    Simpan Perubahan Beranda
                  </button>
                </form>
              </div>

              {/* Service Options Management for Booking Form */}
              <div className="bg-bg-card p-8 rounded-sm border border-gray-main/20">
                <h2 className="text-2xl font-black mb-2">Manajemen Pilihan Layanan Booking</h2>
                <p className="text-xs text-gray-main mb-6">Tambah atau hapus opsi layanan yang akan muncul di formulir pemesanan (Booking Form).</p>
                
                <form
                  onSubmit={handleAddServiceOption}
                  className="flex gap-3 mb-6 bg-black-main/50 p-4 rounded-sm border border-gray-main/20"
                >
                  <div className="flex-1">
                    <input
                      type="text"
                      placeholder="Nama layanan baru (contoh: Live Streaming)..."
                      value={newServiceOption}
                      onChange={e => setNewServiceOption(e.target.value)}
                      className="w-full bg-black-main border border-gray-main/30 rounded-sm px-4 py-2.5 text-xs text-white"
                    />
                  </div>
                  <button
                    type="submit"
                    className="bg-[#cc0000] hover:bg-[#800000] text-white px-6 py-2.5 rounded-sm text-xs font-bold uppercase flex items-center gap-1.5"
                  >
                    <Plus className="w-4 h-4" /> Tambah Layanan
                  </button>
                </form>

                <div className="grid md:grid-cols-2 gap-3">
                  {serviceOptions.map(srv => (
                    <div key={srv} className="flex items-center justify-between bg-black-main p-3.5 rounded-sm border border-gray-main/20">
                      <span className="text-xs font-bold text-white">{srv}</span>
                      <button
                        onClick={() => handleDeleteServiceOption(srv)}
                        className="px-2.5 py-1 bg-red-600/20 text-red-400 rounded text-xs font-bold hover:bg-red-600 hover:text-white flex items-center gap-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" /> Hapus
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Social Media Links Management */}
              <div className="bg-bg-card p-8 rounded-sm border border-gray-main/20">
                <h2 className="text-2xl font-black mb-2">Manajemen Media Sosial</h2>
                <p className="text-xs text-gray-main mb-6">Tambah atau kurangi jumlah menu media sosial yang tampil di beranda & footer website.</p>
                
                {/* Add new social form */}
                <form onSubmit={handleAddSocial} className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8 bg-black-main/50 p-4 rounded-sm border border-gray-main/20">
                  <div>
                    <label className="block text-[10px] uppercase font-bold text-gray-main mb-1">Nama Medsos</label>
                    <input
                      type="text"
                      placeholder="Instagram / TikTok dll"
                      value={newSocialName}
                      onChange={e => setNewSocialName(e.target.value)}
                      required
                      className="w-full bg-black-main border border-gray-main/30 rounded-sm p-2.5 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] uppercase font-bold text-gray-main mb-1">URL Link</label>
                    <input
                      type="url"
                      placeholder="https://..."
                      value={newSocialUrl}
                      onChange={e => setNewSocialUrl(e.target.value)}
                      required
                      className="w-full bg-black-main border border-gray-main/30 rounded-sm p-2.5 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] uppercase font-bold text-gray-main mb-1">Platform / Ikon</label>
                    <select
                      value={newSocialIcon}
                      onChange={e => setNewSocialIcon(e.target.value as any)}
                      className="w-full bg-black-main border border-gray-main/30 rounded-sm p-2.5 text-xs text-white"
                    >
                      <option value="instagram">Instagram</option>
                      <option value="facebook">Facebook</option>
                      <option value="youtube">YouTube</option>
                      <option value="tiktok">TikTok</option>
                      <option value="whatsapp">WhatsApp</option>
                      <option value="github">GitHub</option>
                      <option value="twitter">Twitter / X</option>
                      <option value="globe">Website Lainnya</option>
                    </select>
                  </div>
                  <div className="flex items-end">
                    <button type="submit" className="w-full bg-[#cc0000] hover:bg-[#800000] text-white py-2.5 rounded-sm text-xs font-bold uppercase flex items-center justify-center gap-1.5">
                      <Share2 className="w-3.5 h-3.5" /> Tambah Medsos
                    </button>
                  </div>
                </form>

                {/* List of social links */}
                <div className="space-y-3">
                  {socialLinks.map(s => (
                    <div key={s.id} className="flex items-center justify-between bg-black-main p-4 rounded-sm border border-gray-main/20">
                      <div>
                        <span className="text-xs font-bold text-white uppercase mr-3">{s.name}</span>
                        <a href={s.url} target="_blank" rel="noreferrer" className="text-xs text-[#cc0000] underline truncate max-w-xs inline-block">
                          {s.url}
                        </a>
                      </div>
                      <button
                        onClick={() => handleDeleteSocial(s.id)}
                        className="px-3 py-1.5 bg-red-600/20 text-red-400 rounded text-xs font-bold hover:bg-red-600 hover:text-white flex items-center gap-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" /> Hapus
                      </button>
                    </div>
                  ))}
                  {socialLinks.length === 0 && (
                    <p className="text-xs text-gray-main text-center py-4">Belum ada media sosial ditambahkan.</p>
                  )}
                </div>
              </div>

            </div>
          )}

        </main>
      </div>
    </div>
  );
}
