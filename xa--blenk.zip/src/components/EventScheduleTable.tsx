import { useState, useEffect } from 'react';
import { events, Event } from '../data/events';
import { motion } from 'motion/react';
import { Calendar, Sparkles } from 'lucide-react';

export default function EventScheduleTable() {
  const [eventList, setEventList] = useState<Event[]>(() => {
    const saved = localStorage.getItem('xablenk_events');
    const list: Event[] = saved ? JSON.parse(saved) : events;
    const now = Date.now();
    const oneMonthMs = 30 * 24 * 60 * 60 * 1000;
    return list.filter(ev => !ev.timestamp || (now - ev.timestamp < oneMonthMs));
  });

  useEffect(() => {
    const interval = setInterval(() => {
      const saved = localStorage.getItem('xablenk_events');
      if (saved) {
        const list: Event[] = JSON.parse(saved);
        const now = Date.now();
        const oneMonthMs = 30 * 24 * 60 * 60 * 1000;
        const active = list.filter(ev => !ev.timestamp || (now - ev.timestamp < oneMonthMs));
        setEventList(active);
      }
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section id="jadwal" className="py-24 bg-black-main relative overflow-hidden">
      {/* Background ambient crimson glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] bg-[#cc0000]/10 rounded-full blur-[160px] pointer-events-none animate-pulse" />

      <div className="container mx-auto px-6 relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-sm bg-bg-card border border-[#cc0000]/40 text-[#cc0000] text-xs uppercase tracking-widest font-bold mb-3 shadow-[0_0_15px_rgba(204,0,0,0.2)]">
            <Sparkles className="w-3.5 h-3.5 animate-spin" /> JADWAL KEGIATAN & EVENT
          </div>
          <h2 className="text-4xl md:text-5xl font-black tracking-tight mb-4">
            UPCOMING <span className="text-[#cc0000]">EVENTS.</span>
          </h2>
          <p className="text-gray-main max-w-xl mx-auto text-xs md:text-sm">
            Daftar jadwal produksi event resmi XA-BLENK. Kegiatan akan otomatis terhapus dari sistem setelah 1 bulan.
          </p>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, scale: 0.98 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="bg-bg-card border border-[#cc0000]/30 rounded-sm overflow-hidden shadow-2xl glow-border"
        >
          <div className="overflow-x-auto">
            <table className="w-full text-xs md:text-sm text-left">
              <thead className="bg-[#141414] text-gray-main uppercase text-[11px] md:text-xs border-b border-[#cc0000]/40 tracking-wider">
                <tr>
                  <th className="px-4 py-4">Nomer</th>
                  <th className="px-4 py-4">Acara</th>
                  <th className="px-4 py-4">Hari Tanggal Bulan</th>
                  <th className="px-4 py-4">Penyewa</th>
                  <th className="px-4 py-4">Lokasi</th>
                  <th className="px-4 py-4">Acara Pukul</th>
                  <th className="px-4 py-4">Keterangan</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-main/15">
                {eventList.map((event, index) => (
                  <motion.tr 
                    initial={{ opacity: 0, y: 10 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.3, delay: index * 0.05 }}
                    key={event.id} 
                    className="hover:bg-[#cc0000]/10 transition-colors"
                  >
                    <td className="px-4 py-4 text-[#cc0000] font-black">{event.no}</td>
                    <td className="px-4 py-4 font-bold text-white flex items-center gap-2">
                      <Calendar className="w-3.5 h-3.5 text-[#cc0000]" /> {event.name}
                    </td>
                    <td className="px-4 py-4 text-gray-main font-medium">{event.dateText || '-'}</td>
                    <td className="px-4 py-4 text-gray-main font-semibold">{event.client}</td>
                    <td className="px-4 py-4 text-gray-main">{event.location}</td>
                    <td className="px-4 py-4 text-[#cc0000] font-semibold">{event.timeText || '-'}</td>
                    <td className="px-4 py-4 text-gray-main">{event.keterangan || '-'}</td>
                  </motion.tr>
                ))}
                {eventList.length === 0 && (
                  <tr>
                    <td colSpan={7} className="px-4 py-12 text-center text-gray-main text-xs uppercase tracking-widest">
                      Belum ada jadwal kegiatan aktif (kegiatan otomatis terhapus setelah 1 bulan).
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
