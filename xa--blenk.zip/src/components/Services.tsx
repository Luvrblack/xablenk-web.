import { Mic, Lightbulb, Monitor, Settings, LayoutGrid, Radio } from 'lucide-react';

const services = [
  { title: 'Sistem Audio', icon: Mic },
  { title: 'Sistem Pencahayaan', icon: Lightbulb },
  { title: 'Videotron', icon: Monitor },
  { title: 'Rigging', icon: Settings },
  { title: 'Panggung', icon: LayoutGrid },
  { title: 'Produksi Penuh', icon: Radio },
];

export default function Services() {
  return (
    <section id="layanan" className="py-12">
      <div className="container mx-auto px-6">
        <h2 className="text-2xl md:text-3xl font-black mb-6 tracking-wider">LAYANAN UTAMA</h2>
        <div className="grid grid-cols-2 md:grid-cols-6 gap-3">
          {services.map(s => (
            <div key={s.title} className="bg-bg-card p-4 rounded-sm hover:border-red-main border border-gray-main/20 transition-all duration-300 transform hover:-translate-y-1">
              <s.icon className="text-red-main w-6 h-6 mb-2" />
              <h3 className="text-xs font-bold uppercase tracking-wide mb-1">{s.title}</h3>
              <p className="text-[10px] text-gray-main leading-tight">Layanan {s.title.toLowerCase()} profesional.</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
