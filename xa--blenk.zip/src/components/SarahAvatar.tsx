import React from 'react';

interface SarahAvatarProps {
  className?: string;
}

export const SarahAvatar: React.FC<SarahAvatarProps> = ({ className = 'w-8 h-8' }) => {
  return (
    <div className={`relative inline-block overflow-hidden rounded-full ${className}`}>
      <svg
        viewBox="0 0 120 120"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full object-cover"
      >
        <defs>
          <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#2b0303" />
            <stop offset="50%" stopColor="#800000" />
            <stop offset="100%" stopColor="#cc0000" />
          </linearGradient>
          <linearGradient id="hairGrad" x1="0%" y1="0%" x2="50%" y2="100%">
            <stop offset="0%" stopColor="#211510" />
            <stop offset="100%" stopColor="#120a06" />
          </linearGradient>
          <linearGradient id="skinGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#ffdfd0" />
            <stop offset="100%" stopColor="#f3c4af" />
          </linearGradient>
          <linearGradient id="headsetGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#555" />
            <stop offset="50%" stopColor="#222" />
            <stop offset="100%" stopColor="#111" />
          </linearGradient>
          <linearGradient id="shirtGrad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#cc0000" />
            <stop offset="50%" stopColor="#1a1a1a" />
            <stop offset="100%" stopColor="#cc0000" />
          </linearGradient>
        </defs>

        {/* Circular Background */}
        <circle cx="60" cy="60" r="60" fill="url(#bgGrad)" />

        {/* Ambient Ring Glow */}
        <circle cx="60" cy="60" r="57" stroke="#ff4d4d" strokeWidth="2" strokeOpacity="0.4" />

        {/* Hair Back / Bun / Volume */}
        <path
          d="M32 60 C26 35 40 18 60 18 C80 18 94 35 88 60 C85 75 75 88 60 88 C45 88 35 75 32 60 Z"
          fill="url(#hairGrad)"
        />
        {/* Cute High Ponytail / Bob detail */}
        <path
          d="M84 40 C95 44 100 56 95 68 C90 74 85 72 82 62 Z"
          fill="url(#hairGrad)"
        />

        {/* Neck */}
        <rect x="52" y="74" width="16" height="18" rx="4" fill="url(#skinGrad)" />

        {/* Clothes / Uniform Collar */}
        <path
          d="M26 114 C30 96 44 88 60 88 C76 88 90 96 94 114 C85 119 73 120 60 120 C47 120 35 119 26 114 Z"
          fill="url(#shirtGrad)"
        />
        {/* Collar V-Neck */}
        <path d="M50 88 L60 102 L70 88 Z" fill="#ffdfd0" />
        <path d="M54 90 L60 100 L66 90" stroke="#cc0000" strokeWidth="1.5" fill="none" />
        {/* Name tag or badge on chest */}
        <rect x="68" y="104" width="14" height="6" rx="1.5" fill="#ffffff" />
        <rect x="70" y="106" width="10" height="2" fill="#cc0000" />

        {/* Ears */}
        <circle cx="37" cy="58" r="6.5" fill="url(#skinGrad)" />
        <circle cx="83" cy="58" r="6.5" fill="url(#skinGrad)" />
        {/* Cute Pearl Earrings */}
        <circle cx="37" cy="62" r="2.2" fill="#ffffff" />
        <circle cx="83" cy="62" r="2.2" fill="#ffffff" />

        {/* Face Base */}
        <path
          d="M38 50 C38 36 48 30 60 30 C72 30 82 36 82 50 C82 65 74 76 60 76 C46 76 38 65 38 50 Z"
          fill="url(#skinGrad)"
        />

        {/* Hair Front / Bangs & Side Tendrils */}
        <path
          d="M38 46 C42 32 50 26 60 26 C70 26 78 32 82 46 C76 38 68 34 60 35 C52 36 44 38 38 46 Z"
          fill="url(#hairGrad)"
        />
        {/* Stylish Side Fringe */}
        <path
          d="M37 46 C39 56 42 66 43 68 C41 68 38 60 37 46 Z"
          fill="url(#hairGrad)"
        />
        <path
          d="M83 46 C81 56 78 66 77 68 C79 68 82 60 83 46 Z"
          fill="url(#hairGrad)"
        />

        {/* Cheerful Eyebrows */}
        <path d="M44 45 C47 43 51 43 53 45" stroke="#3d2314" strokeWidth="1.6" strokeLinecap="round" fill="none" />
        <path d="M67 45 C69 43 73 43 76 45" stroke="#3d2314" strokeWidth="1.6" strokeLinecap="round" fill="none" />

        {/* Expressive Warm Eyes */}
        <ellipse cx="48.5" cy="50.5" rx="3.8" ry="4.5" fill="#24140c" />
        <ellipse cx="71.5" cy="50.5" rx="3.8" ry="4.5" fill="#24140c" />
        {/* Eye Highlights */}
        <circle cx="47.5" cy="49" r="1.4" fill="#ffffff" />
        <circle cx="50" cy="52" r="0.6" fill="#ffffff" />
        <circle cx="70.5" cy="49" r="1.4" fill="#ffffff" />
        <circle cx="73" cy="52" r="0.6" fill="#ffffff" />
        {/* Soft Eyelashes */}
        <path d="M44.5 48 C47 46.5 51 46.5 53 48.5" stroke="#1f1109" strokeWidth="1.4" strokeLinecap="round" fill="none" />
        <path d="M67 48.5 C69 46.5 73 46.5 75.5 48" stroke="#1f1109" strokeWidth="1.4" strokeLinecap="round" fill="none" />

        {/* Cute Soft Blush */}
        <ellipse cx="43" cy="56" rx="4" ry="2" fill="#ff7f7f" fillOpacity="0.4" />
        <ellipse cx="77" cy="56" rx="4" ry="2" fill="#ff7f7f" fillOpacity="0.4" />

        {/* Dainty Nose */}
        <path d="M59.5 54 C60 55.5 61 55.5 61.5 54" stroke="#d99982" strokeWidth="1.2" strokeLinecap="round" fill="none" />

        {/* Sweet Friendly Smile */}
        <path
          d="M53 60 C56 64.5 64 64.5 67 60"
          stroke="#b33939"
          strokeWidth="1.8"
          strokeLinecap="round"
          fill="none"
        />
        {/* Gentle Teeth/Mouth fill */}
        <path
          d="M54.5 60.5 C57 63.5 63 63.5 65.5 60.5 Z"
          fill="#ffffff"
          fillOpacity="0.8"
        />

        {/* Professional Customer Service Headset */}
        {/* Headband arch */}
        <path
          d="M34 54 C32 30 46 16 60 16 C74 16 88 30 86 54"
          stroke="url(#headsetGrad)"
          strokeWidth="3.2"
          strokeLinecap="round"
          fill="none"
        />
        {/* Ear cushions */}
        <rect x="30" y="48" width="6" height="14" rx="3" fill="#1e1e1e" stroke="#cc0000" strokeWidth="1" />
        <rect x="84" y="48" width="6" height="14" rx="3" fill="#1e1e1e" stroke="#cc0000" strokeWidth="1" />

        {/* Headset Boom Microphone curving to mouth */}
        <path
          d="M33 58 C33 70 42 72 52 68"
          stroke="#222"
          strokeWidth="2"
          strokeLinecap="round"
          fill="none"
        />
        {/* Mic Tip with glowing active LED */}
        <rect x="51" y="65" width="5" height="4" rx="1.5" fill="#111" />
        <circle cx="55.5" cy="67" r="1" fill="#00ff66" />
      </svg>
    </div>
  );
};

export default SarahAvatar;
