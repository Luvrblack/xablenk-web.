import { useState, useEffect } from 'react';
import { rentalPackages, RentalPackage } from '../data/packages';
import { motion, AnimatePresence } from 'motion/react';
import { CheckCircle2, MessageSquare } from 'lucide-react';

const categories = ['All', 'Audio', 'Lighting', 'Videotron', 'Rigging', 'Stage', 'Full Production'];

export default function RentalPackages() {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [packages, setPackages] = useState<RentalPackage[]>(() => {
    const saved = localStorage.getItem('xablenk_packages');
    return saved ? JSON.parse(saved) : rentalPackages;
  });

  useEffect(() => {
    const handleStorageChange = () => {
      const saved = localStorage.getItem('xablenk_packages');
      if (saved) {
        setPackages(JSON.parse(saved));
      }
    };
    window.addEventListener('storage', handleStorageChange);
    // Interval check for live updates within same session
    const interval = setInterval(() => {
      const saved = localStorage.getItem('xablenk_packages');
      if (saved) {
        setPackages(JSON.parse(saved));
      }
    }, 1000);
    return () => {
      window.removeEventListener('storage', handleStorageChange);
      clearInterval(interval);
    };
  }, []);

  const filteredPackages = selectedCategory === 'All'
    ? packages
    : packages.filter(pkg => pkg.category === selectedCategory);

  const handleWhatsAppInquiry = (pkgName: string) => {
    const phoneNumber = localStorage.getItem('xablenk_whatsapp_number') || '6285735007989';
    const message = encodeURIComponent(`Halo XA-BLENK, saya ingin menanyakan ketersediaan dan penawaran untuk paket rental: *${pkgName}*. Mohon informasinya.`);
    window.open(`https://wa.me/${phoneNumber}?text=${message}`, '_blank');
  };

  return (
    <section id="paket" className="py-20 bg-black-main relative">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-12">
          <span className="text-[#cc0000] text-xs uppercase tracking-[0.25em] font-bold block mb-2">
            KATALOG PERALATAN & PAKET
          </span>
          <h2 className="text-3xl md:text-4xl font-black tracking-tight mb-3">
            RENTAL <span className="text-[#cc0000]">PACKAGES.</span>
          </h2>
          <p className="text-gray-main max-w-xl mx-auto text-xs md:text-sm">
            Pilihan paket peralatan audio, lighting, videotron, rigging, dan panggung profesional.
          </p>
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap justify-center gap-2 mb-10">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3.5 py-1.5 rounded-sm text-[11px] font-bold uppercase transition-all duration-300 ${
                selectedCategory === cat
                  ? 'bg-[#cc0000] text-white glow-border'
                  : 'bg-bg-card text-gray-main hover:text-white border border-gray-main/20'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Packages Grid - 6 Sejajar (lg:grid-cols-6) */}
        <motion.div layout className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3 sm:gap-4">
          <AnimatePresence>
            {filteredPackages.map((pkg) => (
              <motion.div
                layout
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.4 }}
                key={pkg.id}
                className="bg-bg-card border border-gray-main/15 hover:border-[#cc0000] rounded-sm overflow-hidden flex flex-col justify-between group transition-all duration-300 shadow-lg"
              >
                <div>
                  <div className="relative h-32 overflow-hidden bg-black-secondary">
                    <img
                      src={pkg.image}
                      alt={pkg.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-bg-card via-transparent to-transparent opacity-90" />
                    <span className="absolute top-2 left-2 bg-[#cc0000] text-white text-[9px] font-bold uppercase px-2 py-0.5">
                      {pkg.category}
                    </span>
                  </div>

                  <div className="p-3">
                    <h3 className="text-xs font-bold text-white mb-1 group-hover:text-[#cc0000] transition-colors line-clamp-1">
                      {pkg.name}
                    </h3>
                    <p className="text-gray-main text-[11px] line-clamp-2 mb-3 leading-tight">
                      {pkg.description}
                    </p>
                    <div className="space-y-1 mb-3">
                      {pkg.specs.slice(0, 3).map((spec, idx) => (
                        <div key={idx} className="flex items-center text-[10px] text-gray-main line-clamp-1">
                          <CheckCircle2 className="w-3 h-3 text-[#cc0000] mr-1.5 flex-shrink-0" />
                          <span>{spec}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="p-3 pt-0 flex flex-col gap-2 border-t border-gray-main/10 mt-auto">
                  <span className="text-[10px] text-[#cc0000] font-bold text-center">
                    {pkg.priceTag}
                  </span>
                  <button
                    onClick={() => handleWhatsAppInquiry(pkg.name)}
                    className="w-full bg-[#cc0000] hover:bg-[#800000] text-white py-1.5 rounded-sm text-[10px] font-bold uppercase flex items-center justify-center gap-1 transition-colors glow-border"
                  >
                    <MessageSquare className="w-3 h-3" /> Tanya
                  </button>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>
      </div>
    </section>
  );
}
