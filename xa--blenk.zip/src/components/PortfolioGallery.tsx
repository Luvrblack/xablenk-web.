import { useState, useEffect } from 'react';
import { portfolioItems, PortfolioItem } from '../data/portfolio';
import { motion, AnimatePresence } from 'motion/react';
import { Calendar, MapPin, X } from 'lucide-react';

const categories = ['Semua', 'Konser', 'Festival', 'Pernikahan', 'Perusahaan', 'Produksi Panggung'];

export default function PortfolioGallery() {
  const [selectedCategory, setSelectedCategory] = useState('Semua');
  const [activeItem, setActiveItem] = useState<PortfolioItem | null>(null);
  const [items, setItems] = useState<PortfolioItem[]>(() => {
    const saved = localStorage.getItem('xablenk_portfolio');
    return saved ? JSON.parse(saved) : portfolioItems;
  });

  const [heroSettings, setHeroSettings] = useState<{ backgroundImage?: string }>(() => {
    const saved = localStorage.getItem('xablenk_hero_settings');
    return saved ? JSON.parse(saved) : { backgroundImage: '' };
  });

  useEffect(() => {
    const handleStorageChange = () => {
      const saved = localStorage.getItem('xablenk_portfolio');
      if (saved) {
        setItems(JSON.parse(saved));
      }
      const savedHero = localStorage.getItem('xablenk_hero_settings');
      if (savedHero) {
        setHeroSettings(JSON.parse(savedHero));
      }
    };
    window.addEventListener('storage', handleStorageChange);
    const interval = setInterval(() => {
      const saved = localStorage.getItem('xablenk_portfolio');
      if (saved) {
        setItems(JSON.parse(saved));
      }
      const savedHero = localStorage.getItem('xablenk_hero_settings');
      if (savedHero) {
        setHeroSettings(JSON.parse(savedHero));
      }
    }, 1000);
    return () => {
      window.removeEventListener('storage', handleStorageChange);
      clearInterval(interval);
    };
  }, []);

  const filteredItems = selectedCategory === 'Semua'
    ? items
    : items.filter(item => item.category === selectedCategory);

  return (
    <section 
      id="galeri" 
      className="py-20 relative overflow-hidden bg-black-secondary"
      style={heroSettings.backgroundImage ? {
        backgroundImage: `linear-gradient(to bottom, rgba(5,5,5,0.88), rgba(5,5,5,0.96)), url(${heroSettings.backgroundImage})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center'
      } : {
        backgroundImage: `linear-gradient(to bottom, rgba(5,5,5,0.92), rgba(5,5,5,0.96)), radial-gradient(circle at 50% 50%, rgba(128,0,0,0.2) 0%, rgba(5,5,5,0.95) 70%)`
      }}
    >
      {/* Decorative background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#cc0000]/5 rounded-full blur-[120px] pointer-events-none" />
      
      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <div className="text-center mb-12">
          <span className="text-[#cc0000] text-xs uppercase tracking-[0.25em] font-bold block mb-2">
            PORTFOLIO & DOKUMENTASI
          </span>
          <h2 className="text-3xl md:text-4xl font-black tracking-tight mb-3">
            OUR WORK. <span className="text-[#cc0000]">OUR ENERGY.</span>
          </h2>
          <p className="text-gray-main max-w-xl mx-auto text-xs md:text-sm">
            Saksikan galeri pekerjaan nyata produksi panggung, konser, festival, dan event spektakuler.
          </p>
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap justify-center gap-2 mb-10">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-sm text-[11px] font-bold uppercase transition-all duration-300 ${
                selectedCategory === cat
                  ? 'bg-[#cc0000] text-white glow-border'
                  : 'bg-bg-card text-gray-main hover:text-white border border-gray-main/20'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Portfolio Grid - Compact columns (grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5) */}
        <motion.div layout className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          <AnimatePresence>
            {filteredItems.map((item) => (
              <motion.div
                layout
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.4 }}
                key={item.id}
                onClick={() => setActiveItem(item)}
                className="group bg-bg-card rounded-sm overflow-hidden border border-gray-main/15 hover:border-[#cc0000] transition-all duration-300 cursor-pointer shadow-lg hover:shadow-[0_0_20px_rgba(204,0,0,0.2)] flex flex-col justify-between"
              >
                <div>
                  <div className="relative h-40 overflow-hidden bg-black-secondary">
                    <img
                      src={item.image}
                      alt={item.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 ease-out"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black-main via-transparent to-transparent opacity-80" />
                    <span className="absolute top-2 left-2 bg-black-main/85 backdrop-blur-md text-[#cc0000] text-[9px] font-black uppercase px-2 py-0.5 border border-[#cc0000]/30">
                      {item.category}
                    </span>
                  </div>

                  <div className="p-3.5 flex-1 flex flex-col justify-between">
                    <div>
                      <h3 className="text-xs font-bold mb-1 group-hover:text-[#cc0000] transition-colors line-clamp-1">
                        {item.title}
                      </h3>
                      <p className="text-gray-main text-[11px] line-clamp-2 mb-3 leading-tight">
                        {item.description}
                      </p>
                    </div>
                    <div className="flex items-center justify-between pt-2.5 border-t border-gray-main/10 text-[10px] text-gray-main">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3 h-3 text-[#cc0000]" /> {item.date}
                      </span>
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-[#cc0000]" /> {item.location}
                      </span>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>
      </div>

      {/* Lightbox / Detail Modal */}
      <AnimatePresence>
        {activeItem && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-bg-card border border-[#cc0000]/40 max-w-2xl w-full rounded-sm overflow-hidden shadow-2xl relative"
            >
              <button
                onClick={() => setActiveItem(null)}
                className="absolute top-4 right-4 z-10 bg-black-main/80 text-white p-2 rounded-full hover:bg-[#cc0000] transition-colors"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="h-64 md:h-80 w-full relative">
                <img src={activeItem.image} alt={activeItem.title} className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-bg-card via-transparent to-transparent" />
              </div>

              <div className="p-6">
                <span className="text-[#cc0000] text-xs uppercase font-bold tracking-widest mb-2 block">
                  {activeItem.category}
                </span>
                <h3 className="text-xl md:text-2xl font-black mb-3">{activeItem.title}</h3>
                <p className="text-gray-main text-xs md:text-sm mb-6 leading-relaxed">{activeItem.description}</p>
                <div className="flex flex-wrap gap-6 text-xs text-gray-main border-t border-gray-main/20 pt-4">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-[#cc0000]" />
                    <span>{activeItem.date}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-[#cc0000]" />
                    <span>{activeItem.location}</span>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}
