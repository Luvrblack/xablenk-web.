import { useState, useEffect } from 'react';
import { ArrowRight, Download, Sparkles, MessageSquare, Globe, ShoppingBag, Share2, ExternalLink } from 'lucide-react';
import { events } from '../data/events';
import { SocialLink, HeroSettings } from './AdminDashboard';
import { motion } from 'motion/react';

export default function Hero() {
  // Load events
  const savedEvents = localStorage.getItem('xablenk_events');
  const eventList = savedEvents ? JSON.parse(savedEvents) : events;
  const nextEvent = eventList[0] || { name: 'Konser Musik', dateText: '25 Okt 2026', location: 'Blitar', keterangan: 'Akan Datang' };

  // Load Hero Settings & Socials
  const [hero, setHero] = useState<HeroSettings>(() => {
    const saved = localStorage.getItem('xablenk_hero_settings');
    return saved ? JSON.parse(saved) : {
      title: 'BRING THE EVENT TO THE NEXT LEVEL.',
      subtitle: 'Solusi produksi acara profesional melalui layanan audio, lighting, videotron, rigging, dan panggung untuk menghadirkan pengalaman event yang berkesan.',
      image: 'https://images.unsplash.com/photo-1516450360452-9312f5e86578?q=80&w=1000',
      logo: '',
      backgroundImage: ''
    };
  });

  const [socials, setSocials] = useState<SocialLink[]>(() => {
    const saved = localStorage.getItem('xablenk_socials');
    return saved ? JSON.parse(saved) : [
      { id: 's1', name: 'Instagram', url: 'https://instagram.com/xablenk_audio', icon: 'instagram' },
      { id: 's2', name: 'Facebook', url: 'https://facebook.com', icon: 'facebook' },
      { id: 's3', name: 'YouTube', url: 'https://youtube.com', icon: 'youtube' },
      { id: 's4', name: 'WhatsApp', url: 'https://whatsapp.com', icon: 'whatsapp' }
    ];
  });

  useEffect(() => {
    const interval = setInterval(() => {
      const savedHero = localStorage.getItem('xablenk_hero_settings');
      if (savedHero) setHero(JSON.parse(savedHero));
      const savedSocials = localStorage.getItem('xablenk_socials');
      if (savedSocials) setSocials(JSON.parse(savedSocials));
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const getSocialIcon = (icon: SocialLink['icon']) => {
    switch (icon) {
      case 'instagram': return <Share2 className="w-4 h-4" />;
      case 'facebook': return <Globe className="w-4 h-4" />;
      case 'youtube': return <ExternalLink className="w-4 h-4" />;
      case 'whatsapp': return <MessageSquare className="w-4 h-4" />;
      case 'github': return <Globe className="w-4 h-4" />;
      case 'twitter': return <Share2 className="w-4 h-4" />;
      default: return <Globe className="w-4 h-4" />;
    }
  };

  return (
    <section 
      id="beranda" 
      className="relative min-h-screen flex items-center pt-24 pb-16 overflow-hidden bg-black-main"
      style={hero.backgroundImage ? {
        backgroundImage: `linear-gradient(to bottom, rgba(5,5,5,0.85), rgba(5,5,5,0.95)), url(${hero.backgroundImage})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center'
      } : undefined}
    >
      {/* Massive watermark text matching the reference portfolio concept */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 select-none pointer-events-none z-0 opacity-10 text-center w-full overflow-hidden">
        <span className="text-[16vw] md:text-[20vw] font-black tracking-tighter text-[#cc0000] uppercase block leading-none">
          XA-BLENK
        </span>
      </div>

      {/* Background ambient lighting and crimson glow */}
      <div className="absolute top-20 right-10 w-[500px] h-[500px] bg-[#cc0000]/15 rounded-full blur-[160px] pointer-events-none animate-pulse" />
      <div className="absolute bottom-10 left-10 w-[400px] h-[400px] bg-[#800000]/15 rounded-full blur-[140px] pointer-events-none" />

      <div className="container mx-auto px-6 relative z-10">
        <div className="grid lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Text & CTAs */}
          <motion.div 
            initial={{ opacity: 0, x: -40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7, ease: 'easeOut' }}
            className="lg:col-span-7 space-y-6"
          >
            {/* Uploaded Brand Logo above Professional Event Production badge */}
            {hero.logo && (
              <div className="mb-2">
                <img
                  src={hero.logo}
                  alt="XA-BLENK Brand Logo"
                  className="h-16 md:h-20 object-contain drop-shadow-[0_0_20px_rgba(204,0,0,0.5)]"
                />
              </div>
            )}
            
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-sm bg-bg-card border border-[#cc0000]/40 text-red-500 text-xs uppercase tracking-widest font-bold shadow-[0_0_15px_rgba(204,0,0,0.2)]">
              <Sparkles className="w-3.5 h-3.5 animate-spin text-red-500" /> PRODUKSI ACARA PROFESIONAL
            </div>

            <h1 className="text-5xl md:text-7xl font-black tracking-tight leading-[1.05]">
              {hero.title.split('TO THE NEXT LEVEL')[0]}
              {hero.title.includes('TO THE NEXT LEVEL') && <span className="text-[#cc0000] drop-shadow-[0_0_30px_rgba(204,0,0,0.4)]">TO THE NEXT LEVEL.</span>}
            </h1>

            <p className="text-gray-main text-base md:text-lg max-w-xl">
              {hero.subtitle}
            </p>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <a
                href="#paket"
                className="bg-[#cc0000] hover:bg-[#800000] text-white px-5 py-3 rounded-sm font-bold uppercase text-[11px] md:text-xs tracking-widest transition-all duration-300 transform hover:scale-105 active:scale-95 glow-border flex items-center gap-2 shadow-xl"
              >
                Lihat Paket Rental <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
              </a>
              <a
                href="#merchandise"
                className="bg-[#cc0000] hover:bg-[#800000] text-white px-5 py-3 rounded-sm font-bold uppercase text-[11px] md:text-xs tracking-widest transition-all duration-300 transform hover:scale-105 active:scale-95 glow-border flex items-center gap-2 shadow-xl"
              >
                Merchandise <ShoppingBag className="w-3.5 h-3.5 text-white" />
              </a>
              <a
                href="#kontak"
                className="bg-[#cc0000] hover:bg-[#800000] text-white px-5 py-3 rounded-sm font-bold uppercase text-[11px] md:text-xs tracking-widest transition-all duration-300 transform hover:scale-105 active:scale-95 glow-border flex items-center gap-2 shadow-xl"
              >
                Konsultasi Booking <Download className="w-3.5 h-3.5" />
              </a>
            </div>

            {/* Dynamic Social Links */}
            <div className="pt-8 border-t border-gray-main/10 flex items-center gap-6 flex-wrap">
              <span className="text-xs uppercase tracking-widest text-gray-main font-bold">Hubungi Kami</span>
              <div className="flex items-center gap-3 flex-wrap">
                {socials.map(s => (
                  <a
                    key={s.id}
                    href={s.url}
                    target="_blank"
                    rel="noreferrer"
                    title={s.name}
                    className="w-10 h-10 bg-bg-card border border-gray-main/20 flex items-center justify-center rounded-sm text-white hover:border-[#cc0000] hover:text-[#cc0000] transition-colors shadow-md hover:scale-110 transform duration-200"
                  >
                    {getSocialIcon(s.icon)}
                  </a>
                ))}
              </div>
            </div>

          </motion.div>

          {/* Right Column: Hero Image with Floating Upcoming Event Box & Badge */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, delay: 0.2, ease: 'easeOut' }}
            className="lg:col-span-5 relative flex justify-center"
          >
            {/* Glowing frame / geometry behind image */}
            <div className="absolute inset-0 border-2 border-[#cc0000]/40 rounded-2xl transform rotate-6 scale-95 pointer-events-none glow-border animate-pulse" />
            
            {/* Main Hero Image */}
            <div className="relative z-10 w-full max-w-md bg-bg-card rounded-sm overflow-hidden border border-[#cc0000]/60 shadow-2xl">
              <img
                src={hero.image}
                alt="Stage Concert Production"
                className="w-full h-[420px] object-cover filter contrast-115 transform hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-transparent to-transparent opacity-90" />
              
              <div className="absolute bottom-4 left-4 right-4 p-4 bg-[#050505]/90 backdrop-blur-md border border-[#cc0000]/30 rounded-sm">
                <p className="text-xs text-[#cc0000] font-bold uppercase tracking-wider">XA- BLENK PRODUCTION</p>
                <p className="text-sm font-bold text-white">Full Concert & Stage Setup</p>
              </div>
            </div>

            {/* Floating Upcoming Event Box (Top Right) */}
            <motion.div 
              animate={{ y: [0, -8, 0] }}
              transition={{ repeat: Infinity, duration: 4, ease: 'easeInOut' }}
              className="hidden sm:block absolute -top-6 -right-6 z-20 bg-bg-card/95 backdrop-blur-md border border-[#cc0000]/50 p-4 rounded-sm shadow-xl max-w-[240px]"
            >
              <p className="text-[10px] uppercase font-bold text-[#cc0000] mb-1 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[#cc0000] animate-pulse" /> Acara Mendatang:
              </p>
              <pre className="text-[10px] text-white font-mono leading-tight whitespace-pre-wrap">{`{
  nama: "${nextEvent.name}",
  lokasi: "${nextEvent.location}",
  keterangan: "${nextEvent.keterangan || 'Akan Datang'}"
};`}</pre>
            </motion.div>

            {/* Floating Freelance / Booking Badge (Bottom Right) */}
            <motion.div 
              animate={{ y: [0, 8, 0] }}
              transition={{ repeat: Infinity, duration: 4.5, ease: 'easeInOut' }}
              className="absolute -bottom-6 -right-4 z-20 bg-bg-card/95 backdrop-blur-md border border-[#cc0000]/50 px-5 py-3 rounded-sm shadow-xl flex items-center gap-3"
            >
              <span className="w-2.5 h-2.5 rounded-full bg-[#cc0000] animate-ping" />
              <div className="text-left">
                <p className="text-[10px] uppercase text-gray-main font-bold">KETERSEDIAAN</p>
                <p className="text-xs font-black text-white">BUKA PEMESANAN ACARA</p>
              </div>
            </motion.div>

          </motion.div>

        </div>
      </div>
    </section>
  );
}
