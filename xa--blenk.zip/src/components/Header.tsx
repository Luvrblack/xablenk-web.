import { useState, useEffect } from 'react';

export default function Header() {
  const [logoImg, setLogoImg] = useState<string>('');

  useEffect(() => {
    const updateLogo = () => {
      const saved = localStorage.getItem('xablenk_hero_settings');
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (parsed.headerLogo) {
            setLogoImg(parsed.headerLogo);
          } else if (parsed.logo) {
            setLogoImg(parsed.logo);
          } else {
            setLogoImg('');
          }
        } catch {}
      }
    };
    updateLogo();
    const interval = setInterval(updateLogo, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <header className="sticky top-0 z-50 bg-black-main/90 backdrop-blur-md border-b border-gray-main/10">
      <nav className="container mx-auto px-6 py-4 flex justify-between items-center">
        <div className="text-xl font-black tracking-tighter text-white flex items-center gap-1.5 font-mono">
          {logoImg ? (
            <a href="#beranda" className="flex items-center">
              <img src={logoImg} alt="XA-BLENK Logo" className="h-8 md:h-10 object-contain" />
            </a>
          ) : (
            <a href="#beranda" className="flex items-center gap-1.5 hover:opacity-95 transition-opacity">
              <span className="text-red-main">&lt;/&gt;</span> XA-<span className="text-red-main">BLENK</span>
            </a>
          )}
        </div>
        <div className="hidden lg:flex space-x-6 text-[11px] uppercase tracking-widest font-bold">
          <a href="#beranda" className="hover:text-red-main transition-colors">Beranda</a>
          <a href="#merchandise" className="hover:text-red-main transition-colors">Merchandise</a>
          <a href="#layanan" className="hover:text-red-main transition-colors">Layanan</a>
          <a href="#paket" className="hover:text-red-main transition-colors">Paket</a>
          <a href="#jadwal" className="hover:text-red-main transition-colors">Jadwal</a>
          <a href="#galeri" className="hover:text-red-main transition-colors">Proyek</a>
          <a href="#kontak" className="hover:text-red-main transition-colors">Kontak</a>
        </div>
        <a
          href="#kontak"
          className="bg-red-main hover:bg-red-dark text-white px-6 py-2.5 rounded-sm font-bold uppercase text-[11px] tracking-wider transition-all duration-300 glow-border"
        >
          Hubungi Kami
        </a>
      </nav>
    </header>
  );
}
