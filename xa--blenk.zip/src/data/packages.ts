export interface RentalPackage {
  id: string;
  category: 'Audio' | 'Lighting' | 'Videotron' | 'Rigging' | 'Stage' | 'Full Production';
  name: string;
  image: string;
  description: string;
  specs: string[];
  priceTag: string;
}

export const rentalPackages: RentalPackage[] = [
  {
    id: 'pkg-1',
    category: 'Audio',
    name: 'Audio Basic Event',
    image: 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?q=80&w=800',
    description: 'Paket suara ideal untuk acara indoor skala kecil hingga menengah seperti seminar, gathering, atau mini acoustic.',
    specs: ['2x Active Speaker 15"', '1x Digital Mixer 16 Ch', '2x Wireless Mic', 'Cables & Stands', '1x Sound Operator'],
    priceTag: 'Hubungi untuk Penawaran (DEMO)'
  },
  {
    id: 'pkg-2',
    category: 'Audio',
    name: 'Audio Concert Pro',
    image: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?q=80&w=800',
    description: 'Sistem Line Array bertenaga besar untuk konser musik outdoor, festival, dan panggung megah.',
    specs: ['8x Line Array Speaker', '4x Dual Subwoofer 18"', 'Digital Mixer 32 Ch Stagebox', 'In-Ear Monitor & Mic Package', '2x Professional Audio Engineer'],
    priceTag: 'Hubungi untuk Penawaran (DEMO)'
  },
  {
    id: 'pkg-3',
    category: 'Lighting',
    name: 'Lighting Show Standard',
    image: 'https://images.unsplash.com/photo-1516450360452-9312f5e86578?q=80&w=800',
    description: 'Pencahayaan dinamis untuk menghidupkan suasana panggung dan memukau penonton.',
    specs: ['12x PAR LED RGBW', '6x Moving Head Beam 230W', '2x Blinder 4-Eye', 'Lighting Controller DMX', '1x Lighting Operator'],
    priceTag: 'Hubungi untuk Penawaran (DEMO)'
  },
  {
    id: 'pkg-4',
    category: 'Videotron',
    name: 'Videotron P3.9 Outdoor Medium',
    image: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?q=80&w=800',
    description: 'Layar LED beresolusi tinggi dengan tingkat kecerahan maksimal untuk visibilitas siang & malam hari.',
    specs: ['Ukuran 6m x 4m (P3.9 Outdoor)', 'Video Processor NovaStar', 'Laptop Controller & Switcher', '1x Visual Operator'],
    priceTag: 'Hubungi untuk Penawaran (DEMO)'
  },
  {
    id: 'pkg-5',
    category: 'Rigging',
    name: 'Rigging Aluminium Truss 10x8',
    image: 'https://images.unsplash.com/photo-1501386761578-eac5c94b800a?q=80&w=800',
    description: 'Struktur panggung kokoh bersertifikasi untuk menopang tata cahaya dan sistem suara berat.',
    specs: ['Aluminium Truss 30x30 / 40x40', 'Ground Support System 4 Hoist', 'Safety Rigging Accessories', 'Tim Instalasi & Safety'],
    priceTag: 'Hubungi untuk Penawaran (DEMO)'
  },
  {
    id: 'pkg-6',
    category: 'Full Production',
    name: 'Full Event Production Mega',
    image: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?q=80&w=800',
    description: 'Solusi all-in-one komprehensif: Audio, Lighting, Videotron, Rigging, Stage, dan Manajemen Teknis Penuh.',
    specs: ['Line Array Concert Package', 'Moving Head & PAR LED Lighting Show', 'Videotron Utama & Samping', 'Rigging & Panggung Modular', 'Full Crew & Produser Teknis'],
    priceTag: 'Hubungi untuk Penawaran (DEMO)'
  }
];
