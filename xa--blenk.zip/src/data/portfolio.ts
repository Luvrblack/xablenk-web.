export interface PortfolioItem {
  id: string;
  title: string;
  category: 'Concert' | 'Wedding' | 'Festival' | 'Corporate' | 'Stage Production';
  image: string;
  location: string;
  date: string;
  description: string;
}

export const portfolioItems: PortfolioItem[] = [
  {
    id: 'p1',
    title: 'Rock Arena Music Festival 2026',
    category: 'Festival',
    image: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?q=80&w=1200',
    location: 'Stadion Utama Gelora Bung Karno',
    date: '12 September 2026',
    description: 'Full production setup including massive Line Array audio system, 14m x 8m outdoor stage, moving head beam lights, and 100m P3.9 outdoor videotron.'
  },
  {
    id: 'p2',
    title: 'EDM Summer Sunset Party',
    category: 'Concert',
    image: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?q=80&w=1200',
    location: 'Beach Club Bali',
    date: '28 Agustus 2026',
    description: 'Dynamic lighting show featuring 48 units of moving head spot, full laser effects, and custom DJ booth LED backdrop.'
  },
  {
    id: 'p3',
    title: 'Grand Royal Wedding Reception',
    category: 'Wedding',
    image: 'https://images.unsplash.com/photo-1519741497674-611481863552?q=80&w=1200',
    location: 'The Ritz-Carlton Ballroom',
    date: '15 Juli 2026',
    description: 'Elegant warm lighting design, crystal clear compact line array for acoustic performances, and dual side LED screens for visual montages.'
  },
  {
    id: 'p4',
    title: 'TechCorp Annual Innovation Summit',
    category: 'Corporate',
    image: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?q=80&w=1200',
    location: 'Jakarta Convention Center',
    date: '05 Juni 2026',
    description: 'Corporate stage setup with high-resolution indoor P2.6 videotron main screen, professional podium mic systems, and directional spotlighting.'
  },
  {
    id: 'p5',
    title: 'Acoustic Sunset Live Session',
    category: 'Stage Production',
    image: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?q=80&w=1200',
    location: 'Open Air Amphitheater',
    date: '20 Mei 2026',
    description: 'Custom modular stage rigging with atmospheric backlighting and professional sound engineering for pristine acoustic performance.'
  },
  {
    id: 'p6',
    title: 'Indie Youth Music Celebration',
    category: 'Festival',
    image: 'https://images.unsplash.com/photo-1501386761578-eac5c94b800a?q=80&w=1200',
    location: 'City Square Open Ground',
    date: '10 April 2026',
    description: 'Complete aluminium truss rigging ground support, robust subwoofers, and energetic strobe and wash lighting.'
  }
];
