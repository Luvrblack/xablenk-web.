export interface Event {
  id: string;
  no: string;
  name: string;
  dateText: string;
  client: string;
  location: string;
  timeText: string;
  keterangan: string;
  timestamp: number;
}

export const events: Event[] = [
  { 
    id: '1', 
    no: '01', 
    name: 'Konser Musik', 
    dateText: 'Sabtu, 25 Oktober 2026', 
    client: 'Penyewa DEMO', 
    location: 'Blitar', 
    timeText: '19.00 WIB', 
    keterangan: 'Full Sound & Lighting Setup', 
    timestamp: Date.now() 
  },
  { 
    id: '2', 
    no: '02', 
    name: 'Wedding Event', 
    dateText: 'Rabu, 28 Oktober 2026', 
    client: 'Penyewa DEMO', 
    location: 'Malang', 
    timeText: '10.00 WIB', 
    keterangan: 'Acoustic & Stage Production', 
    timestamp: Date.now() 
  },
];
