import 'dotenv/config';
import express, { Request, Response } from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import { db } from './server/db.js';
import { askCustomerServiceAI, testGeminiApiKey } from './server/gemini.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

// Helper auth check for Admin API endpoints
function isAdminAuthorized(req: Request, res: Response, next: () => void) {
  const token = req.headers['x-admin-token'];
  // Admin credentials default 'admin' or session check
  if (!token || token !== 'xablenk_admin_secret_token') {
    res.status(401).json({ error: 'Akses tidak sah. Harap login ke C-Panel Admin.' });
    return;
  }
  next();
}

// ---------------- API ROUTES ----------------

// 1. Customer Service AI Chat Endpoint
app.post('/api/chat', async (req: Request, res: Response) => {
  try {
    const { message, history, whatsappNumber } = req.body;
    if (!message || typeof message !== 'string') {
      res.status(400).json({ error: 'Pesan tidak boleh kosong.' });
      return;
    }

    const response = await askCustomerServiceAI({
      message,
      history,
      whatsappNumber
    });

    res.json(response);
  } catch (err: any) {
    console.error('API /api/chat error:', err);
    res.status(500).json({
      reply: 'Mohon maaf, terjadi kendala pada server asisten AI. Silakan hubungi admin kami via WhatsApp.',
      redirectToAdmin: true
    });
  }
});

// 2. Order Management Endpoints
app.get('/api/orders', (req: Request, res: Response) => {
  try {
    const orders = db.getOrders();
    res.json(orders);
  } catch (err) {
    res.status(500).json({ error: 'Gagal mengambil data pesanan.' });
  }
});

app.post('/api/orders', (req: Request, res: Response) => {
  try {
    const { customerName, phone, address, themeName, eventDate, eventTime, services, notes } = req.body;
    if (!customerName || !phone) {
      res.status(400).json({ error: 'Nama dan Nomor WhatsApp wajib diisi.' });
      return;
    }

    const newOrder = db.createOrder({
      customerName,
      phone,
      address,
      themeName,
      eventDate,
      eventTime,
      services,
      notes,
      status: 'Pending'
    });

    res.status(201).json({ success: true, order: newOrder });
  } catch (err) {
    res.status(500).json({ error: 'Gagal membuat pesanan baru.' });
  }
});

app.patch('/api/orders/:id', isAdminAuthorized, (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    const updated = db.updateOrderStatus(id, status);
    if (!updated) {
      res.status(404).json({ error: 'Pesanan tidak ditemukan.' });
      return;
    }
    res.json({ success: true, order: updated });
  } catch (err) {
    res.status(500).json({ error: 'Gagal memperbarui pesanan.' });
  }
});

app.delete('/api/orders/:id', isAdminAuthorized, (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const deleted = db.deleteOrder(id);
    if (!deleted) {
      res.status(404).json({ error: 'Pesanan tidak ditemukan.' });
      return;
    }
    res.json({ success: true, message: 'Pesanan berhasil dihapus.' });
  } catch (err) {
    res.status(500).json({ error: 'Gagal menghapus pesanan.' });
  }
});

// 3. Event Schedule Endpoints
app.get('/api/events', (req: Request, res: Response) => {
  try {
    const events = db.getEvents();
    res.json(events);
  } catch (err) {
    res.status(500).json({ error: 'Gagal mengambil data jadwal.' });
  }
});

app.post('/api/events', isAdminAuthorized, (req: Request, res: Response) => {
  try {
    const { name, dateText, client, location, timeText, keterangan } = req.body;
    if (!name || !location) {
      res.status(400).json({ error: 'Nama acara dan lokasi wajib diisi.' });
      return;
    }
    const newEvent = db.createEvent({
      name,
      dateText: dateText || '',
      client: client || '',
      location,
      timeText: timeText || '',
      keterangan: keterangan || '',
      no: ''
    });
    res.status(201).json({ success: true, event: newEvent });
  } catch (err) {
    res.status(500).json({ error: 'Gagal menambah event.' });
  }
});

app.delete('/api/events/:id', isAdminAuthorized, (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const deleted = db.deleteEvent(id);
    if (!deleted) {
      res.status(404).json({ error: 'Event tidak ditemukan.' });
      return;
    }
    res.json({ success: true, message: 'Event berhasil dihapus.' });
  } catch (err) {
    res.status(500).json({ error: 'Gagal menghapus event.' });
  }
});

// 4. Admin AI Configuration Endpoints
app.get('/api/admin/ai/status', isAdminAuthorized, (req: Request, res: Response) => {
  try {
    const config = db.getAiConfig();
    const hasKey = Boolean(config.resolvedKey);
    // Mask key: only show last 4 chars e.g. ...a1B4
    const maskedKey = hasKey && config.resolvedKey.length > 4
      ? '•••••••••••••' + config.resolvedKey.slice(-4)
      : hasKey ? '••••••••' : '';

    res.json({
      configured: hasKey,
      model: config.model,
      maskedKey,
      status: config.status,
      lastTested: config.lastTested,
      lastError: config.lastError
    });
  } catch (err) {
    res.status(500).json({ error: 'Gagal mengambil status AI.' });
  }
});

app.post('/api/admin/ai/config', isAdminAuthorized, (req: Request, res: Response) => {
  try {
    const { apiKey, model } = req.body;
    db.saveAiConfig({
      apiKey: apiKey !== undefined ? apiKey : undefined,
      model: model || undefined,
      status: apiKey ? 'connected' : undefined
    });

    const updated = db.getAiConfig();
    const hasKey = Boolean(updated.resolvedKey);
    const maskedKey = hasKey && updated.resolvedKey.length > 4
      ? '•••••••••••••' + updated.resolvedKey.slice(-4)
      : hasKey ? '••••••••' : '';

    res.json({
      success: true,
      message: 'Pengaturan AI berhasil disimpan di server.',
      model: updated.model,
      maskedKey,
      status: updated.status
    });
  } catch (err) {
    res.status(500).json({ error: 'Gagal menyimpan konfigurasi AI.' });
  }
});

// Test Connection Endpoint with rate-limit protection
let lastTestTimestamp = 0;
app.post('/api/admin/ai/test', isAdminAuthorized, async (req: Request, res: Response) => {
  try {
    const now = Date.now();
    if (now - lastTestTimestamp < 3000) {
      res.status(429).json({ error: 'Harap tunggu beberapa detik sebelum menguji koneksi lagi.' });
      return;
    }
    lastTestTimestamp = now;

    const { apiKey, model } = req.body;
    const aiConfig = db.getAiConfig();
    const keyToTest = apiKey || aiConfig.resolvedKey;

    if (!keyToTest) {
      res.status(400).json({
        success: false,
        message: 'API Key belum diisi atau dikonfigurasi.'
      });
      return;
    }

    const result = await testGeminiApiKey(keyToTest, model || aiConfig.model);

    // Save test status
    db.saveAiConfig({
      status: result.success ? 'connected' : 'error',
      lastError: result.success ? undefined : result.message
    });

    res.json(result);
  } catch (err: any) {
    res.status(500).json({
      success: false,
      message: 'Gagal melakukan pengujian koneksi ke Gemini API.'
    });
  }
});

app.delete('/api/admin/ai/config', isAdminAuthorized, (req: Request, res: Response) => {
  try {
    db.deleteAiConfig();
    res.json({ success: true, message: 'Google Gemini API key berhasil dihapus dari server.' });
  } catch (err) {
    res.status(500).json({ error: 'Gagal menghapus API key.' });
  }
});

// ---------------- VITE & STATIC HANDLING ----------------
async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    // Mount Vite dev server middlewares
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    // Serve static files in production
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(Number(PORT), '0.0.0.0', () => {
    console.log(`🚀 XA-BLENK Full-Stack Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
